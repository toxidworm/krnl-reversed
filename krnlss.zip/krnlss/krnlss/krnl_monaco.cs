﻿// Decompiled with JetBrains decompiler
// Type: krnlss.krnl_monaco
// Assembly: krnlss, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 1D51A737-46C7-4798-AAF1-4373D41D8FFF
// Assembly location: C:\Users\Win10\Desktop\krnl\krnlss.exe

using Bunifu.Framework.UI;
using CefSharp;
using CefSharp.WinForms;
using Controls;
using injection;
using krnlss.Properties;
using Microsoft.CSharp.RuntimeBinder;
using Microsoft.Win32;
using SirhurtUI.Controls;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace krnlss
{
  public class krnl_monaco : Form
  {
    public const int WM_NCLBUTTONDOWN = 161;
    public const int HT_CAPTION = 2;
    private object ScriptPath = (object) Settings.Default.ScriptPath;
    public TabPanelControl tpc = new TabPanelControl();
    public bool changed;
    private IContainer components;
    private Panel panel1;
    private Label label1;
    private ToolStripMenuItem clearToolStripMenuItem;
    private ToolStripMenuItem openIntoToolStripMenuItem;
    private ToolStripMenuItem saveToolStripMenuItem;
    private ToolStripMenuItem renameToolStripMenuItem;
    public ContextMenuStrip TabContextMenu;
    public MonacoCustomTabControl customTabControl1;
    private TabPage tabPage1;
    private TreeView ScriptView;
    private BunifuFlatButton bunifuFlatButton1;
    private BunifuFlatButton bunifuFlatButton2;
    private BunifuFlatButton bunifuFlatButton3;
    private BunifuFlatButton bunifuFlatButton4;
    public BunifuFlatButton bunifuFlatButton5;
    private ContextMenuStrip contextMenuStrip1;
    private ToolStripMenuItem executeToolStripMenuItem;
    private ToolStripMenuItem loadIntoEditorToolStripMenuItem;
    private ToolStripMenuItem deleteFileToolStripMenuItem;
    private ToolStripMenuItem changePathToolStripMenuItem;
    private ToolStripMenuItem reloadToolStripMenuItem;
    private BunifuFlatButton bunifuFlatButton6;
    private MenuStrip menuStrip1;
    private ToolStripMenuItem fileToolStripMenuItem;
    private ToolStripMenuItem injectToolStripMenuItem;
    private ToolStripMenuItem aboutToolStripMenuItem;
    private ToolStripMenuItem gamesToolStripMenuItem;
    private ToolStripMenuItem hotScriptsToolStripMenuItem;
    private ToolStripMenuItem openGuiToolStripMenuItem;
    private ToolStripMenuItem toolStripMenuItem1;
    private ToolStripMenuItem killRobloxToolStripMenuItem;
    private ToolStripMenuItem remoteSpyToolStripMenuItem;
    private ToolStripMenuItem toolStripMenuItem2;
    private ToolStripMenuItem toolStripMenuItem3;
    private System.Windows.Forms.Timer timer1;
    private ToolStripMenuItem toolStripMenuItem4;
    private ToolTip toolTip1;
    private ToolStripMenuItem toolStripMenuItem5;
    private ToolStripMenuItem toolStripMenuItem6;
    private ToolStripMenuItem toolStripMenuItem7;
    private Panel panel2;
    public Panel panel3;
    private ErrorProvider errorProvider1;
    private Button button1;
    private Button button2;
    private PictureBox pictureBox2;
    private ToolStripMenuItem toolStripMenuItem8;
    private ToolStripMenuItem toolStripMenuItem10;
    private ToolStripMenuItem unnamedESPToolStripMenuItem;
    public static int injectedPID = 0;
    public static RegistryKey SOFTWARE = Registry.CurrentUser.OpenSubKey(nameof (SOFTWARE), true);
    public static bool activated = false;
    public static bool launcherDetected = false;
    public static double timeout = 6.0;
    private krnl_monaco.EdgeEnum mEdge;
    private bool isonEdge;
    private int mWidth = 20;
    private bool mMouseDown;
    private bool heightUnchanged = true;
    private bool widthUnchanged = true;
    private ToolStripMenuItem cMDXToolStripMenuItem;
    private bool Anim_ATF_break;

    [DllImport("user32.dll", SetLastError = true)]
    internal static extern IntPtr FindWindowA(string lpClassName, string lpWindowName);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out int lpdwProcessId);

    [DllImport("user32.dll")]
    public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

    [DllImport("user32.dll")]
    public static extern bool ReleaseCapture();

    public void PopulateTree(object dir, TreeNode node)
    {
      try
      {
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__0 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__0 = CallSite<Func<CallSite, System.Type, object, DirectoryInfo>>.Create(Binder.InvokeConstructor(CSharpBinderFlags.None, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.IsStaticType, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj1 = (object) krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__0, typeof (DirectoryInfo), dir);
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__9 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__9 = CallSite<Func<CallSite, object, IEnumerable>>.Create(Binder.Convert(CSharpBinderFlags.None, typeof (IEnumerable), typeof (krnl_monaco)));
        }
        // ISSUE: reference to a compiler-generated field
        Func<CallSite, object, IEnumerable> target1 = krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__9.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Func<CallSite, object, IEnumerable>> p9 = krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__9;
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__1 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.None, "GetDirectories", (IEnumerable<System.Type>) null, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj2 = krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__1.Target((CallSite) krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__1, obj1);
        foreach (object obj3 in target1((CallSite) p9, obj2))
        {
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__3 == null)
          {
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__3 = CallSite<Func<CallSite, System.Type, object, TreeNode>>.Create(Binder.InvokeConstructor(CSharpBinderFlags.None, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.IsStaticType, (string) null),
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          Func<CallSite, System.Type, object, TreeNode> target2 = krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__3.Target;
          // ISSUE: reference to a compiler-generated field
          CallSite<Func<CallSite, System.Type, object, TreeNode>> p3 = krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__3;
          System.Type type = typeof (TreeNode);
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__2 == null)
          {
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__2 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "Name", typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          object obj4 = krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__2.Target((CallSite) krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__2, obj3);
          object obj5 = (object) target2((CallSite) p3, type, obj4);
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__4 == null)
          {
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__4 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          if ((krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__4.Target((CallSite) krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__4, (object) (node == null)) ? 1 : 0) == 0)
          {
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__5 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__5 = CallSite<Action<CallSite, TreeNodeCollection, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.ResultDiscarded, "Add", (IEnumerable<System.Type>) null, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null),
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__5.Target((CallSite) krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__5, node.Nodes, obj5);
          }
          else
          {
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__6 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__6 = CallSite<Action<CallSite, TreeNodeCollection, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.ResultDiscarded, "Add", (IEnumerable<System.Type>) null, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null),
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__6.Target((CallSite) krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__6, this.ScriptView.Nodes, obj5);
          }
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__8 == null)
          {
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__8 = CallSite<Action<CallSite, krnl_monaco, object, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.ResultDiscarded, nameof (PopulateTree), (IEnumerable<System.Type>) null, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[3]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null),
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          Action<CallSite, krnl_monaco, object, object> target3 = krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__8.Target;
          // ISSUE: reference to a compiler-generated field
          CallSite<Action<CallSite, krnl_monaco, object, object>> p8 = krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__8;
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__7 == null)
          {
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__7 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "FullName", typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          object obj6 = krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__7.Target((CallSite) krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__7, obj3);
          object obj7 = obj5;
          target3((CallSite) p8, this, obj6, obj7);
        }
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__17 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__17 = CallSite<Func<CallSite, object, IEnumerable>>.Create(Binder.Convert(CSharpBinderFlags.None, typeof (IEnumerable), typeof (krnl_monaco)));
        }
        // ISSUE: reference to a compiler-generated field
        Func<CallSite, object, IEnumerable> target4 = krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__17.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Func<CallSite, object, IEnumerable>> p17 = krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__17;
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__10 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__10 = CallSite<Func<CallSite, object, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.None, "GetFiles", (IEnumerable<System.Type>) null, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj8 = krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__10.Target((CallSite) krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__10, obj1);
        foreach (object obj9 in target4((CallSite) p17, obj8))
        {
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__12 == null)
          {
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__12 = CallSite<Func<CallSite, System.Type, object, TreeNode>>.Create(Binder.InvokeConstructor(CSharpBinderFlags.None, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.IsStaticType, (string) null),
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          Func<CallSite, System.Type, object, TreeNode> target5 = krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__12.Target;
          // ISSUE: reference to a compiler-generated field
          CallSite<Func<CallSite, System.Type, object, TreeNode>> p12 = krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__12;
          System.Type type = typeof (TreeNode);
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__11 == null)
          {
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__11 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "Name", typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          object obj10 = krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__11.Target((CallSite) krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__11, obj9);
          object obj11 = (object) target5((CallSite) p12, type, obj10);
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__14 == null)
          {
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__14 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          Func<CallSite, object, bool> target6 = krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__14.Target;
          // ISSUE: reference to a compiler-generated field
          CallSite<Func<CallSite, object, bool>> p14 = krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__14;
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__13 == null)
          {
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__13 = CallSite<Func<CallSite, object, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.NotEqual, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.Constant, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          object obj12 = krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__13.Target((CallSite) krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__13, (object) node, (object) null);
          if (target6((CallSite) p14, obj12))
          {
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__15 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__15 = CallSite<Action<CallSite, TreeNodeCollection, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.ResultDiscarded, "Add", (IEnumerable<System.Type>) null, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null),
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__15.Target((CallSite) krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__15, node.Nodes, obj11);
          }
          else
          {
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__16 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__16 = CallSite<Action<CallSite, TreeNodeCollection, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.ResultDiscarded, "Add", (IEnumerable<System.Type>) null, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null),
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__16.Target((CallSite) krnl_monaco.\u003C\u003Eo__75.\u003C\u003Ep__16, this.ScriptView.Nodes, obj11);
          }
        }
      }
      catch
      {
      }
    }

    private void ScriptLoading()
    {
      try
      {
        object obj1 = (object) Directory.Exists(Settings.Default.ScriptPath);
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__76.\u003C\u003Ep__1 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__76.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        Func<CallSite, object, bool> target = krnl_monaco.\u003C\u003Eo__76.\u003C\u003Ep__1.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Func<CallSite, object, bool>> p1 = krnl_monaco.\u003C\u003Eo__76.\u003C\u003Ep__1;
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__76.\u003C\u003Ep__0 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__76.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, object>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.Not, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj2 = krnl_monaco.\u003C\u003Eo__76.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__76.\u003C\u003Ep__0, obj1);
        if (target((CallSite) p1, obj2))
          Directory.CreateDirectory(Settings.Default.ScriptPath);
      }
      catch
      {
      }
      this.PopulateTree((object) Settings.Default.ScriptPath, (TreeNode) null);
    }

    public krnl_monaco()
    {
      AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(this.CurrentDomain_UnhandledException);
      this.InitializeComponent();
      this.panel3.Width = this.Width;
      MonacoCustomTabControl.Form1 = this;
      this.customTabControl1.ShowClosingButton = true;
    }

    private void shit()
    {
      while (true)
      {
        foreach (Process process in Process.GetProcesses())
        {
          try
          {
            System.Type type = (System.Type) null;
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__6 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__6 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            Func<CallSite, object, bool> target1 = krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__6.Target;
            // ISSUE: reference to a compiler-generated field
            CallSite<Func<CallSite, object, bool>> p6 = krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__6;
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__0 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.Constant, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            object obj1 = krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__0, (object) type, (object) null);
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__5 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__5 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsFalse, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            object obj2;
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            if (!krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__5.Target((CallSite) krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__5, obj1))
            {
              // ISSUE: reference to a compiler-generated field
              if (krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__4 == null)
              {
                // ISSUE: reference to a compiler-generated field
                krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__4 = CallSite<Func<CallSite, object, bool, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.BinaryOperationLogical, ExpressionType.And, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
                {
                  CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
                  CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
                }));
              }
              // ISSUE: reference to a compiler-generated field
              Func<CallSite, object, bool, object> target2 = krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__4.Target;
              // ISSUE: reference to a compiler-generated field
              CallSite<Func<CallSite, object, bool, object>> p4 = krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__4;
              object obj3 = obj1;
              // ISSUE: reference to a compiler-generated field
              if (krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__3 == null)
              {
                // ISSUE: reference to a compiler-generated field
                krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__3 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
                {
                  CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
                }));
              }
              // ISSUE: reference to a compiler-generated field
              Func<CallSite, object, bool> target3 = krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__3.Target;
              // ISSUE: reference to a compiler-generated field
              CallSite<Func<CallSite, object, bool>> p3 = krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__3;
              object obj4 = (object) !File.Exists(process.MainModule.FileName);
              // ISSUE: reference to a compiler-generated field
              if (krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__2 == null)
              {
                // ISSUE: reference to a compiler-generated field
                krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__2 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsFalse, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
                {
                  CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
                }));
              }
              object obj5;
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              if (!krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__2.Target((CallSite) krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__2, obj4))
              {
                // ISSUE: reference to a compiler-generated field
                if (krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__1 == null)
                {
                  // ISSUE: reference to a compiler-generated field
                  krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.BinaryOperationLogical, ExpressionType.And, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
                  {
                    CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
                    CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
                  }));
                }
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                obj5 = krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__1.Target((CallSite) krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__1, obj4, process.Id != Process.GetCurrentProcess().Id);
              }
              else
                obj5 = obj4;
              int num = target3((CallSite) p3, obj5) ? 1 : 0;
              obj2 = target2((CallSite) p4, obj3, num != 0);
            }
            else
              obj2 = obj1;
            if (target1((CallSite) p6, obj2))
            {
              process.Kill();
              return;
            }
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__8 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__8 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            Func<CallSite, object, bool> target4 = krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__8.Target;
            // ISSUE: reference to a compiler-generated field
            CallSite<Func<CallSite, object, bool>> p8 = krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__8;
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__7 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__7 = CallSite<Func<CallSite, object, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.Constant, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            object obj6 = krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__7.Target((CallSite) krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__7, (object) type, (object) null);
            if (target4((CallSite) p8, obj6))
            {
              try
              {
                string lower = process.MainModule.FileVersionInfo.FileDescription.ToLower();
                // ISSUE: reference to a compiler-generated field
                if (krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__12 == null)
                {
                  // ISSUE: reference to a compiler-generated field
                  krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__12 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
                  {
                    CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
                  }));
                }
                // ISSUE: reference to a compiler-generated field
                Func<CallSite, object, bool> target5 = krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__12.Target;
                // ISSUE: reference to a compiler-generated field
                CallSite<Func<CallSite, object, bool>> p12 = krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__12;
                // ISSUE: reference to a compiler-generated field
                if (krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__9 == null)
                {
                  // ISSUE: reference to a compiler-generated field
                  krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__9 = CallSite<Func<CallSite, object, string, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.NotEqual, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
                  {
                    CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
                    CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
                  }));
                }
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                object obj7 = krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__9.Target((CallSite) krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__9, (object) lower, "");
                // ISSUE: reference to a compiler-generated field
                if (krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__11 == null)
                {
                  // ISSUE: reference to a compiler-generated field
                  krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__11 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsFalse, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
                  {
                    CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
                  }));
                }
                object obj8;
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                if (!krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__11.Target((CallSite) krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__11, obj7))
                {
                  // ISSUE: reference to a compiler-generated field
                  if (krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__10 == null)
                  {
                    // ISSUE: reference to a compiler-generated field
                    krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__10 = CallSite<Func<CallSite, object, bool, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.BinaryOperationLogical, ExpressionType.And, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
                    {
                      CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
                      CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
                    }));
                  }
                  // ISSUE: reference to a compiler-generated field
                  // ISSUE: reference to a compiler-generated field
                  obj8 = krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__10.Target((CallSite) krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__10, obj7, "windowsformsapp107".IndexOf(lower) != -1 || lower.IndexOf("krnl") != -1 && (lower.IndexOf("bypass") != -1 || lower.IndexOf("keygen") != -1));
                }
                else
                  obj8 = obj7;
                if (target5((CallSite) p12, obj8))
                  process.Kill();
              }
              catch (Win32Exception ex)
              {
                type = ex.GetType();
              }
            }
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__14 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__14 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            Func<CallSite, object, bool> target6 = krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__14.Target;
            // ISSUE: reference to a compiler-generated field
            CallSite<Func<CallSite, object, bool>> p14 = krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__14;
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__13 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__13 = CallSite<Func<CallSite, object, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.Constant, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            object obj9 = krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__13.Target((CallSite) krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__13, (object) type, (object) null);
            if (target6((CallSite) p14, obj9))
            {
              try
              {
                string lower = process.MainModule.FileVersionInfo.FileDescription.ToLower();
                // ISSUE: reference to a compiler-generated field
                if (krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__18 == null)
                {
                  // ISSUE: reference to a compiler-generated field
                  krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__18 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
                  {
                    CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
                  }));
                }
                // ISSUE: reference to a compiler-generated field
                Func<CallSite, object, bool> target7 = krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__18.Target;
                // ISSUE: reference to a compiler-generated field
                CallSite<Func<CallSite, object, bool>> p18 = krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__18;
                // ISSUE: reference to a compiler-generated field
                if (krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__15 == null)
                {
                  // ISSUE: reference to a compiler-generated field
                  krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__15 = CallSite<Func<CallSite, object, string, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.NotEqual, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
                  {
                    CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
                    CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
                  }));
                }
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                object obj10 = krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__15.Target((CallSite) krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__15, (object) lower, "");
                // ISSUE: reference to a compiler-generated field
                if (krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__17 == null)
                {
                  // ISSUE: reference to a compiler-generated field
                  krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__17 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsFalse, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
                  {
                    CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
                  }));
                }
                object obj11;
                // ISSUE: reference to a compiler-generated field
                // ISSUE: reference to a compiler-generated field
                if (!krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__17.Target((CallSite) krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__17, obj10))
                {
                  // ISSUE: reference to a compiler-generated field
                  if (krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__16 == null)
                  {
                    // ISSUE: reference to a compiler-generated field
                    krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__16 = CallSite<Func<CallSite, object, bool, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.BinaryOperationLogical, ExpressionType.And, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
                    {
                      CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
                      CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
                    }));
                  }
                  // ISSUE: reference to a compiler-generated field
                  // ISSUE: reference to a compiler-generated field
                  obj11 = krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__16.Target((CallSite) krnl_monaco.\u003C\u003Eo__78.\u003C\u003Ep__16, obj10, "windowsformsapp107".IndexOf(lower) != -1 || lower.IndexOf("krnl") != -1 && (lower.IndexOf("bypass") != -1 || lower.IndexOf("keygen") != -1));
                }
                else
                  obj11 = obj10;
                if (target7((CallSite) p18, obj11))
                  process.Kill();
              }
              catch (InvalidOperationException ex)
              {
                ex.GetType();
              }
            }
          }
          catch
          {
          }
        }
        Task.Delay(1000).GetAwaiter().GetResult();
      }
    }

    private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
    {
      Settings.Default.monaco = false;
      Settings.Default.Save();
      Exception exceptionObject = (Exception) e.ExceptionObject;
      File.WriteAllText("error.txt", string.Join("\n", new string[7]
      {
        "Message: " + exceptionObject.Message,
        "StackTrace: " + exceptionObject.StackTrace,
        "Source: " + exceptionObject.Source,
        "TargetSite: " + exceptionObject.TargetSite?.ToString(),
        "HResult: " + exceptionObject.HResult.ToString(),
        "HelpLink: " + exceptionObject.HelpLink,
        "Values: [ " + string.Join("\n", (object) exceptionObject.Data.Values) + " ]"
      }));
      int num = (int) MessageBox.Show("Send `error.txt` to krnl server", "Caught an oopsies!");
      DialogResult dialogResult = MessageBox.Show("Click `Yes` if you want to get an invite to krnl discord server.", "Krnl Prompt", MessageBoxButtons.YesNo);
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__79.\u003C\u003Ep__1 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__79.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target = krnl_monaco.\u003C\u003Eo__79.\u003C\u003Ep__1.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p1 = krnl_monaco.\u003C\u003Eo__79.\u003C\u003Ep__1;
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__79.\u003C\u003Ep__0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__79.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, DialogResult, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj = krnl_monaco.\u003C\u003Eo__79.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__79.\u003C\u003Ep__0, (object) dialogResult, DialogResult.Yes);
      if (target((CallSite) p1, obj))
        Process.Start("https://krnl.ca/invite.php");
      Process.Start(Process.GetCurrentProcess().MainModule.FileName);
    }

    private void Form1_Load(object sender1, EventArgs e)
    {
      for (int index = 0; index < this.hotScriptsToolStripMenuItem.DropDownItems.Count; ++index)
      {
        ToolStripItem dropDownItem = this.hotScriptsToolStripMenuItem.DropDownItems[index];
        if (dropDownItem.Text == "Owl Hub" || dropDownItem.Text == "Galaxy Hub")
        {
          dropDownItem.Visible = false;
          dropDownItem.Enabled = false;
        }
      }
      if (!Directory.Exists("bin/tabs"))
        Directory.CreateDirectory("bin/tabs");
      if (Directory.GetFiles("bin/tabs").Length != 0)
      {
        for (int index = 0; index < Directory.GetFiles("bin/tabs").Length / 2; ++index)
        {
          int num = this.customTabControl1.TabPages.Count - 2;
          using (FileStream fileStream = new FileStream(string.Format("bin/tabs/{0}_source.lua", (object) index), FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
          {
            using (StreamReader streamReader = new StreamReader((Stream) fileStream, Encoding.UTF8))
            {
              this.customTabControl1.addScript(streamReader.ReadToEnd());
              streamReader.Close();
            }
          }
        }
        for (int index = 0; index < Directory.GetFiles("bin/tabs").Length / 2; ++index)
        {
          this.customTabControl1.addnewtab();
          int count = this.customTabControl1.TabPages.Count - 2;
          int curr = index;
          if (index + 1 == Directory.GetFiles("bin/tabs").Length / 2)
            this.customTabControl1.GetWorkingTextEditor().LoadingStateChanged += (EventHandler<LoadingStateChangedEventArgs>) ((sender7, args) =>
            {
              if (args.IsLoading)
                return;
              try
              {
                using (FileStream fileStream = new FileStream(string.Format("bin/tabs/{0}_name.txt", (object) curr), FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                  using (StreamReader streamReader = new StreamReader((Stream) fileStream, Encoding.UTF8))
                  {
                    this.customTabControl1.TabPages[count].Text = streamReader.ReadToEnd();
                    streamReader.Close();
                  }
                }
                using (FileStream fileStream = new FileStream(string.Format("bin/tabs/{0}_source.lua", (object) curr), FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                  using (StreamReader streamReader = new StreamReader((Stream) fileStream, Encoding.UTF8))
                  {
                    WebBrowserExtensions.ExecuteScriptAsync((IWebBrowser) this.customTabControl1.GetWorkingTextEditor(), "SetText", new object[1]
                    {
                      (object) streamReader.ReadToEnd()
                    });
                    streamReader.Close();
                  }
                }
              }
              catch
              {
              }
            });
        }
      }
      else
        this.customTabControl1.addnewtab();
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__80.\u003C\u003Ep__0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__80.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__80.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__80.\u003C\u003Ep__0, (object) !Directory.Exists(Settings.Default.ScriptPath)))
        Settings.Default.ScriptPath = Environment.CurrentDirectory + "\\scripts";
      this.menuStrip1.Renderer = (ToolStripRenderer) new ToolStripProfessionalRenderer((ProfessionalColorTable) new krnl_monaco.BrowserColors());
      this.ScriptLoading();
      this.Anim_ATF_break = true;
      this.anim_AwaitingTaskFinish();
    }

    private async void button1_Click(object sender, EventArgs e)
    {
      krnl_monaco krnlMonaco;
      for (krnlMonaco = this; krnlMonaco.Opacity > 0.0; krnlMonaco.Opacity -= 0.1)
        await Task.Delay(10);
      string[] files = Directory.GetFiles("bin/tabs");
      for (int index = 0; index < (files.Length != 0 ? files.Length / 2 : 0); ++index)
      {
        if (krnlMonaco.customTabControl1.TabPages.Count <= index + 1)
        {
          try
          {
            File.Delete(string.Format("bin/tabs/{0}_name.txt", (object) index));
            File.Delete(string.Format("bin/tabs/{0}_source.lua", (object) index));
          }
          catch
          {
          }
        }
      }
      string str = WebBrowserExtensions.EvaluateScriptAsync((IWebBrowser) krnlMonaco.customTabControl1.GetWorkingTextEditor(), "GetText", new object[0]).GetAwaiter().GetResult().Result.ToString();
      Program.tabScripts[krnlMonaco.customTabControl1.realIndex] = str != "-- Krnl Monaco" ? str : Program.tabScripts[krnlMonaco.customTabControl1.realIndex];
      for (int index = 0; index < krnlMonaco.customTabControl1.TabCount - 1; ++index)
      {
        File.WriteAllText(string.Format("bin/tabs/{0}_name.txt", (object) index), krnlMonaco.customTabControl1.TabPages[index].Text);
        File.WriteAllText(string.Format("bin/tabs/{0}_source.lua", (object) index), Program.tabScripts[index]);
      }
      Environment.Exit(Environment.ExitCode);
    }

    private void button2_Click(object sender, EventArgs e) => this.WindowState = FormWindowState.Minimized;

    private void panel1_Paint(object sender, PaintEventArgs e)
    {
    }

    private void panel1_MouseMove(object sender, MouseEventArgs e)
    {
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__84.\u003C\u003Ep__1 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__84.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target = krnl_monaco.\u003C\u003Eo__84.\u003C\u003Ep__1.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p1 = krnl_monaco.\u003C\u003Eo__84.\u003C\u003Ep__1;
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__84.\u003C\u003Ep__0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__84.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, MouseButtons, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj = krnl_monaco.\u003C\u003Eo__84.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__84.\u003C\u003Ep__0, (object) e.Button, MouseButtons.Left);
      if (!target((CallSite) p1, obj))
        return;
      krnl_monaco.ReleaseCapture();
      krnl_monaco.SendMessage(this.Handle, 161, 2, 0);
    }

    private void tabPage1_Click(object sender, EventArgs e)
    {
    }

    private void closeToolStripMenuItem_Click(object sender, EventArgs e) => this.customTabControl1.CloseTab(this.customTabControl1.contextTab);

    private void clearToolStripMenuItem_Click(object sender, EventArgs e) => WebBrowserExtensions.ExecuteScriptAsync((IWebBrowser) this.customTabControl1.GetWorkingTextEditor(), "SetText", new object[1]
    {
      (object) ""
    });

    private void openIntoToolStripMenuItem_Click(object sender, EventArgs e)
    {
      TabPage contextTab = this.customTabControl1.contextTab;
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__88.\u003C\u003Ep__1 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__88.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target1 = krnl_monaco.\u003C\u003Eo__88.\u003C\u003Ep__1.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p1 = krnl_monaco.\u003C\u003Eo__88.\u003C\u003Ep__1;
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__88.\u003C\u003Ep__0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__88.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.Constant, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj1 = krnl_monaco.\u003C\u003Eo__88.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__88.\u003C\u003Ep__0, (object) contextTab, (object) null);
      if (target1((CallSite) p1, obj1))
        throw new Exception("SELECTED TAB NOT FOUND");
      using (OpenFileDialog openFileDialog = new OpenFileDialog())
      {
        openFileDialog.CheckFileExists = true;
        openFileDialog.Filter = "Script Files (*.txt, *.lua)|*.txt;*.lua|All Files (*.*)|*.*";
        openFileDialog.RestoreDirectory = true;
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__88.\u003C\u003Ep__3 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__88.\u003C\u003Ep__3 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        Func<CallSite, object, bool> target2 = krnl_monaco.\u003C\u003Eo__88.\u003C\u003Ep__3.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Func<CallSite, object, bool>> p3 = krnl_monaco.\u003C\u003Eo__88.\u003C\u003Ep__3;
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__88.\u003C\u003Ep__2 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__88.\u003C\u003Ep__2 = CallSite<Func<CallSite, object, DialogResult, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj2 = krnl_monaco.\u003C\u003Eo__88.\u003C\u003Ep__2.Target((CallSite) krnl_monaco.\u003C\u003Eo__88.\u003C\u003Ep__2, (object) openFileDialog.ShowDialog(), DialogResult.OK);
        if (!target2((CallSite) p3, obj2))
          return;
        contextTab.Text = Path.GetFileNameWithoutExtension(openFileDialog.SafeFileName);
        object obj3 = (object) File.ReadAllText(openFileDialog.FileName);
        try
        {
          WebBrowserExtensions.ExecuteScriptAsync((IWebBrowser) (this.customTabControl1.contextTab.Controls[0] as ChromiumWebBrowser), "SetText", new object[1]
          {
            obj3
          });
        }
        catch
        {
        }
      }
    }

    private void saveToolStripMenuItem_Click(object sender, EventArgs e)
    {
      TabPage contextTab = this.customTabControl1.contextTab;
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__89.\u003C\u003Ep__1 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__89.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target = krnl_monaco.\u003C\u003Eo__89.\u003C\u003Ep__1.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p1 = krnl_monaco.\u003C\u003Eo__89.\u003C\u003Ep__1;
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__89.\u003C\u003Ep__0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__89.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.Constant, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj = krnl_monaco.\u003C\u003Eo__89.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__89.\u003C\u003Ep__0, (object) contextTab, (object) null);
      if (target((CallSite) p1, obj))
        throw new Exception("TAB NOT FOUND");
      contextTab.Text = this.customTabControl1.OpenSaveDialog(contextTab, WebBrowserExtensions.EvaluateScriptAsync((IWebBrowser) this.customTabControl1.GetWorkingTextEditor(), "GetText", new object[0]).GetAwaiter().GetResult().Result.ToString());
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern bool WaitNamedPipe(string name, int timeout);

    public static bool findpipe(string pipeName)
    {
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__91.\u003C\u003Ep__2 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__91.\u003C\u003Ep__2 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target = krnl_monaco.\u003C\u003Eo__91.\u003C\u003Ep__2.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p2 = krnl_monaco.\u003C\u003Eo__91.\u003C\u003Ep__2;
      object obj1 = (object) !krnl_monaco.WaitNamedPipe(Path.GetFullPath("\\\\.\\pipe\\" + pipeName), 0);
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__91.\u003C\u003Ep__1 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__91.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsFalse, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      object obj2;
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (!krnl_monaco.\u003C\u003Eo__91.\u003C\u003Ep__1.Target((CallSite) krnl_monaco.\u003C\u003Eo__91.\u003C\u003Ep__1, obj1))
      {
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__91.\u003C\u003Ep__0 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__91.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, bool, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.BinaryOperationLogical, ExpressionType.And, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        obj2 = krnl_monaco.\u003C\u003Eo__91.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__91.\u003C\u003Ep__0, obj1, Marshal.GetLastWin32Error() == 0 || Marshal.GetLastWin32Error() == 2);
      }
      else
        obj2 = obj1;
      return !target((CallSite) p2, obj2);
    }

    public static void pipeshit(string script)
    {
      try
      {
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__92.\u003C\u003Ep__0 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__92.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__92.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__92.\u003C\u003Ep__0, (object) krnl_monaco.findpipe("krnlpipe")))
        {
          using (NamedPipeClientStream pipeClientStream = new NamedPipeClientStream(".", "krnlpipe", PipeDirection.Out))
          {
            pipeClientStream.Connect();
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__92.\u003C\u003Ep__1 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__92.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__92.\u003C\u003Ep__1.Target((CallSite) krnl_monaco.\u003C\u003Eo__92.\u003C\u003Ep__1, (object) !pipeClientStream.IsConnected))
              throw new IOException("Failed To Connect To Pipe....");
            StreamWriter streamWriter = new StreamWriter((Stream) pipeClientStream, Encoding.Default, 999999);
            streamWriter.Write(script);
            streamWriter.Dispose();
          }
        }
        else
        {
          int num = (int) MessageBox.Show("Please Inject To Execute Scripts", "krnl");
        }
      }
      catch (Exception ex)
      {
      }
    }

    public static void Pipe(string script)
    {
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__93.\u003C\u003Ep__0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__93.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__93.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__93.\u003C\u003Ep__0, (object) krnl_monaco.findpipe("krnlpipe")))
      {
        krnl_monaco.pipeshit(script);
      }
      else
      {
        int num = (int) MessageBox.Show("Please Inject To Execute Scripts", "krnl");
      }
    }

    private void bunifuFlatButton1_Click(object sender, EventArgs e)
    {
      try
      {
        krnl_monaco.Pipe(WebBrowserExtensions.EvaluateScriptAsync((IWebBrowser) this.customTabControl1.GetWorkingTextEditor(), "GetText", new object[0]).GetAwaiter().GetResult().Result.ToString());
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(ex.ToString());
      }
    }

    private void bunifuFlatButton2_Click(object sender, EventArgs e) => WebBrowserExtensions.ExecuteScriptAsync((IWebBrowser) this.customTabControl1.GetWorkingTextEditor(), "SetText", new object[1]
    {
      (object) ""
    });

    private void bunifuFlatButton3_Click(object sender, EventArgs e) => this.customTabControl1.OpenFileDialog(this.customTabControl1.SelectedTab);

    private void bunifuFlatButton4_Click(object sender, EventArgs e)
    {
      this.ScriptView.Nodes.Clear();
      this.ScriptLoading();
      this.customTabControl1.OpenSaveDialog(this.customTabControl1.SelectedTab, "");
    }

    private void injectToolStripMenuItem_Click(object sender, EventArgs e)
    {
    }

    private void bunifuFlatButton5_Click(object sender, EventArgs e) => new Thread((ParameterizedThreadStart) (_param1 =>
    {
      try
      {
        Process[] processesByName = Process.GetProcessesByName("RobloxPlayerBeta");
        IntPtr windowA = krnl_monaco.FindWindowA("WINDOWSCLIENT", "Roblox");
        int lpdwProcessId = 0;
        int windowThreadProcessId = (int) krnl_monaco.GetWindowThreadProcessId(windowA, out lpdwProcessId);
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__99.\u003C\u003Ep__1 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__99.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        Func<CallSite, object, bool> target = krnl_monaco.\u003C\u003Eo__99.\u003C\u003Ep__1.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Func<CallSite, object, bool>> p1 = krnl_monaco.\u003C\u003Eo__99.\u003C\u003Ep__1;
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__99.\u003C\u003Ep__0 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__99.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, IntPtr, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.NotEqual, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj = krnl_monaco.\u003C\u003Eo__99.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__99.\u003C\u003Ep__0, (object) windowA, IntPtr.Zero);
        if (target((CallSite) p1, obj))
        {
          List<string> list = ((IEnumerable<string>) processesByName[0].MainModule.FileName.Split('\\')).ToList<string>();
          list.Remove("RobloxPlayerBeta.exe");
          Program.writeToDir(string.Join("\\", list.ToArray()));
          try
          {
            this.injectdll((object) "krnl.dll", lpdwProcessId);
            this.anim_CompletedTask();
          }
          catch
          {
          }
        }
        else
        {
          int num = (int) MessageBox.Show("Roblox Process Not Found", "Krnl");
        }
      }
      catch
      {
        int num = (int) MessageBox.Show("Caught an unknown error while injecting!");
      }
    })).Start();

    private void executeToolStripMenuItem_Click(object sender, EventArgs e)
    {
      try
      {
        object fullPath = (object) this.ScriptView.SelectedNode.FullPath;
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__100.\u003C\u003Ep__1 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__100.\u003C\u003Ep__1 = CallSite<Func<CallSite, System.Type, object, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.None, "ReadAllText", (IEnumerable<System.Type>) null, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.IsStaticType, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        Func<CallSite, System.Type, object, object> target = krnl_monaco.\u003C\u003Eo__100.\u003C\u003Ep__1.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Func<CallSite, System.Type, object, object>> p1 = krnl_monaco.\u003C\u003Eo__100.\u003C\u003Ep__1;
        System.Type type = typeof (File);
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__100.\u003C\u003Ep__0 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__100.\u003C\u003Ep__0 = CallSite<Func<CallSite, string, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Add, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj1 = krnl_monaco.\u003C\u003Eo__100.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__100.\u003C\u003Ep__0, Settings.Default.ScriptPath + "//", fullPath);
        object obj2 = target((CallSite) p1, type, obj1);
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__100.\u003C\u003Ep__2 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__100.\u003C\u003Ep__2 = CallSite<Action<CallSite, krnl_monaco, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.InvokeSimpleName | CSharpBinderFlags.ResultDiscarded, "Pipe", (IEnumerable<System.Type>) null, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__100.\u003C\u003Ep__2.Target((CallSite) krnl_monaco.\u003C\u003Eo__100.\u003C\u003Ep__2, this, obj2);
      }
      catch
      {
      }
    }

    private void loadIntoEditorToolStripMenuItem_Click(object sender, EventArgs e)
    {
      try
      {
        object fullPath = (object) this.ScriptView.SelectedNode.FullPath;
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__101.\u003C\u003Ep__1 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__101.\u003C\u003Ep__1 = CallSite<Func<CallSite, System.Type, object, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.None, "ReadAllText", (IEnumerable<System.Type>) null, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.IsStaticType, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        Func<CallSite, System.Type, object, object> target = krnl_monaco.\u003C\u003Eo__101.\u003C\u003Ep__1.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Func<CallSite, System.Type, object, object>> p1 = krnl_monaco.\u003C\u003Eo__101.\u003C\u003Ep__1;
        System.Type type = typeof (File);
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__101.\u003C\u003Ep__0 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__101.\u003C\u003Ep__0 = CallSite<Func<CallSite, string, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Add, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj1 = krnl_monaco.\u003C\u003Eo__101.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__101.\u003C\u003Ep__0, Settings.Default.ScriptPath + "//", fullPath);
        object obj2 = target((CallSite) p1, type, obj1);
        WebBrowserExtensions.ExecuteScriptAsync((IWebBrowser) this.customTabControl1.GetWorkingTextEditor(), "SetText", new object[1]
        {
          obj2
        });
      }
      catch (Exception ex)
      {
      }
    }

    private void deleteFileToolStripMenuItem_Click(object sender, EventArgs e)
    {
      try
      {
        object fullPath = (object) this.ScriptView.SelectedNode.FullPath;
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__102.\u003C\u003Ep__1 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__102.\u003C\u003Ep__1 = CallSite<Action<CallSite, System.Type, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.ResultDiscarded, "Delete", (IEnumerable<System.Type>) null, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.IsStaticType, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        Action<CallSite, System.Type, object> target = krnl_monaco.\u003C\u003Eo__102.\u003C\u003Ep__1.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Action<CallSite, System.Type, object>> p1 = krnl_monaco.\u003C\u003Eo__102.\u003C\u003Ep__1;
        System.Type type = typeof (File);
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__102.\u003C\u003Ep__0 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__102.\u003C\u003Ep__0 = CallSite<Func<CallSite, string, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Add, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj = krnl_monaco.\u003C\u003Eo__102.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__102.\u003C\u003Ep__0, Settings.Default.ScriptPath + "//", fullPath);
        target((CallSite) p1, type, obj);
      }
      catch (Exception ex)
      {
      }
    }

    private void changePathToolStripMenuItem_Click(object sender, EventArgs e)
    {
      try
      {
        object obj1 = (object) new FolderBrowserDialog();
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__11 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__11 = CallSite<Func<CallSite, object, IDisposable>>.Create(Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof (IDisposable), typeof (krnl_monaco)));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        using (krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__11.Target((CallSite) krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__11, obj1))
        {
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__1 == null)
          {
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, DialogResult, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          Func<CallSite, object, DialogResult, object> target1 = krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__1.Target;
          // ISSUE: reference to a compiler-generated field
          CallSite<Func<CallSite, object, DialogResult, object>> p1 = krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__1;
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__0 == null)
          {
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.None, "ShowDialog", (IEnumerable<System.Type>) null, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          object obj2 = krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__0, obj1);
          object obj3 = target1((CallSite) p1, obj2, DialogResult.OK);
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__6 == null)
          {
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__6 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsFalse, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          object obj4;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          if (!krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__6.Target((CallSite) krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__6, obj3))
          {
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__5 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__5 = CallSite<Func<CallSite, object, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.BinaryOperationLogical, ExpressionType.And, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            Func<CallSite, object, object, object> target2 = krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__5.Target;
            // ISSUE: reference to a compiler-generated field
            CallSite<Func<CallSite, object, object, object>> p5 = krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__5;
            object obj5 = obj3;
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__4 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__4 = CallSite<Func<CallSite, object, object>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.Not, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            Func<CallSite, object, object> target3 = krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__4.Target;
            // ISSUE: reference to a compiler-generated field
            CallSite<Func<CallSite, object, object>> p4 = krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__4;
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__3 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__3 = CallSite<Func<CallSite, System.Type, object, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.None, "IsNullOrWhiteSpace", (IEnumerable<System.Type>) null, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.IsStaticType, (string) null),
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            Func<CallSite, System.Type, object, object> target4 = krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__3.Target;
            // ISSUE: reference to a compiler-generated field
            CallSite<Func<CallSite, System.Type, object, object>> p3 = krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__3;
            System.Type type = typeof (string);
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__2 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__2 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "SelectedPath", typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            object obj6 = krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__2.Target((CallSite) krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__2, obj1);
            object obj7 = target4((CallSite) p3, type, obj6);
            object obj8 = target3((CallSite) p4, obj7);
            obj4 = target2((CallSite) p5, obj5, obj8);
          }
          else
            obj4 = obj3;
          object obj9 = obj4;
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__7 == null)
          {
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__7 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__7.Target((CallSite) krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__7, obj9))
          {
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__8 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__8 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "SelectedPath", typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            this.ScriptPath = krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__8.Target((CallSite) krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__8, obj1);
            // ISSUE: variable of a compiler-generated type
            Settings settings = Settings.Default;
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__10 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__10 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.None, typeof (string), typeof (krnl_monaco)));
            }
            // ISSUE: reference to a compiler-generated field
            Func<CallSite, object, string> target5 = krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__10.Target;
            // ISSUE: reference to a compiler-generated field
            CallSite<Func<CallSite, object, string>> p10 = krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__10;
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__9 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__9 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "SelectedPath", typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            object obj10 = krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__9.Target((CallSite) krnl_monaco.\u003C\u003Eo__103.\u003C\u003Ep__9, obj1);
            string str = target5((CallSite) p10, obj10);
            settings.ScriptPath = str;
            Settings.Default.Save();
          }
        }
        this.ScriptView.Nodes.Clear();
        this.ScriptLoading();
      }
      catch
      {
      }
    }

    private void reloadToolStripMenuItem_Click(object sender, EventArgs e)
    {
      this.ScriptView.Nodes.Clear();
      this.ScriptLoading();
    }

    private void ScriptView_AfterSelect(object sender, TreeViewEventArgs e)
    {
    }

    private void customTabControl1_SelectedIndexChanged(object sender, EventArgs e)
    {
    }

    private void renameToolStripMenuItem_Click(object sender, EventArgs e)
    {
    }

    private void openGuiToolStripMenuItem_Click(object sender, EventArgs e) => krnl_monaco.Pipe("loadstring(game:HttpGet('https://pastebin.com/raw/UXmbai5q', true))()");

    private void toolStripMenuItem1_Click(object sender, EventArgs e) => krnl_monaco.Pipe("loadstring(game:HttpGet('https://raw.githubusercontent.com/CriShoux/OwlHub/master/OwlHub.txt'))();");

    private void toolStripMenuItem2_Click(object sender, EventArgs e) => krnl_monaco.Pipe("if game:GetService'CoreGui':FindFirstChild'Dex'then game:GetService'CoreGui'.Dex:Destroy()end;math.randomseed(tick())local a={}for b=48,57 do table.insert(a,string.char(b))end;for b=65,90 do table.insert(a,string.char(b))end;for b=97,122 do table.insert(a,string.char(b))end;function RandomCharacters(c)if c>0 then return RandomCharacters(c-1)..a[math.random(1,#a)]else return''end end;local d=game:GetObjects('rbxassetid://3567096419')[1]d.Name=RandomCharacters(math.random(5,20))d.Parent=game:GetService('CoreGui')local function e(f,g)local function h(i,j)local k={}local l={script=j}local m={}m.__index=function(n,o)if l[o]==nil then return getfenv()[o]else return l[o]end end;m.__newindex=function(n,o,p)if l[o]==nil then getfenv()[o]=p else l[o]=p end end;setmetatable(k,m)setfenv(i,k)return i end;local function q(j)if j.ClassName=='Script'or j.ClassName=='LocalScript'then spawn(function()h(loadstring(j.Source,'='..j:GetFullName()),j)()end)end;for b,r in pairs(j:GetChildren())do q(r)end end;q(f)end;e(d)");

    private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
    {
    }

    private void bunifuFlatButton6_Click(object sender, EventArgs e)
    {
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__112.\u003C\u003Ep__1 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__112.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target = krnl_monaco.\u003C\u003Eo__112.\u003C\u003Ep__1.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p1 = krnl_monaco.\u003C\u003Eo__112.\u003C\u003Ep__1;
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__112.\u003C\u003Ep__0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__112.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.NotEqual, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj = krnl_monaco.\u003C\u003Eo__112.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__112.\u003C\u003Ep__0, (object) Application.OpenForms.OfType<settings>().Count<settings>(), 1);
      if (!target((CallSite) p1, obj))
        return;
      new settings((Form) this).Show();
      Application.OpenForms.OfType<settings>().First<settings>().SetDesktopLocation(this.Location.X + this.Size.Width + 5, this.Location.Y);
    }

    private void gamesToolStripMenuItem_Click_1(object sender, EventArgs e)
    {
      int num = (int) MessageBox.Show("Disabled as most scripts are patched.");
    }

    private void aboutToolStripMenuItem_Click_1(object sender, EventArgs e)
    {
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__114.\u003C\u003Ep__1 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__114.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target = krnl_monaco.\u003C\u003Eo__114.\u003C\u003Ep__1.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p1 = krnl_monaco.\u003C\u003Eo__114.\u003C\u003Ep__1;
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__114.\u003C\u003Ep__0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__114.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.NotEqual, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj = krnl_monaco.\u003C\u003Eo__114.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__114.\u003C\u003Ep__0, (object) Application.OpenForms.OfType<About>().Count<About>(), 1);
      if (!target((CallSite) p1, obj))
        return;
      new About().Show();
      Application.OpenForms.OfType<About>().First<About>().SetDesktopLocation(this.Location.X + this.Size.Width + 5, this.Location.Y);
    }

    private void injectToolStripMenuItem_Click_1(object sender, EventArgs e)
    {
      IntPtr windowA = krnl_monaco.FindWindowA("WINDOWSCLIENT", "Roblox");
      Process[] processesByName = Process.GetProcessesByName("RobloxPlayerBeta");
      int lpdwProcessId = 0;
      int windowThreadProcessId = (int) krnl_monaco.GetWindowThreadProcessId(windowA, out lpdwProcessId);
      for (int index = 0; index < processesByName.Length; ++index)
      {
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__115.\u003C\u003Ep__1 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__115.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        Func<CallSite, object, bool> target = krnl_monaco.\u003C\u003Eo__115.\u003C\u003Ep__1.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Func<CallSite, object, bool>> p1 = krnl_monaco.\u003C\u003Eo__115.\u003C\u003Ep__1;
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__115.\u003C\u003Ep__0 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__115.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.NotEqual, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj = krnl_monaco.\u003C\u003Eo__115.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__115.\u003C\u003Ep__0, (object) processesByName[index].Id, lpdwProcessId);
        if (target((CallSite) p1, obj))
          processesByName[index].Kill();
      }
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__115.\u003C\u003Ep__3 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__115.\u003C\u003Ep__3 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target1 = krnl_monaco.\u003C\u003Eo__115.\u003C\u003Ep__3.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p3 = krnl_monaco.\u003C\u003Eo__115.\u003C\u003Ep__3;
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__115.\u003C\u003Ep__2 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__115.\u003C\u003Ep__2 = CallSite<Func<CallSite, object, IntPtr, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.NotEqual, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj1 = krnl_monaco.\u003C\u003Eo__115.\u003C\u003Ep__2.Target((CallSite) krnl_monaco.\u003C\u003Eo__115.\u003C\u003Ep__2, (object) windowA, IntPtr.Zero);
      if (target1((CallSite) p3, obj1))
      {
        List<string> list = ((IEnumerable<string>) processesByName[0].MainModule.FileName.Split('\\')).ToList<string>();
        list.Remove("RobloxPlayerBeta.exe");
        Program.writeToDir(string.Join("\\", list.ToArray()));
        string[] strArray = new string[1]{ "krnl" };
        foreach (string str in strArray)
        {
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__115.\u003C\u003Ep__4 == null)
          {
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__115.\u003C\u003Ep__4 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          if ((krnl_monaco.\u003C\u003Eo__115.\u003C\u003Ep__4.Target((CallSite) krnl_monaco.\u003C\u003Eo__115.\u003C\u003Ep__4, (object) !this.injectdll((object) (str + ".dll"), lpdwProcessId)) ? 1 : 0) != 0)
            break;
          Task.Delay(10).GetAwaiter().GetResult();
          this.anim_CompletedTask();
        }
      }
      else
      {
        int num = (int) MessageBox.Show("Roblox Process Not Found", "Krnl");
      }
    }

    private void openGuiToolStripMenuItem_Click_1(object sender, EventArgs e) => krnl_monaco.Pipe("loadstring(game:HttpGet('https://pastebin.com/raw/UXmbai5q', true))()");

    private void toolStripMenuItem1_Click_1(object sender, EventArgs e) => krnl_monaco.Pipe("loadstring(game:HttpGet('https://raw.githubusercontent.com/CriShoux/OwlHub/master/OwlHub.txt'))();");

    private void killRobloxToolStripMenuItem_Click(object sender, EventArgs e)
    {
      Process[] processesByName = Process.GetProcessesByName("RobloxPlayerBeta");
      int num1 = 0;
      for (int index = 0; index < processesByName.Length; ++index)
      {
        processesByName[index].Kill();
        ++num1;
      }
      int num2 = (int) MessageBox.Show(string.Format("Terminated {0} Process", (object) num1), "krnl");
    }

    private void krnl_FormClosing(object sender, FormClosingEventArgs e)
    {
      string[] files = Directory.GetFiles("bin/tabs");
      for (int index = 0; index < (files.Length != 0 ? files.Length / 2 : 0); ++index)
      {
        if (this.customTabControl1.TabPages.Count <= index + 1)
        {
          try
          {
            File.Delete(string.Format("bin/tabs/{0}_name.txt", (object) index));
            File.Delete(string.Format("bin/tabs/{0}_source.lua", (object) index));
          }
          catch
          {
          }
        }
      }
      string str = WebBrowserExtensions.EvaluateScriptAsync((IWebBrowser) this.customTabControl1.GetWorkingTextEditor(), "GetText", new object[0]).GetAwaiter().GetResult().Result.ToString();
      Program.tabScripts[this.customTabControl1.realIndex] = str != "-- Krnl Monaco" ? str : Program.tabScripts[this.customTabControl1.realIndex];
      for (int index = 0; index < this.customTabControl1.TabCount - 1; ++index)
      {
        File.WriteAllText(string.Format("bin/tabs/{0}_name.txt", (object) index), this.customTabControl1.TabPages[index].Text);
        File.WriteAllText(string.Format("bin/tabs/{0}_source.lua", (object) index), Program.tabScripts[index]);
      }
      Environment.Exit(Environment.ExitCode);
    }

    private async void krnl_Deactivate(object sender, EventArgs e)
    {
    }

    protected override async void OnActivated(EventArgs e)
    {
      krnl_monaco krnlMonaco = this;
      krnl_monaco.activated = true;
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__121.\u003C\u003Ep__0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__121.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__121.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__121.\u003C\u003Ep__0, (object) Settings.Default.fadein_out_opacity))
      {
        for (; krnlMonaco.Opacity < 1.0 && krnl_monaco.activated; krnlMonaco.Opacity += 0.05)
          await Task.Delay(10);
      }
      else
        krnlMonaco.Opacity = 1.0;
    }

    protected override async void OnDeactivate(EventArgs e)
    {
      krnl_monaco krnlMonaco = this;
      krnl_monaco.activated = false;
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__122.\u003C\u003Ep__0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__122.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__122.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__122.\u003C\u003Ep__0, (object) Settings.Default.fadein_out_opacity))
      {
        for (; krnlMonaco.Opacity > 0.5 && !krnl_monaco.activated; krnlMonaco.Opacity -= 0.05)
          await Task.Delay(10);
      }
      else
        krnlMonaco.Opacity = 1.0;
    }

    private async void krnl_Activated(object sender, EventArgs e)
    {
    }

    private void gameSenseToolStripMenuItem_Click(object sender, EventArgs e) => krnl_monaco.Pipe("loadstring(game:HttpGet('https://pastebin.com/raw/rPnPiYZV'))();");

    private void remoteSpyToolStripMenuItem_Click(object sender, EventArgs e) => krnl_monaco.Pipe("loadstring(game:HttpGet('https://pastebin.com/raw/JZaJe9Sg'))();");

    protected override void Dispose(bool disposing)
    {
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__126.\u003C\u003Ep__2 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__126.\u003C\u003Ep__2 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target = krnl_monaco.\u003C\u003Eo__126.\u003C\u003Ep__2.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p2 = krnl_monaco.\u003C\u003Eo__126.\u003C\u003Ep__2;
      object obj1 = (object) disposing;
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__126.\u003C\u003Ep__1 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__126.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsFalse, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      object obj2;
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (!krnl_monaco.\u003C\u003Eo__126.\u003C\u003Ep__1.Target((CallSite) krnl_monaco.\u003C\u003Eo__126.\u003C\u003Ep__1, obj1))
      {
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__126.\u003C\u003Ep__0 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__126.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, bool, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.BinaryOperationLogical, ExpressionType.And, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        obj2 = krnl_monaco.\u003C\u003Eo__126.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__126.\u003C\u003Ep__0, obj1, this.components != null);
      }
      else
        obj2 = obj1;
      if (target((CallSite) p2, obj2))
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (krnl_monaco));
      this.panel1 = new Panel();
      this.pictureBox2 = new PictureBox();
      this.panel3 = new Panel();
      this.button2 = new Button();
      this.button1 = new Button();
      this.label1 = new Label();
      this.TabContextMenu = new ContextMenuStrip(this.components);
      this.clearToolStripMenuItem = new ToolStripMenuItem();
      this.openIntoToolStripMenuItem = new ToolStripMenuItem();
      this.saveToolStripMenuItem = new ToolStripMenuItem();
      this.toolStripMenuItem10 = new ToolStripMenuItem();
      this.ScriptView = new TreeView();
      this.contextMenuStrip1 = new ContextMenuStrip(this.components);
      this.executeToolStripMenuItem = new ToolStripMenuItem();
      this.loadIntoEditorToolStripMenuItem = new ToolStripMenuItem();
      this.deleteFileToolStripMenuItem = new ToolStripMenuItem();
      this.changePathToolStripMenuItem = new ToolStripMenuItem();
      this.reloadToolStripMenuItem = new ToolStripMenuItem();
      this.bunifuFlatButton1 = new BunifuFlatButton();
      this.bunifuFlatButton2 = new BunifuFlatButton();
      this.bunifuFlatButton3 = new BunifuFlatButton();
      this.bunifuFlatButton4 = new BunifuFlatButton();
      this.bunifuFlatButton5 = new BunifuFlatButton();
      this.bunifuFlatButton6 = new BunifuFlatButton();
      this.menuStrip1 = new MenuStrip();
      this.fileToolStripMenuItem = new ToolStripMenuItem();
      this.injectToolStripMenuItem = new ToolStripMenuItem();
      this.killRobloxToolStripMenuItem = new ToolStripMenuItem();
      this.aboutToolStripMenuItem = new ToolStripMenuItem();
      this.gamesToolStripMenuItem = new ToolStripMenuItem();
      this.hotScriptsToolStripMenuItem = new ToolStripMenuItem();
      this.toolStripMenuItem2 = new ToolStripMenuItem();
      this.openGuiToolStripMenuItem = new ToolStripMenuItem();
      this.toolStripMenuItem4 = new ToolStripMenuItem();
      this.toolStripMenuItem1 = new ToolStripMenuItem();
      this.remoteSpyToolStripMenuItem = new ToolStripMenuItem();
      this.toolStripMenuItem3 = new ToolStripMenuItem();
      this.unnamedESPToolStripMenuItem = new ToolStripMenuItem();
      this.toolStripMenuItem8 = new ToolStripMenuItem();
      this.cMDXToolStripMenuItem = new ToolStripMenuItem();
      this.toolStripMenuItem5 = new ToolStripMenuItem();
      this.toolStripMenuItem6 = new ToolStripMenuItem();
      this.toolStripMenuItem7 = new ToolStripMenuItem();
      this.timer1 = new System.Windows.Forms.Timer(this.components);
      this.toolTip1 = new ToolTip(this.components);
      this.panel2 = new Panel();
      this.errorProvider1 = new ErrorProvider(this.components);
      this.customTabControl1 = new MonacoCustomTabControl();
      this.tabPage1 = new TabPage();
      this.panel1.SuspendLayout();
      ((ISupportInitialize) this.pictureBox2).BeginInit();
      this.TabContextMenu.SuspendLayout();
      this.contextMenuStrip1.SuspendLayout();
      this.menuStrip1.SuspendLayout();
      ((ISupportInitialize) this.errorProvider1).BeginInit();
      this.customTabControl1.SuspendLayout();
      this.SuspendLayout();
      this.panel1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
      this.panel1.BackColor = System.Drawing.Color.FromArgb(29, 29, 29);
      this.panel1.Controls.Add((Control) this.pictureBox2);
      this.panel1.Controls.Add((Control) this.panel3);
      this.panel1.Controls.Add((Control) this.button2);
      this.panel1.Controls.Add((Control) this.button1);
      this.panel1.Controls.Add((Control) this.label1);
      this.panel1.Location = new Point(0, 0);
      this.panel1.Name = "panel1";
      this.panel1.Size = new Size(690, 33);
      this.panel1.TabIndex = 0;
      this.panel1.Paint += new PaintEventHandler(this.panel1_Paint);
      this.panel1.MouseMove += new MouseEventHandler(this.panel1_MouseMove);
      this.pictureBox2.Image = (Image) componentResourceManager.GetObject("pictureBox2.Image");
      this.pictureBox2.Location = new Point(4, 4);
      this.pictureBox2.Name = "pictureBox2";
      this.pictureBox2.Size = new Size(25, 25);
      this.pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox2.TabIndex = 8;
      this.pictureBox2.TabStop = false;
      this.panel3.AutoSize = true;
      this.panel3.BackColor = System.Drawing.Color.DodgerBlue;
      this.panel3.Location = new Point(0, 1);
      this.panel3.Name = "panel3";
      this.panel3.Size = new Size(682, 3);
      this.panel3.TabIndex = 5;
      this.panel3.MouseMove += new MouseEventHandler(this.krnl_MouseMove);
      this.button2.Anchor = AnchorStyles.Right;
      this.button2.BackColor = System.Drawing.Color.FromArgb(29, 29, 29);
      this.button2.BackgroundImageLayout = ImageLayout.Center;
      this.button2.FlatAppearance.BorderSize = 0;
      this.button2.FlatStyle = FlatStyle.Flat;
      this.button2.Font = new Font("Corbel", 12f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.button2.ForeColor = System.Drawing.Color.White;
      this.button2.Image = (Image) componentResourceManager.GetObject("button2.Image");
      this.button2.Location = new Point(620, 0);
      this.button2.Name = "button2";
      this.button2.Size = new Size(35, 33);
      this.button2.TabIndex = 7;
      this.button2.UseVisualStyleBackColor = false;
      this.button2.Click += new EventHandler(this.button2_Click);
      this.button1.Anchor = AnchorStyles.Right;
      this.button1.BackColor = System.Drawing.Color.FromArgb(29, 29, 29);
      this.button1.FlatAppearance.BorderSize = 0;
      this.button1.FlatStyle = FlatStyle.Flat;
      this.button1.Font = new Font("Corbel", 12f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.button1.ForeColor = System.Drawing.Color.White;
      this.button1.Image = (Image) componentResourceManager.GetObject("button1.Image");
      this.button1.Location = new Point(655, 0);
      this.button1.Name = "button1";
      this.button1.Size = new Size(35, 33);
      this.button1.TabIndex = 6;
      this.button1.UseVisualStyleBackColor = false;
      this.button1.Click += new EventHandler(this.button1_Click);
      this.button1.MouseMove += new MouseEventHandler(this.krnl_MouseMove);
      this.label1.Anchor = AnchorStyles.None;
      this.label1.AutoSize = true;
      this.label1.Font = new Font("Segoe UI", 11.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label1.ForeColor = System.Drawing.Color.White;
      this.label1.Location = new Point(328, 7);
      this.label1.Name = "label1";
      this.label1.Size = new Size(45, 20);
      this.label1.TabIndex = 0;
      this.label1.Text = "KRNL";
      this.label1.MouseDown += new MouseEventHandler(this.panel1_MouseMove);
      this.TabContextMenu.ImageScalingSize = new Size(20, 20);
      this.TabContextMenu.Items.AddRange(new ToolStripItem[4]
      {
        (ToolStripItem) this.clearToolStripMenuItem,
        (ToolStripItem) this.openIntoToolStripMenuItem,
        (ToolStripItem) this.saveToolStripMenuItem,
        (ToolStripItem) this.toolStripMenuItem10
      });
      this.TabContextMenu.Name = "TabContextMenu";
      this.TabContextMenu.RenderMode = ToolStripRenderMode.System;
      this.TabContextMenu.Size = new Size(128, 92);
      this.clearToolStripMenuItem.Name = "clearToolStripMenuItem";
      this.clearToolStripMenuItem.Size = new Size((int) sbyte.MaxValue, 22);
      this.clearToolStripMenuItem.Text = "Clear";
      this.clearToolStripMenuItem.Click += new EventHandler(this.clearToolStripMenuItem_Click);
      this.openIntoToolStripMenuItem.Name = "openIntoToolStripMenuItem";
      this.openIntoToolStripMenuItem.Size = new Size((int) sbyte.MaxValue, 22);
      this.openIntoToolStripMenuItem.Text = "Open Into";
      this.openIntoToolStripMenuItem.Click += new EventHandler(this.openIntoToolStripMenuItem_Click);
      this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
      this.saveToolStripMenuItem.Size = new Size((int) sbyte.MaxValue, 22);
      this.saveToolStripMenuItem.Text = "Save";
      this.saveToolStripMenuItem.Click += new EventHandler(this.saveToolStripMenuItem_Click);
      this.toolStripMenuItem10.Name = "toolStripMenuItem10";
      this.toolStripMenuItem10.Size = new Size((int) sbyte.MaxValue, 22);
      this.toolStripMenuItem10.Text = "Rename";
      this.toolStripMenuItem10.Click += new EventHandler(this.toolStripMenuItem10_Click);
      this.ScriptView.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
      this.ScriptView.BackColor = System.Drawing.Color.FromArgb(29, 29, 29);
      this.ScriptView.BorderStyle = BorderStyle.None;
      this.ScriptView.ContextMenuStrip = this.contextMenuStrip1;
      this.ScriptView.Font = new Font("Segoe UI", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.ScriptView.ForeColor = System.Drawing.Color.White;
      this.ScriptView.HideSelection = false;
      this.ScriptView.LineColor = System.Drawing.Color.White;
      this.ScriptView.Location = new Point(565, 59);
      this.ScriptView.Name = "ScriptView";
      this.ScriptView.Size = new Size(121, 259);
      this.ScriptView.TabIndex = 4;
      this.ScriptView.AfterSelect += new TreeViewEventHandler(this.ScriptView_AfterSelect);
      this.ScriptView.MouseMove += new MouseEventHandler(this.krnl_MouseMove);
      this.contextMenuStrip1.ImageScalingSize = new Size(20, 20);
      this.contextMenuStrip1.Items.AddRange(new ToolStripItem[5]
      {
        (ToolStripItem) this.executeToolStripMenuItem,
        (ToolStripItem) this.loadIntoEditorToolStripMenuItem,
        (ToolStripItem) this.deleteFileToolStripMenuItem,
        (ToolStripItem) this.changePathToolStripMenuItem,
        (ToolStripItem) this.reloadToolStripMenuItem
      });
      this.contextMenuStrip1.Name = "contextMenuStrip1";
      this.contextMenuStrip1.Size = new Size(159, 114);
      this.executeToolStripMenuItem.Name = "executeToolStripMenuItem";
      this.executeToolStripMenuItem.Size = new Size(158, 22);
      this.executeToolStripMenuItem.Text = "Execute";
      this.executeToolStripMenuItem.Click += new EventHandler(this.executeToolStripMenuItem_Click);
      this.loadIntoEditorToolStripMenuItem.Name = "loadIntoEditorToolStripMenuItem";
      this.loadIntoEditorToolStripMenuItem.Size = new Size(158, 22);
      this.loadIntoEditorToolStripMenuItem.Text = "Load Into Editor";
      this.loadIntoEditorToolStripMenuItem.Click += new EventHandler(this.loadIntoEditorToolStripMenuItem_Click);
      this.deleteFileToolStripMenuItem.Name = "deleteFileToolStripMenuItem";
      this.deleteFileToolStripMenuItem.Size = new Size(158, 22);
      this.deleteFileToolStripMenuItem.Text = "Delete File";
      this.deleteFileToolStripMenuItem.Click += new EventHandler(this.deleteFileToolStripMenuItem_Click);
      this.changePathToolStripMenuItem.Name = "changePathToolStripMenuItem";
      this.changePathToolStripMenuItem.Size = new Size(158, 22);
      this.changePathToolStripMenuItem.Text = "Change Path";
      this.changePathToolStripMenuItem.Click += new EventHandler(this.changePathToolStripMenuItem_Click);
      this.reloadToolStripMenuItem.Name = "reloadToolStripMenuItem";
      this.reloadToolStripMenuItem.Size = new Size(158, 22);
      this.reloadToolStripMenuItem.Text = "Reload";
      this.reloadToolStripMenuItem.Click += new EventHandler(this.reloadToolStripMenuItem_Click);
      this.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(36, 36, 36);
      this.bunifuFlatButton1.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
      this.bunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(36, 36, 36);
      this.bunifuFlatButton1.BackgroundImageLayout = ImageLayout.Stretch;
      this.bunifuFlatButton1.BorderRadius = 0;
      this.bunifuFlatButton1.ButtonText = "EXECUTE";
      this.bunifuFlatButton1.Cursor = Cursors.Hand;
      this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
      this.bunifuFlatButton1.Font = new Font("Segoe UI", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
      this.bunifuFlatButton1.Iconimage = (Image) null;
      this.bunifuFlatButton1.Iconimage_right = (Image) null;
      this.bunifuFlatButton1.Iconimage_right_Selected = (Image) null;
      this.bunifuFlatButton1.Iconimage_Selected = (Image) null;
      this.bunifuFlatButton1.IconMarginLeft = 0;
      this.bunifuFlatButton1.IconMarginRight = 0;
      this.bunifuFlatButton1.IconRightVisible = true;
      this.bunifuFlatButton1.IconRightZoom = 0.0;
      this.bunifuFlatButton1.IconVisible = true;
      this.bunifuFlatButton1.IconZoom = 20.0;
      this.bunifuFlatButton1.IsTab = false;
      this.bunifuFlatButton1.Location = new Point(4, 321);
      this.bunifuFlatButton1.Margin = new Padding(0, 3, 3, 3);
      this.bunifuFlatButton1.MinimumSize = new Size(84, 25);
      this.bunifuFlatButton1.Name = "bunifuFlatButton1";
      this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(36, 36, 36);
      this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(39, 39, 39);
      this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
      this.bunifuFlatButton1.Padding = new Padding(0, 4, 0, 0);
      this.bunifuFlatButton1.selected = false;
      this.bunifuFlatButton1.Size = new Size(100, 25);
      this.bunifuFlatButton1.TabIndex = 7;
      this.bunifuFlatButton1.Text = "EXECUTE";
      this.bunifuFlatButton1.TextAlign = ContentAlignment.MiddleCenter;
      this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
      this.bunifuFlatButton1.TextFont = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.bunifuFlatButton1.Click += new EventHandler(this.bunifuFlatButton1_Click);
      this.bunifuFlatButton2.Activecolor = System.Drawing.Color.FromArgb(36, 36, 36);
      this.bunifuFlatButton2.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
      this.bunifuFlatButton2.BackColor = System.Drawing.Color.FromArgb(36, 36, 36);
      this.bunifuFlatButton2.BackgroundImageLayout = ImageLayout.Stretch;
      this.bunifuFlatButton2.BorderRadius = 0;
      this.bunifuFlatButton2.ButtonText = "CLEAR";
      this.bunifuFlatButton2.Cursor = Cursors.Hand;
      this.bunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray;
      this.bunifuFlatButton2.Font = new Font("Segoe UI", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.bunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent;
      this.bunifuFlatButton2.Iconimage = (Image) null;
      this.bunifuFlatButton2.Iconimage_right = (Image) null;
      this.bunifuFlatButton2.Iconimage_right_Selected = (Image) null;
      this.bunifuFlatButton2.Iconimage_Selected = (Image) null;
      this.bunifuFlatButton2.IconMarginLeft = 0;
      this.bunifuFlatButton2.IconMarginRight = 0;
      this.bunifuFlatButton2.IconRightVisible = true;
      this.bunifuFlatButton2.IconRightZoom = 0.0;
      this.bunifuFlatButton2.IconVisible = true;
      this.bunifuFlatButton2.IconZoom = 20.0;
      this.bunifuFlatButton2.IsTab = false;
      this.bunifuFlatButton2.Location = new Point(107, 321);
      this.bunifuFlatButton2.Margin = new Padding(0, 3, 3, 3);
      this.bunifuFlatButton2.MinimumSize = new Size(84, 25);
      this.bunifuFlatButton2.Name = "bunifuFlatButton2";
      this.bunifuFlatButton2.Normalcolor = System.Drawing.Color.FromArgb(36, 36, 36);
      this.bunifuFlatButton2.OnHovercolor = System.Drawing.Color.FromArgb(39, 39, 39);
      this.bunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White;
      this.bunifuFlatButton2.Padding = new Padding(0, 4, 0, 0);
      this.bunifuFlatButton2.selected = false;
      this.bunifuFlatButton2.Size = new Size(100, 25);
      this.bunifuFlatButton2.TabIndex = 8;
      this.bunifuFlatButton2.Text = "CLEAR";
      this.bunifuFlatButton2.TextAlign = ContentAlignment.MiddleCenter;
      this.bunifuFlatButton2.Textcolor = System.Drawing.Color.White;
      this.bunifuFlatButton2.TextFont = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.bunifuFlatButton2.Click += new EventHandler(this.bunifuFlatButton2_Click);
      this.bunifuFlatButton3.Activecolor = System.Drawing.Color.FromArgb(36, 36, 36);
      this.bunifuFlatButton3.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
      this.bunifuFlatButton3.BackColor = System.Drawing.Color.FromArgb(36, 36, 36);
      this.bunifuFlatButton3.BackgroundImageLayout = ImageLayout.Stretch;
      this.bunifuFlatButton3.BorderRadius = 0;
      this.bunifuFlatButton3.ButtonText = "OPEN FILE";
      this.bunifuFlatButton3.Cursor = Cursors.Hand;
      this.bunifuFlatButton3.DisabledColor = System.Drawing.Color.Gray;
      this.bunifuFlatButton3.Font = new Font("Segoe UI", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.bunifuFlatButton3.Iconcolor = System.Drawing.Color.Transparent;
      this.bunifuFlatButton3.Iconimage = (Image) null;
      this.bunifuFlatButton3.Iconimage_right = (Image) null;
      this.bunifuFlatButton3.Iconimage_right_Selected = (Image) null;
      this.bunifuFlatButton3.Iconimage_Selected = (Image) null;
      this.bunifuFlatButton3.IconMarginLeft = 0;
      this.bunifuFlatButton3.IconMarginRight = 0;
      this.bunifuFlatButton3.IconRightVisible = true;
      this.bunifuFlatButton3.IconRightZoom = 0.0;
      this.bunifuFlatButton3.IconVisible = true;
      this.bunifuFlatButton3.IconZoom = 20.0;
      this.bunifuFlatButton3.IsTab = false;
      this.bunifuFlatButton3.Location = new Point(210, 321);
      this.bunifuFlatButton3.Margin = new Padding(0, 3, 3, 3);
      this.bunifuFlatButton3.MinimumSize = new Size(84, 25);
      this.bunifuFlatButton3.Name = "bunifuFlatButton3";
      this.bunifuFlatButton3.Normalcolor = System.Drawing.Color.FromArgb(36, 36, 36);
      this.bunifuFlatButton3.OnHovercolor = System.Drawing.Color.FromArgb(39, 39, 39);
      this.bunifuFlatButton3.OnHoverTextColor = System.Drawing.Color.White;
      this.bunifuFlatButton3.Padding = new Padding(0, 4, 0, 0);
      this.bunifuFlatButton3.selected = false;
      this.bunifuFlatButton3.Size = new Size(100, 25);
      this.bunifuFlatButton3.TabIndex = 9;
      this.bunifuFlatButton3.Text = "OPEN FILE";
      this.bunifuFlatButton3.TextAlign = ContentAlignment.MiddleCenter;
      this.bunifuFlatButton3.Textcolor = System.Drawing.Color.White;
      this.bunifuFlatButton3.TextFont = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.bunifuFlatButton3.Click += new EventHandler(this.bunifuFlatButton3_Click);
      this.bunifuFlatButton4.Activecolor = System.Drawing.Color.FromArgb(36, 36, 36);
      this.bunifuFlatButton4.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
      this.bunifuFlatButton4.BackColor = System.Drawing.Color.FromArgb(36, 36, 36);
      this.bunifuFlatButton4.BackgroundImageLayout = ImageLayout.Stretch;
      this.bunifuFlatButton4.BorderRadius = 0;
      this.bunifuFlatButton4.ButtonText = "SAVE FILE";
      this.bunifuFlatButton4.Cursor = Cursors.Hand;
      this.bunifuFlatButton4.DisabledColor = System.Drawing.Color.Gray;
      this.bunifuFlatButton4.Font = new Font("Segoe UI", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.bunifuFlatButton4.Iconcolor = System.Drawing.Color.Transparent;
      this.bunifuFlatButton4.Iconimage = (Image) null;
      this.bunifuFlatButton4.Iconimage_right = (Image) null;
      this.bunifuFlatButton4.Iconimage_right_Selected = (Image) null;
      this.bunifuFlatButton4.Iconimage_Selected = (Image) null;
      this.bunifuFlatButton4.IconMarginLeft = 0;
      this.bunifuFlatButton4.IconMarginRight = 0;
      this.bunifuFlatButton4.IconRightVisible = true;
      this.bunifuFlatButton4.IconRightZoom = 0.0;
      this.bunifuFlatButton4.IconVisible = true;
      this.bunifuFlatButton4.IconZoom = 20.0;
      this.bunifuFlatButton4.IsTab = false;
      this.bunifuFlatButton4.Location = new Point(313, 321);
      this.bunifuFlatButton4.Margin = new Padding(0, 3, 3, 3);
      this.bunifuFlatButton4.MinimumSize = new Size(84, 25);
      this.bunifuFlatButton4.Name = "bunifuFlatButton4";
      this.bunifuFlatButton4.Normalcolor = System.Drawing.Color.FromArgb(36, 36, 36);
      this.bunifuFlatButton4.OnHovercolor = System.Drawing.Color.FromArgb(39, 39, 39);
      this.bunifuFlatButton4.OnHoverTextColor = System.Drawing.Color.White;
      this.bunifuFlatButton4.Padding = new Padding(0, 4, 0, 0);
      this.bunifuFlatButton4.selected = false;
      this.bunifuFlatButton4.Size = new Size(100, 25);
      this.bunifuFlatButton4.TabIndex = 10;
      this.bunifuFlatButton4.Text = "SAVE FILE";
      this.bunifuFlatButton4.TextAlign = ContentAlignment.MiddleCenter;
      this.bunifuFlatButton4.Textcolor = System.Drawing.Color.White;
      this.bunifuFlatButton4.TextFont = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.bunifuFlatButton4.Click += new EventHandler(this.bunifuFlatButton4_Click);
      this.bunifuFlatButton5.Activecolor = System.Drawing.Color.FromArgb(36, 36, 36);
      this.bunifuFlatButton5.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
      this.bunifuFlatButton5.BackColor = System.Drawing.Color.FromArgb(36, 36, 36);
      this.bunifuFlatButton5.BackgroundImageLayout = ImageLayout.Stretch;
      this.bunifuFlatButton5.BorderRadius = 0;
      this.bunifuFlatButton5.ButtonText = "INJECT";
      this.bunifuFlatButton5.Cursor = Cursors.Hand;
      this.bunifuFlatButton5.DisabledColor = System.Drawing.Color.Gray;
      this.bunifuFlatButton5.Font = new Font("Segoe UI", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.bunifuFlatButton5.Iconcolor = System.Drawing.Color.Transparent;
      this.bunifuFlatButton5.Iconimage = (Image) null;
      this.bunifuFlatButton5.Iconimage_right = (Image) null;
      this.bunifuFlatButton5.Iconimage_right_Selected = (Image) null;
      this.bunifuFlatButton5.Iconimage_Selected = (Image) null;
      this.bunifuFlatButton5.IconMarginLeft = 0;
      this.bunifuFlatButton5.IconMarginRight = 0;
      this.bunifuFlatButton5.IconRightVisible = true;
      this.bunifuFlatButton5.IconRightZoom = 0.0;
      this.bunifuFlatButton5.IconVisible = true;
      this.bunifuFlatButton5.IconZoom = 20.0;
      this.bunifuFlatButton5.IsTab = false;
      this.bunifuFlatButton5.Location = new Point(416, 321);
      this.bunifuFlatButton5.Margin = new Padding(0, 3, 3, 3);
      this.bunifuFlatButton5.MinimumSize = new Size(84, 25);
      this.bunifuFlatButton5.Name = "bunifuFlatButton5";
      this.bunifuFlatButton5.Normalcolor = System.Drawing.Color.FromArgb(36, 36, 36);
      this.bunifuFlatButton5.OnHovercolor = System.Drawing.Color.FromArgb(39, 39, 39);
      this.bunifuFlatButton5.OnHoverTextColor = System.Drawing.Color.White;
      this.bunifuFlatButton5.Padding = new Padding(0, 4, 0, 0);
      this.bunifuFlatButton5.selected = false;
      this.bunifuFlatButton5.Size = new Size(100, 25);
      this.bunifuFlatButton5.TabIndex = 11;
      this.bunifuFlatButton5.Text = "INJECT";
      this.bunifuFlatButton5.TextAlign = ContentAlignment.MiddleCenter;
      this.bunifuFlatButton5.Textcolor = System.Drawing.Color.White;
      this.bunifuFlatButton5.TextFont = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.bunifuFlatButton5.Click += new EventHandler(this.bunifuFlatButton5_Click);
      this.bunifuFlatButton6.Activecolor = System.Drawing.Color.FromArgb(36, 36, 36);
      this.bunifuFlatButton6.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
      this.bunifuFlatButton6.BackColor = System.Drawing.Color.FromArgb(36, 36, 36);
      this.bunifuFlatButton6.BackgroundImageLayout = ImageLayout.Stretch;
      this.bunifuFlatButton6.BorderRadius = 0;
      this.bunifuFlatButton6.ButtonText = "OPTIONS";
      this.bunifuFlatButton6.Cursor = Cursors.Hand;
      this.bunifuFlatButton6.DisabledColor = System.Drawing.Color.Gray;
      this.bunifuFlatButton6.Font = new Font("Segoe UI", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.bunifuFlatButton6.Iconcolor = System.Drawing.Color.Transparent;
      this.bunifuFlatButton6.Iconimage = (Image) null;
      this.bunifuFlatButton6.Iconimage_right = (Image) null;
      this.bunifuFlatButton6.Iconimage_right_Selected = (Image) null;
      this.bunifuFlatButton6.Iconimage_Selected = (Image) null;
      this.bunifuFlatButton6.IconMarginLeft = 0;
      this.bunifuFlatButton6.IconMarginRight = 0;
      this.bunifuFlatButton6.IconRightVisible = true;
      this.bunifuFlatButton6.IconRightZoom = 0.0;
      this.bunifuFlatButton6.IconVisible = true;
      this.bunifuFlatButton6.IconZoom = 20.0;
      this.bunifuFlatButton6.IsTab = false;
      this.bunifuFlatButton6.Location = new Point(586, 321);
      this.bunifuFlatButton6.Margin = new Padding(0, 3, 3, 3);
      this.bunifuFlatButton6.MinimumSize = new Size(84, 25);
      this.bunifuFlatButton6.Name = "bunifuFlatButton6";
      this.bunifuFlatButton6.Normalcolor = System.Drawing.Color.FromArgb(36, 36, 36);
      this.bunifuFlatButton6.OnHovercolor = System.Drawing.Color.FromArgb(39, 39, 39);
      this.bunifuFlatButton6.OnHoverTextColor = System.Drawing.Color.White;
      this.bunifuFlatButton6.Padding = new Padding(0, 4, 0, 0);
      this.bunifuFlatButton6.selected = false;
      this.bunifuFlatButton6.Size = new Size(100, 25);
      this.bunifuFlatButton6.TabIndex = 12;
      this.bunifuFlatButton6.Text = "OPTIONS";
      this.bunifuFlatButton6.TextAlign = ContentAlignment.MiddleCenter;
      this.bunifuFlatButton6.Textcolor = System.Drawing.Color.White;
      this.bunifuFlatButton6.TextFont = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.bunifuFlatButton6.Click += new EventHandler(this.bunifuFlatButton6_Click);
      this.menuStrip1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
      this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(33, 33, 33);
      this.menuStrip1.Dock = DockStyle.None;
      this.menuStrip1.ImageScalingSize = new Size(20, 20);
      this.menuStrip1.Items.AddRange(new ToolStripItem[5]
      {
        (ToolStripItem) this.fileToolStripMenuItem,
        (ToolStripItem) this.aboutToolStripMenuItem,
        (ToolStripItem) this.gamesToolStripMenuItem,
        (ToolStripItem) this.hotScriptsToolStripMenuItem,
        (ToolStripItem) this.toolStripMenuItem5
      });
      this.menuStrip1.Location = new Point(0, 33);
      this.menuStrip1.Name = "menuStrip1";
      this.menuStrip1.Size = new Size(289, 24);
      this.menuStrip1.TabIndex = 13;
      this.menuStrip1.Text = "menuStrip1";
      this.fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[2]
      {
        (ToolStripItem) this.injectToolStripMenuItem,
        (ToolStripItem) this.killRobloxToolStripMenuItem
      });
      this.fileToolStripMenuItem.Font = new Font("Segoe UI", 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.fileToolStripMenuItem.ForeColor = System.Drawing.Color.White;
      this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
      this.fileToolStripMenuItem.Size = new Size(37, 20);
      this.fileToolStripMenuItem.Text = "File";
      this.injectToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(33, 33, 33);
      this.injectToolStripMenuItem.ForeColor = System.Drawing.Color.White;
      this.injectToolStripMenuItem.Name = "injectToolStripMenuItem";
      this.injectToolStripMenuItem.Size = new Size(130, 22);
      this.injectToolStripMenuItem.Text = "Inject";
      this.injectToolStripMenuItem.Click += new EventHandler(this.injectToolStripMenuItem_Click_1);
      this.killRobloxToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(33, 33, 33);
      this.killRobloxToolStripMenuItem.ForeColor = System.Drawing.Color.White;
      this.killRobloxToolStripMenuItem.Name = "killRobloxToolStripMenuItem";
      this.killRobloxToolStripMenuItem.Size = new Size(130, 22);
      this.killRobloxToolStripMenuItem.Text = "Kill Roblox";
      this.killRobloxToolStripMenuItem.Click += new EventHandler(this.killRobloxToolStripMenuItem_Click);
      this.aboutToolStripMenuItem.Font = new Font("Segoe UI", 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.aboutToolStripMenuItem.ForeColor = System.Drawing.Color.White;
      this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
      this.aboutToolStripMenuItem.Size = new Size(56, 20);
      this.aboutToolStripMenuItem.Text = "Credits";
      this.aboutToolStripMenuItem.Click += new EventHandler(this.aboutToolStripMenuItem_Click_1);
      this.gamesToolStripMenuItem.Font = new Font("Segoe UI", 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.gamesToolStripMenuItem.ForeColor = System.Drawing.Color.White;
      this.gamesToolStripMenuItem.Name = "gamesToolStripMenuItem";
      this.gamesToolStripMenuItem.Size = new Size(55, 20);
      this.gamesToolStripMenuItem.Text = "Games";
      this.gamesToolStripMenuItem.Click += new EventHandler(this.gamesToolStripMenuItem_Click_1);
      this.hotScriptsToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[9]
      {
        (ToolStripItem) this.toolStripMenuItem2,
        (ToolStripItem) this.openGuiToolStripMenuItem,
        (ToolStripItem) this.toolStripMenuItem4,
        (ToolStripItem) this.toolStripMenuItem1,
        (ToolStripItem) this.remoteSpyToolStripMenuItem,
        (ToolStripItem) this.toolStripMenuItem3,
        (ToolStripItem) this.unnamedESPToolStripMenuItem,
        (ToolStripItem) this.toolStripMenuItem8,
        (ToolStripItem) this.cMDXToolStripMenuItem
      });
      this.hotScriptsToolStripMenuItem.ForeColor = System.Drawing.Color.White;
      this.hotScriptsToolStripMenuItem.Name = "hotScriptsToolStripMenuItem";
      this.hotScriptsToolStripMenuItem.Size = new Size(79, 20);
      this.hotScriptsToolStripMenuItem.Text = "Hot-Scripts";
      this.toolStripMenuItem2.BackColor = System.Drawing.Color.FromArgb(33, 33, 33);
      this.toolStripMenuItem2.ForeColor = System.Drawing.Color.White;
      this.toolStripMenuItem2.Name = "toolStripMenuItem2";
      this.toolStripMenuItem2.Size = new Size(148, 22);
      this.toolStripMenuItem2.Text = "DarkDex";
      this.toolStripMenuItem2.Click += new EventHandler(this.toolStripMenuItem2_Click);
      this.openGuiToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(33, 33, 33);
      this.openGuiToolStripMenuItem.ForeColor = System.Drawing.Color.White;
      this.openGuiToolStripMenuItem.Name = "openGuiToolStripMenuItem";
      this.openGuiToolStripMenuItem.Size = new Size(148, 22);
      this.openGuiToolStripMenuItem.Text = "OpenGui";
      this.openGuiToolStripMenuItem.Click += new EventHandler(this.openGuiToolStripMenuItem_Click_1);
      this.toolStripMenuItem4.BackColor = System.Drawing.Color.FromArgb(33, 33, 33);
      this.toolStripMenuItem4.ForeColor = System.Drawing.Color.White;
      this.toolStripMenuItem4.Name = "toolStripMenuItem4";
      this.toolStripMenuItem4.Size = new Size(148, 22);
      this.toolStripMenuItem4.Text = "Owl Hub";
      this.toolStripMenuItem4.Click += new EventHandler(this.toolStripMenuItem4_Click);
      this.toolStripMenuItem1.BackColor = System.Drawing.Color.FromArgb(33, 33, 33);
      this.toolStripMenuItem1.ForeColor = System.Drawing.Color.White;
      this.toolStripMenuItem1.Name = "toolStripMenuItem1";
      this.toolStripMenuItem1.Size = new Size(148, 22);
      this.toolStripMenuItem1.Text = "Galaxy Hub";
      this.toolStripMenuItem1.Click += new EventHandler(this.toolStripMenuItem1_Click_2);
      this.remoteSpyToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(33, 33, 33);
      this.remoteSpyToolStripMenuItem.ForeColor = System.Drawing.Color.White;
      this.remoteSpyToolStripMenuItem.Name = "remoteSpyToolStripMenuItem";
      this.remoteSpyToolStripMenuItem.Size = new Size(148, 22);
      this.remoteSpyToolStripMenuItem.Text = "Remote Spy";
      this.remoteSpyToolStripMenuItem.Click += new EventHandler(this.remoteSpyToolStripMenuItem_Click);
      this.toolStripMenuItem3.BackColor = System.Drawing.Color.FromArgb(33, 33, 33);
      this.toolStripMenuItem3.ForeColor = System.Drawing.Color.White;
      this.toolStripMenuItem3.Name = "toolStripMenuItem3";
      this.toolStripMenuItem3.Size = new Size(148, 22);
      this.toolStripMenuItem3.Text = "Game Sense";
      this.toolStripMenuItem3.Click += new EventHandler(this.gameSenseToolStripMenuItem_Click);
      this.unnamedESPToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(33, 33, 33);
      this.unnamedESPToolStripMenuItem.ForeColor = System.Drawing.Color.White;
      this.unnamedESPToolStripMenuItem.Name = "unnamedESPToolStripMenuItem";
      this.unnamedESPToolStripMenuItem.Size = new Size(148, 22);
      this.unnamedESPToolStripMenuItem.Text = "Unnamed ESP";
      this.unnamedESPToolStripMenuItem.Click += new EventHandler(this.unnamedESPToolStripMenuItem_Click);
      this.toolStripMenuItem8.BackColor = System.Drawing.Color.FromArgb(33, 33, 33);
      this.toolStripMenuItem8.ForeColor = System.Drawing.Color.White;
      this.toolStripMenuItem8.Name = "toolStripMenuItem8";
      this.toolStripMenuItem8.Size = new Size(148, 22);
      this.toolStripMenuItem8.Text = "Infinite Yield";
      this.toolStripMenuItem8.Click += new EventHandler(this.toolStripMenuItem8_Click);
      this.cMDXToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(33, 33, 33);
      this.cMDXToolStripMenuItem.ForeColor = System.Drawing.Color.White;
      this.cMDXToolStripMenuItem.Name = "cMDXToolStripMenuItem";
      this.cMDXToolStripMenuItem.Size = new Size(148, 22);
      this.cMDXToolStripMenuItem.Text = "CMD-X";
      this.cMDXToolStripMenuItem.Click += new EventHandler(this.cMDXToolStripMenuItem_Click);
      this.toolStripMenuItem5.DropDownItems.AddRange(new ToolStripItem[2]
      {
        (ToolStripItem) this.toolStripMenuItem6,
        (ToolStripItem) this.toolStripMenuItem7
      });
      this.toolStripMenuItem5.ForeColor = System.Drawing.Color.White;
      this.toolStripMenuItem5.Name = "toolStripMenuItem5";
      this.toolStripMenuItem5.Size = new Size(54, 20);
      this.toolStripMenuItem5.Text = "Others";
      this.toolStripMenuItem6.BackColor = System.Drawing.Color.FromArgb(33, 33, 33);
      this.toolStripMenuItem6.ForeColor = System.Drawing.Color.White;
      this.toolStripMenuItem6.Name = "toolStripMenuItem6";
      this.toolStripMenuItem6.Size = new Size(173, 22);
      this.toolStripMenuItem6.Text = "Get Key";
      this.toolStripMenuItem6.Click += new EventHandler(this.bunifuFlatButton8_Click);
      this.toolStripMenuItem7.BackColor = System.Drawing.Color.FromArgb(33, 33, 33);
      this.toolStripMenuItem7.ForeColor = System.Drawing.Color.White;
      this.toolStripMenuItem7.Name = "toolStripMenuItem7";
      this.toolStripMenuItem7.Size = new Size(173, 22);
      this.toolStripMenuItem7.Text = "Join Discord Server";
      this.toolStripMenuItem7.Click += new EventHandler(this.toolStripMenuItem7_Click);
      this.timer1.Enabled = true;
      this.timer1.Interval = 1000;
      this.timer1.Tick += new EventHandler(this.timer1_Tick);
      this.panel2.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
      this.panel2.BackColor = System.Drawing.Color.FromArgb(33, 33, 33);
      this.panel2.Location = new Point(288, 32);
      this.panel2.Name = "panel2";
      this.panel2.Size = new Size(402, 25);
      this.panel2.TabIndex = 0;
      this.panel2.MouseMove += new MouseEventHandler(this.krnl_MouseMove);
      this.errorProvider1.ContainerControl = (ContainerControl) this;
      this.customTabControl1.ActiveColor = System.Drawing.Color.FromArgb(30, 30, 30);
      this.customTabControl1.AllowDrop = true;
      this.customTabControl1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
      this.customTabControl1.BackTabColor = System.Drawing.Color.FromArgb(36, 36, 36);
      this.customTabControl1.BorderColor = System.Drawing.Color.FromArgb(30, 30, 30);
      this.customTabControl1.ClosingButtonColor = System.Drawing.Color.WhiteSmoke;
      this.customTabControl1.ClosingMessage = (string) null;
      this.customTabControl1.Controls.Add((Control) this.tabPage1);
      this.customTabControl1.HeaderColor = System.Drawing.Color.FromArgb(45, 45, 48);
      this.customTabControl1.HorizontalLineColor = System.Drawing.Color.FromArgb(30, 30, 30);
      this.customTabControl1.ItemSize = new Size(240, 16);
      this.customTabControl1.Location = new Point(4, 59);
      this.customTabControl1.Name = "customTabControl1";
      this.customTabControl1.SelectedIndex = 0;
      this.customTabControl1.SelectedTextColor = System.Drawing.Color.FromArgb((int) byte.MaxValue, (int) byte.MaxValue, (int) byte.MaxValue);
      this.customTabControl1.ShowClosingButton = false;
      this.customTabControl1.ShowClosingMessage = false;
      this.customTabControl1.Size = new Size(556, 259);
      this.customTabControl1.TabIndex = 3;
      this.customTabControl1.TextColor = System.Drawing.Color.FromArgb((int) byte.MaxValue, (int) byte.MaxValue, (int) byte.MaxValue);
      this.customTabControl1.SelectedIndexChanged += new EventHandler(this.customTabControl1_SelectedIndexChanged);
      this.tabPage1.BackColor = System.Drawing.Color.FromArgb(36, 36, 36);
      this.tabPage1.Location = new Point(4, 20);
      this.tabPage1.Name = "tabPage1";
      this.tabPage1.Size = new Size(548, 235);
      this.tabPage1.TabIndex = 0;
      this.tabPage1.Click += new EventHandler(this.tabPage1_Click);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.BackColor = System.Drawing.Color.FromArgb(18, 18, 18);
      this.ClientSize = new Size(690, 350);
      this.Controls.Add((Control) this.menuStrip1);
      this.Controls.Add((Control) this.ScriptView);
      this.Controls.Add((Control) this.customTabControl1);
      this.Controls.Add((Control) this.panel1);
      this.Controls.Add((Control) this.panel2);
      this.Controls.Add((Control) this.bunifuFlatButton5);
      this.Controls.Add((Control) this.bunifuFlatButton4);
      this.Controls.Add((Control) this.bunifuFlatButton3);
      this.Controls.Add((Control) this.bunifuFlatButton2);
      this.Controls.Add((Control) this.bunifuFlatButton1);
      this.Controls.Add((Control) this.bunifuFlatButton6);
      this.FormBorderStyle = FormBorderStyle.None;
      this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
      this.Name = nameof (krnl_monaco);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "krnl";
      this.TopMost = true;
      this.Activated += new EventHandler(this.krnl_Activated);
      this.Deactivate += new EventHandler(this.krnl_Deactivate);
      this.FormClosing += new FormClosingEventHandler(this.krnl_FormClosing);
      this.Load += new EventHandler(this.Form1_Load);
      this.MouseDown += new MouseEventHandler(this.krnl_MouseDown);
      this.MouseMove += new MouseEventHandler(this.krnl_MouseMove);
      this.MouseUp += new MouseEventHandler(this.krnl_MouseUp);
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      ((ISupportInitialize) this.pictureBox2).EndInit();
      this.TabContextMenu.ResumeLayout(false);
      this.contextMenuStrip1.ResumeLayout(false);
      this.menuStrip1.ResumeLayout(false);
      this.menuStrip1.PerformLayout();
      ((ISupportInitialize) this.errorProvider1).EndInit();
      this.customTabControl1.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();
    }

    private bool injectdll(object filename, int PID)
    {
      Program.injecting = true;
      Program.form.Invoke((Delegate) (() => (Program.form.Controls["bunifuFlatButton5"] as BunifuFlatButton).Text = "INJECTING"));
      krnlgay.krnlgayResult krnlgayResult = krnlgay.DllInjector.GetInstance.Inject(Application.StartupPath + string.Format("\\\\{0}", filename), PID);
      string text = "";
      string str = "";
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__1 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target1 = krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__1.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p1 = krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__1;
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, krnlgay.krnlgayResult, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj1 = krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__0, (object) krnlgayResult, krnlgay.krnlgayResult.DllNotFound);
      if (target1((CallSite) p1, obj1))
        text = string.Format("{0} is missing!", filename);
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__3 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__3 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target2 = krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__3.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p3 = krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__3;
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__2 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__2 = CallSite<Func<CallSite, object, krnlgay.krnlgayResult, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj2 = krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__2.Target((CallSite) krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__2, (object) krnlgayResult, krnlgay.krnlgayResult.Failed);
      if (target2((CallSite) p3, obj2))
        text = "Failed to inject for unknown reason.";
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__5 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__5 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target3 = krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__5.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p5 = krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__5;
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__4 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__4 = CallSite<Func<CallSite, object, krnlgay.krnlgayResult, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj3 = krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__4.Target((CallSite) krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__4, (object) krnlgayResult, krnlgay.krnlgayResult.Success);
      if (target3((CallSite) p5, obj3))
        krnl_monaco.injectedPID = PID;
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__7 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__7 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target4 = krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__7.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p7 = krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__7;
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__6 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__6 = CallSite<Func<CallSite, object, krnlgay.krnlgayResult, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj4 = krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__6.Target((CallSite) krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__6, (object) krnlgayResult, krnlgay.krnlgayResult.threaderr);
      if (target4((CallSite) p7, obj4))
      {
        text = "Caught Thread Error";
        str = "Unknown Error";
      }
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__8 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__8 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (!krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__8.Target((CallSite) krnl_monaco.\u003C\u003Eo__128.\u003C\u003Ep__8, (object) !string.IsNullOrEmpty(text)))
        return true;
      Program.injecting = false;
      Program.failed_inject = true;
      int num = (int) MessageBox.Show(text, str != "" ? str : "Krnl Error");
      return false;
    }

    private void unnamedESPToolStripMenuItem_Click(object sender, EventArgs e) => krnl_monaco.Pipe("loadstring(game:HttpGet('https://ic3w0lf.xyz/rblx/protoesp.lua', true))()");

    private void timer1_Tick(object sender, EventArgs e)
    {
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__0, (object) Settings.Default.remove_crash_logs))
      {
        try
        {
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__1 == null)
          {
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__1.Target((CallSite) krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__1, (object) Directory.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\Roblox\\logs\\archive")))
          {
            Directory.Delete(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\Roblox\\logs\\archive", true);
          }
          else
          {
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__2 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__2 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__2.Target((CallSite) krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__2, (object) Directory.Exists(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86) + "\\Roblox\\logs\\archive")))
              Directory.Delete(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86) + "\\Roblox\\logs\\archive", true);
          }
        }
        catch
        {
        }
      }
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__3 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__3 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if ((krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__3.Target((CallSite) krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__3, (object) Settings.Default.autoinject) ? 1 : 0) == 0)
        return;
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__5 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__5 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target1 = krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__5.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p5 = krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__5;
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__4 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__4 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.GreaterThan, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj1 = krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__4.Target((CallSite) krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__4, (object) Process.GetProcessesByName("RobloxPlayerLauncher").Length, 0);
      if (target1((CallSite) p5, obj1))
        krnl_monaco.launcherDetected = true;
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__6 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__6 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__6.Target((CallSite) krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__6, (object) krnl_monaco.launcherDetected))
      {
        try
        {
          try
          {
            krnl_monaco.injectedPID = 0;
          }
          catch (ArgumentException ex)
          {
          }
        }
        catch (Win32Exception ex)
        {
        }
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__10 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__10 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        Func<CallSite, object, bool> target2 = krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__10.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Func<CallSite, object, bool>> p10 = krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__10;
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__7 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__7 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj2 = krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__7.Target((CallSite) krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__7, (object) Process.GetProcessesByName("RobloxPlayerLauncher").Length, 0);
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__9 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__9 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsFalse, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        object obj3;
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (!krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__9.Target((CallSite) krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__9, obj2))
        {
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__8 == null)
          {
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__8 = CallSite<Func<CallSite, object, bool, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.BinaryOperationLogical, ExpressionType.And, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          obj3 = krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__8.Target((CallSite) krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__8, obj2, (uint) Process.GetProcessesByName("RobloxPlayerBeta").Length > 0U);
        }
        else
          obj3 = obj2;
        if (target2((CallSite) p10, obj3))
        {
          krnl_monaco.injectedPID = 0;
          krnl_monaco.launcherDetected = false;
          krnl_monaco.timeout = 6.0;
          new Thread((ThreadStart) (() =>
          {
            this.Invoke((Delegate) (() => this.bunifuFlatButton5.Text = "Injecting..."));
            Process[] processesByName = Process.GetProcessesByName("RobloxPlayerBeta");
            int num;
            for (num = 0; processesByName.Length == 0 && num != 10; ++num)
              processesByName = Process.GetProcessesByName("RobloxPlayerBeta");
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__12 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__12 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            Func<CallSite, object, bool> target11 = krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__12.Target;
            // ISSUE: reference to a compiler-generated field
            CallSite<Func<CallSite, object, bool>> p12 = krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__12;
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__11 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__11 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.NotEqual, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            object obj12 = krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__11.Target((CallSite) krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__11, (object) num, 10);
            if (!target11((CallSite) p12, obj12))
              return;
            IntPtr windowA = krnl_monaco.FindWindowA("WINDOWSCLIENT", "Roblox");
            int lpdwProcessId = 0;
            int windowThreadProcessId = (int) krnl_monaco.GetWindowThreadProcessId(windowA, out lpdwProcessId);
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__14 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__14 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            Func<CallSite, object, bool> target12 = krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__14.Target;
            // ISSUE: reference to a compiler-generated field
            CallSite<Func<CallSite, object, bool>> p14 = krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__14;
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__13 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__13 = CallSite<Func<CallSite, object, IntPtr, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.NotEqual, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            object obj13 = krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__13.Target((CallSite) krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__13, (object) windowA, IntPtr.Zero);
            if (target12((CallSite) p14, obj13))
            {
              List<string> list = ((IEnumerable<string>) processesByName[0].MainModule.FileName.Split('\\')).ToList<string>();
              list.Remove("RobloxPlayerBeta.exe");
              Program.writeToDir(string.Join("\\", list.ToArray()));
              try
              {
                this.injectdll((object) "krnl.dll", lpdwProcessId);
                this.anim_CompletedTask();
              }
              catch
              {
              }
            }
            this.Invoke((Delegate) (() => this.bunifuFlatButton5.Text = "INJECT"));
          })).Start();
          return;
        }
        --krnl_monaco.timeout;
      }
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__16 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__16 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target13 = krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__16.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p16 = krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__16;
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__15 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__15 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj14 = krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__15.Target((CallSite) krnl_monaco.\u003C\u003Eo__130.\u003C\u003Ep__15, (object) krnl_monaco.timeout, 0);
      if (!target13((CallSite) p16, obj14))
        return;
      krnl_monaco.launcherDetected = false;
      krnl_monaco.timeout = 6.0;
    }

    private void toolStripMenuItem1_Click_2(object sender, EventArgs e) => krnl.Pipe("loadstring(game:HttpGet('https://raw.githubusercontent.com/LaziestBoy/Krnl-Hub/master/Krnl-Hub.lua', true))()");

    private void toolStripMenuItem4_Click(object sender, EventArgs e) => krnl.Pipe("loadstring(game:HttpGet('https://raw.githubusercontent.com/CriShoux/OwlHub/master/OwlHub.txt'))();");

    private void pictureBox2_MouseEnter(object sender, EventArgs e) => this.toolTip1.SetToolTip((Control) sender, "Click to join the server");

    private void pictureBox2_MouseLeave(object sender, EventArgs e) => this.toolTip1.Hide((IWin32Window) sender);

    private void pictureBox2_MouseClick(object sender, MouseEventArgs e) => Process.Start("https://krnl.ca/invite.php");

    private void bunifuFlatButton8_Click(object sender, EventArgs e) => Process.Start("https://cdn.krnl.ca/getkey.php");

    private void toolStripMenuItem7_Click(object sender, EventArgs e) => Process.Start("https://krnl.ca/invite.php");

    private void krnl_MouseMove(object sender, MouseEventArgs e)
    {
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__0, (object) this.mMouseDown))
      {
        this.Refresh();
        this.SuspendLayout();
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__1 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__1.Target((CallSite) krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__1, (object) this.isonEdge))
        {
          if (this.Cursor == Cursors.PanSouth)
          {
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__3 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__3 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            Func<CallSite, object, bool> target = krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__3.Target;
            // ISSUE: reference to a compiler-generated field
            CallSite<Func<CallSite, object, bool>> p3 = krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__3;
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__2 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__2 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.GreaterThan, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            object obj = krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__2.Target((CallSite) krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__2, (object) e.Y, 350);
            if (target((CallSite) p3, obj))
            {
              this.heightUnchanged = false;
              this.SetBounds(this.Left, this.Top, this.Width, this.Height - (this.Height - e.Y));
            }
            else
            {
              this.heightUnchanged = true;
              this.SetBounds(this.Left, this.Top, this.Width, 350);
            }
          }
          if (this.Cursor == Cursors.PanEast)
          {
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__5 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__5 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            Func<CallSite, object, bool> target = krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__5.Target;
            // ISSUE: reference to a compiler-generated field
            CallSite<Func<CallSite, object, bool>> p5 = krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__5;
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__4 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__4 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.GreaterThan, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            object obj = krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__4.Target((CallSite) krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__4, (object) e.X, 690);
            if (target((CallSite) p5, obj))
            {
              this.widthUnchanged = false;
              this.SetBounds(this.Left, this.Top, this.Width - (this.Width - e.X), this.Height);
            }
            else
            {
              this.widthUnchanged = true;
              this.SetBounds(this.Left, this.Top, 690, this.Height);
            }
          }
          else if (this.Cursor == Cursors.PanSE)
            this.SetBounds(this.Left, this.Top, this.Width - (this.Width - e.X) < 690 ? 690 : this.Width - (this.Width - e.X), this.Height - (this.Height - e.Y) < 350 ? 350 : this.Height - (this.Height - e.Y));
          this.panel3.Width = this.Width;
        }
        this.ResumeLayout();
      }
      else
      {
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__9 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__9 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        Func<CallSite, object, bool> target1 = krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__9.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Func<CallSite, object, bool>> p9 = krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__9;
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__6 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__6 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.GreaterThan, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj1 = krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__6.Target((CallSite) krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__6, (object) e.Y, this.Height - 10);
        // ISSUE: reference to a compiler-generated field
        if (krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__8 == null)
        {
          // ISSUE: reference to a compiler-generated field
          krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__8 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsFalse, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        object obj2;
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (!krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__8.Target((CallSite) krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__8, obj1))
        {
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__7 == null)
          {
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__7 = CallSite<Func<CallSite, object, bool, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.BinaryOperationLogical, ExpressionType.And, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          obj2 = krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__7.Target((CallSite) krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__7, obj1, e.X < this.Width - 5);
        }
        else
          obj2 = obj1;
        if (target1((CallSite) p9, obj2))
        {
          this.Cursor = Cursors.PanSouth;
          this.isonEdge = true;
        }
        else
        {
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__13 == null)
          {
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__13 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          Func<CallSite, object, bool> target2 = krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__13.Target;
          // ISSUE: reference to a compiler-generated field
          CallSite<Func<CallSite, object, bool>> p13 = krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__13;
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__10 == null)
          {
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__10 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.GreaterThan, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          object obj3 = krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__10.Target((CallSite) krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__10, (object) e.X, this.Width - (this.mWidth + 2));
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__12 == null)
          {
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__12 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsFalse, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          object obj4;
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          if (!krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__12.Target((CallSite) krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__12, obj3))
          {
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__11 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__11 = CallSite<Func<CallSite, object, bool, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.BinaryOperationLogical, ExpressionType.And, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            obj4 = krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__11.Target((CallSite) krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__11, obj3, e.Y > this.Height - (this.mWidth + 2));
          }
          else
            obj4 = obj3;
          if (target2((CallSite) p13, obj4))
          {
            this.Cursor = Cursors.PanSE;
            this.isonEdge = true;
          }
          else
          {
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__17 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__17 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            Func<CallSite, object, bool> target3 = krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__17.Target;
            // ISSUE: reference to a compiler-generated field
            CallSite<Func<CallSite, object, bool>> p17 = krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__17;
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__14 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__14 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.GreaterThan, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            object obj5 = krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__14.Target((CallSite) krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__14, (object) e.X, this.Width - 5);
            // ISSUE: reference to a compiler-generated field
            if (krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__16 == null)
            {
              // ISSUE: reference to a compiler-generated field
              krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__16 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsFalse, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            object obj6;
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            if (!krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__16.Target((CallSite) krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__16, obj5))
            {
              // ISSUE: reference to a compiler-generated field
              if (krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__15 == null)
              {
                // ISSUE: reference to a compiler-generated field
                krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__15 = CallSite<Func<CallSite, object, bool, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.BinaryOperationLogical, ExpressionType.And, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
                {
                  CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
                  CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
                }));
              }
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              obj6 = krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__15.Target((CallSite) krnl_monaco.\u003C\u003Eo__138.\u003C\u003Ep__15, obj5, e.Y > this.button1.Size.Height);
            }
            else
              obj6 = obj5;
            if (target3((CallSite) p17, obj6))
            {
              this.Cursor = Cursors.PanEast;
              this.isonEdge = true;
            }
            else
            {
              this.Cursor = Cursors.Default;
              this.isonEdge = false;
            }
          }
        }
      }
    }

    private void krnl_MouseDown(object sender, MouseEventArgs e)
    {
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__139.\u003C\u003Ep__1 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__139.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target = krnl_monaco.\u003C\u003Eo__139.\u003C\u003Ep__1.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p1 = krnl_monaco.\u003C\u003Eo__139.\u003C\u003Ep__1;
      // ISSUE: reference to a compiler-generated field
      if (krnl_monaco.\u003C\u003Eo__139.\u003C\u003Ep__0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        krnl_monaco.\u003C\u003Eo__139.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, MouseButtons, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj = krnl_monaco.\u003C\u003Eo__139.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__139.\u003C\u003Ep__0, (object) e.Button, MouseButtons.Left);
      if (!target((CallSite) p1, obj))
        return;
      this.mMouseDown = true;
    }

    private void krnl_MouseUp(object sender, MouseEventArgs e) => this.mMouseDown = false;

    private void bunifuFlatButton7_Click(object sender, EventArgs e)
    {
    }

    private async void anim_CompletedTask()
    {
      int j;
      for (j = 0; j < 70; j += 5)
      {
        await Task.Delay(1);
        this.panel3.BackColor = System.Drawing.Color.FromArgb(30, 144 - j, (int) byte.MaxValue - j);
      }
      for (j = 0; j < 69; j += 5)
      {
        await Task.Delay(1);
        this.panel3.BackColor = System.Drawing.Color.FromArgb(30, 74 + j, 185 + j);
      }
    }

    private async void anim_AwaitingTaskFinish()
    {
      while (this.Anim_ATF_break)
      {
        int j;
        for (j = 0; j < 70; ++j)
        {
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__143.\u003C\u003Ep__0 == null)
          {
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__143.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__143.\u003C\u003Ep__0.Target((CallSite) krnl_monaco.\u003C\u003Eo__143.\u003C\u003Ep__0, (object) !this.Anim_ATF_break))
          {
            this.panel3.BackColor = System.Drawing.Color.FromArgb(30, 144, (int) byte.MaxValue);
            break;
          }
          await Task.Delay(3);
          this.panel3.BackColor = System.Drawing.Color.FromArgb(30, 144 - j, (int) byte.MaxValue - j);
        }
        for (j = 0; j < 69; ++j)
        {
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__143.\u003C\u003Ep__1 == null)
          {
            // ISSUE: reference to a compiler-generated field
            krnl_monaco.\u003C\u003Eo__143.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (krnl_monaco), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          if (krnl_monaco.\u003C\u003Eo__143.\u003C\u003Ep__1.Target((CallSite) krnl_monaco.\u003C\u003Eo__143.\u003C\u003Ep__1, (object) !this.Anim_ATF_break))
          {
            this.panel3.BackColor = System.Drawing.Color.FromArgb(30, 144, (int) byte.MaxValue);
            break;
          }
          await Task.Delay(3);
          this.panel3.BackColor = System.Drawing.Color.FromArgb(30, 74 + j, 185 + j);
        }
      }
    }

    private void bunifuFlatButton8_Click_1(object sender, EventArgs e)
    {
      this.Anim_ATF_break = true;
      this.anim_AwaitingTaskFinish();
      this.Anim_ATF_break = false;
    }

    private void bunifuFlatButton10_Click(object sender, EventArgs e)
    {
    }

    private void toolStripMenuItem8_Click(object sender, EventArgs e) => krnl_monaco.Pipe("loadstring(game:HttpGet('https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source'))()");

    private void toolStripMenuItem10_Click(object sender, EventArgs e)
    {
      TabPage contextTab = this.customTabControl1.contextTab;
      if (contextTab == null)
        return;
      Form form = new Form();
      form.Width = 200;
      form.Height = 50;
      form.MinimumSize = new Size(200, 50);
      form.MaximumSize = new Size(200, 50);
      form.FormBorderStyle = FormBorderStyle.None;
      form.Text = "What do you want to rename this tab to?";
      form.StartPosition = FormStartPosition.CenterParent;
      Form prompt = form;
      Label label1 = new Label();
      label1.Width = 200;
      label1.Height = 50;
      label1.Text = "What do you want to rename this tab to?";
      label1.Top = 0;
      label1.Left = 0;
      Label label2 = label1;
      TextBox textBox1 = new TextBox();
      textBox1.Left = 0;
      textBox1.Top = 30;
      textBox1.Width = 150;
      textBox1.Text = contextTab.Text;
      TextBox textBox2 = textBox1;
      Button button1 = new Button();
      button1.Text = "Ok";
      button1.Left = 150;
      button1.Width = 50;
      button1.Top = 30;
      button1.DialogResult = DialogResult.OK;
      Button button2 = button1;
      prompt.TopMost = true;
      button2.Click += (EventHandler) ((_param1, _param2) => prompt.Close());
      prompt.Controls.Add((Control) textBox2);
      prompt.Controls.Add((Control) button2);
      prompt.Controls.Add((Control) label2);
      prompt.AcceptButton = (IButtonControl) button2;
      string str = prompt.ShowDialog() == DialogResult.OK ? textBox2.Text : "";
      if (str.Length <= 0)
        return;
      contextTab.Text = str;
    }

    private void cMDXToolStripMenuItem_Click(object sender, EventArgs e) => krnl_monaco.Pipe("loadstring(game:HttpGet('https://raw.githubusercontent.com/CMD-X/CMD-X/master/Source', true))()");

    public class BrowserMenuRenderer : ToolStripProfessionalRenderer
    {
      public BrowserMenuRenderer()
        : base((ProfessionalColorTable) new krnl_monaco.BrowserColors())
      {
      }
    }

    public class BrowserColors : ProfessionalColorTable
    {
      public override System.Drawing.Color ToolStripDropDownBackground => System.Drawing.Color.FromArgb(40, 40, 40);

      public override System.Drawing.Color ImageMarginGradientBegin => System.Drawing.Color.FromArgb(40, 40, 40);

      public override System.Drawing.Color ImageMarginGradientMiddle => System.Drawing.Color.FromArgb(40, 40, 40);

      public override System.Drawing.Color ImageMarginGradientEnd => System.Drawing.Color.FromArgb(40, 40, 40);

      public override System.Drawing.Color MenuBorder => System.Drawing.Color.FromArgb(45, 45, 45);

      public override System.Drawing.Color MenuItemBorder => System.Drawing.Color.FromArgb(45, 45, 45);

      public override System.Drawing.Color MenuItemSelected => System.Drawing.Color.FromArgb(45, 45, 45);

      public override System.Drawing.Color MenuStripGradientBegin => System.Drawing.Color.FromArgb(40, 40, 40);

      public override System.Drawing.Color MenuStripGradientEnd => System.Drawing.Color.FromArgb(45, 45, 45);

      public override System.Drawing.Color MenuItemSelectedGradientBegin => System.Drawing.Color.FromArgb(40, 40, 40);

      public override System.Drawing.Color MenuItemSelectedGradientEnd => System.Drawing.Color.FromArgb(40, 40, 40);

      public override System.Drawing.Color MenuItemPressedGradientBegin => System.Drawing.Color.FromArgb(40, 40, 40);

      public override System.Drawing.Color MenuItemPressedGradientEnd => System.Drawing.Color.FromArgb(40, 40, 40);
    }

    private enum EdgeEnum
    {
      None,
      Right,
      Left,
      Top,
      Bottom,
      TopLeft,
      BottomRight,
    }
  }
}
