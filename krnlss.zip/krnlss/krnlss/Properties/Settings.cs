﻿// Decompiled with JetBrains decompiler
// Type: krnlss.Properties.Settings
// Assembly: krnlss, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 1D51A737-46C7-4798-AAF1-4373D41D8FFF
// Assembly location: C:\Users\Win10\Desktop\krnl\krnlss.exe

using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace krnlss.Properties
{
  [CompilerGenerated]
  [GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "11.0.0.0")]
  internal sealed class Settings : ApplicationSettingsBase
  {
    private static Settings defaultInstance = (Settings) SettingsBase.Synchronized((SettingsBase) new Settings());

    public static Settings Default => Settings.defaultInstance;

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("Environment.CurrentDirectory + \"\\\\scripts\"")]
    public string ScriptPath
    {
      get => (string) this[nameof (ScriptPath)];
      set => this[nameof (ScriptPath)] = (object) value;
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("false")]
    public bool autoinject
    {
      get => (bool) this[nameof (autoinject)];
      set => this[nameof (autoinject)] = (object) value;
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("false")]
    public bool topmostchecked
    {
      get => (bool) this[nameof (topmostchecked)];
      set => this[nameof (topmostchecked)] = (object) value;
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("true")]
    public bool fadein_out_opacity
    {
      get => (bool) this[nameof (fadein_out_opacity)];
      set => this[nameof (fadein_out_opacity)] = (object) value;
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("false")]
    public bool remove_crash_logs
    {
      get => (bool) this[nameof (remove_crash_logs)];
      set => this[nameof (remove_crash_logs)] = (object) value;
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public string cachedkey
    {
      get => (string) this[nameof (cachedkey)];
      set => this[nameof (cachedkey)] = (object) value;
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("false")]
    public bool monaco
    {
      get => (bool) this[nameof (monaco)];
      set => this[nameof (monaco)] = (object) value;
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public DateTime timer
    {
      get => this[nameof (timer)] != null ? Convert.ToDateTime(this[nameof (timer)]) : Convert.ToDateTime(DateTime.Now);
      set => this[nameof (timer)] = (object) value;
    }
  }
}
