﻿// Decompiled with JetBrains decompiler
// Type: krnlss.Program
// Assembly: krnlss, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 1D51A737-46C7-4798-AAF1-4373D41D8FFF
// Assembly location: C:\Users\Win10\Desktop\krnl\krnlss.exe

using Bunifu.Framework.UI;
using injection;
using krnlss.Properties;
using Microsoft.CSharp.RuntimeBinder;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace krnlss
{
  internal static class Program
  {
    public static Form form;
    public static List<string> tabScripts = new List<string>();
    public static bool injecting = false;
    public static bool failed_inject = false;
    public static int __i;
    public static bool debugme;
    public static int idx;

    private static int injectedPID { get; set; }

    [STAThread]
    public static void writerblx()
    {
    }

    public static void pc(bool start = false, bool urlPassed = false, int key = -1)
    {
      // ISSUE: reference to a compiler-generated field
      if (Program.\u003C\u003Eo__12.\u003C\u003Ep__0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        Program.\u003C\u003Eo__12.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (!Program.\u003C\u003Eo__12.\u003C\u003Ep__0.Target((CallSite) Program.\u003C\u003Eo__12.\u003C\u003Ep__0, (object) Program.debugme))
        return;
      // ISSUE: reference to a compiler-generated field
      if (Program.\u003C\u003Eo__12.\u003C\u003Ep__1 == null)
      {
        // ISSUE: reference to a compiler-generated field
        Program.\u003C\u003Eo__12.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (Program.\u003C\u003Eo__12.\u003C\u003Ep__1.Target((CallSite) Program.\u003C\u003Eo__12.\u003C\u003Ep__1, (object) start))
        System.IO.File.WriteAllText("pass check.txt", "");
      string str = Convert.ToString(Program.__i++);
      object obj;
      switch (key)
      {
        case 0:
          obj = (object) " No Key";
          break;
        case 1:
          obj = (object) " Key";
          break;
        default:
          obj = (object) "";
          break;
      }
      System.IO.File.AppendAllText("pass check.txt", str + (string) obj + (urlPassed ? " Url Passed" : "") + "\n");
    }

    public static bool isCompatible()
    {
      string str = (string) Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion").GetValue("ProductName");
      return str.IndexOf("Windows 8.1") != -1 || str.IndexOf("Windows 8") != -1 && str.IndexOf("1") != -1 || str.IndexOf("Windows 10") != -1;
    }

    public static bool hasFolder(string name, string path)
    {
      foreach (FileSystemInfo directory in new DirectoryInfo(path).GetDirectories())
      {
        // ISSUE: reference to a compiler-generated field
        if (Program.\u003C\u003Eo__14.\u003C\u003Ep__1 == null)
        {
          // ISSUE: reference to a compiler-generated field
          Program.\u003C\u003Eo__14.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        Func<CallSite, object, bool> target = Program.\u003C\u003Eo__14.\u003C\u003Ep__1.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Func<CallSite, object, bool>> p1 = Program.\u003C\u003Eo__14.\u003C\u003Ep__1;
        // ISSUE: reference to a compiler-generated field
        if (Program.\u003C\u003Eo__14.\u003C\u003Ep__0 == null)
        {
          // ISSUE: reference to a compiler-generated field
          Program.\u003C\u003Eo__14.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj = Program.\u003C\u003Eo__14.\u003C\u003Ep__0.Target((CallSite) Program.\u003C\u003Eo__14.\u003C\u003Ep__0, (object) directory.Name, name);
        if (target((CallSite) p1, obj))
          return true;
      }
      return false;
    }

    public static bool hasFile(string name, string path)
    {
      foreach (FileSystemInfo file in new DirectoryInfo(path).GetFiles())
      {
        // ISSUE: reference to a compiler-generated field
        if (Program.\u003C\u003Eo__15.\u003C\u003Ep__1 == null)
        {
          // ISSUE: reference to a compiler-generated field
          Program.\u003C\u003Eo__15.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        Func<CallSite, object, bool> target = Program.\u003C\u003Eo__15.\u003C\u003Ep__1.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Func<CallSite, object, bool>> p1 = Program.\u003C\u003Eo__15.\u003C\u003Ep__1;
        // ISSUE: reference to a compiler-generated field
        if (Program.\u003C\u003Eo__15.\u003C\u003Ep__0 == null)
        {
          // ISSUE: reference to a compiler-generated field
          Program.\u003C\u003Eo__15.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj = Program.\u003C\u003Eo__15.\u003C\u003Ep__0.Target((CallSite) Program.\u003C\u003Eo__15.\u003C\u003Ep__0, (object) file.Name, name);
        if (target((CallSite) p1, obj))
          return true;
      }
      return false;
    }

    private static void LoadReferencedAssembly(Assembly assembly)
    {
      foreach (AssemblyName referencedAssembly in assembly.GetReferencedAssemblies())
      {
        AssemblyName name = referencedAssembly;
        if (!((IEnumerable<Assembly>) AppDomain.CurrentDomain.GetAssemblies()).Any<Assembly>((Func<Assembly, bool>) (a => a.FullName == name.FullName)))
          Program.LoadReferencedAssembly(Assembly.Load(name));
      }
    }

    public static void test()
    {
    }

    [STAThread]
    private static void Main()
    {
      if (!System.IO.File.Exists("krnlss.exe.config"))
      {
        System.IO.File.WriteAllText("krnlss.exe.config", "<?xml version=\"1.0\" encoding=\"utf-8\" ?><configuration><runtime><assemblyBinding xmlns=\"urn:schemas-microsoft-com:asm.v1\"><probing privatePath=\"bin;bin/src\" /></assemblyBinding></runtime></configuration>");
        Task.Delay(500).GetAwaiter().GetResult();
        Process.Start("krnlss.exe");
        Environment.Exit(0);
      }
      Program.test();
      try
      {
        string[] strArray = new string[4]
        {
          "CefSharp.dll",
          "CefSharp.Core.dll",
          "CefSharp.WinForms.dll",
          "CefSharp.OffScreen.dll"
        };
        foreach (string path3 in strArray)
        {
          try
          {
            Program.LoadReferencedAssembly(Assembly.LoadFrom(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "bin/src", path3)));
          }
          catch
          {
          }
        }
      }
      catch (Exception ex)
      {
      }
      try
      {
        string[] strArray = new string[2]
        {
          "ScintillaNET.dll",
          "Bunifu_UI_v1.5.3.dll"
        };
        foreach (string path3 in strArray)
        {
          try
          {
            Program.LoadReferencedAssembly(Assembly.LoadFrom(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "bin", path3)));
          }
          catch
          {
          }
        }
      }
      catch (Exception ex)
      {
      }
      Program.test();
      ServicePointManager.Expect100Continue = true;
      // ISSUE: reference to a compiler-generated field
      if (Program.\u003C\u003Eo__18.\u003C\u003Ep__0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        Program.\u003C\u003Eo__18.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (Program.\u003C\u003Eo__18.\u003C\u003Ep__0.Target((CallSite) Program.\u003C\u003Eo__18.\u003C\u003Ep__0, (object) !Program.isCompatible()))
      {
        int num = (int) MessageBox.Show("You do not have Windows 8.1 or Windows 10!");
        Environment.Exit(1);
      }
      else
      {
        Program.test();
        Process[] processes = Process.GetProcesses();
        for (int index = 0; index < processes.Length; ++index)
        {
          if (processes[index] != Process.GetCurrentProcess())
          {
            if (((IEnumerable<string>) new string[2]
            {
              "krnl",
              "krnlss"
            }).ToList<string>().IndexOf(processes[index].ProcessName.Split('.')[0].ToLower()) != -1)
            {
              try
              {
                processes[index].CloseMainWindow();
              }
              catch
              {
              }
            }
          }
        }
        Program.test();
        // ISSUE: reference to a compiler-generated field
        if (Program.\u003C\u003Eo__18.\u003C\u003Ep__1 == null)
        {
          // ISSUE: reference to a compiler-generated field
          Program.\u003C\u003Eo__18.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (Program.\u003C\u003Eo__18.\u003C\u003Ep__1.Target((CallSite) Program.\u003C\u003Eo__18.\u003C\u003Ep__1, (object) !Directory.Exists("workspace")))
          Directory.CreateDirectory("workspace");
        // ISSUE: reference to a compiler-generated field
        if (Program.\u003C\u003Eo__18.\u003C\u003Ep__2 == null)
        {
          // ISSUE: reference to a compiler-generated field
          Program.\u003C\u003Eo__18.\u003C\u003Ep__2 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (Program.\u003C\u003Eo__18.\u003C\u003Ep__2.Target((CallSite) Program.\u003C\u003Eo__18.\u003C\u003Ep__2, (object) !Directory.Exists("scripts")))
          Directory.CreateDirectory("scripts");
        // ISSUE: reference to a compiler-generated field
        if (Program.\u003C\u003Eo__18.\u003C\u003Ep__3 == null)
        {
          // ISSUE: reference to a compiler-generated field
          Program.\u003C\u003Eo__18.\u003C\u003Ep__3 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (Program.\u003C\u003Eo__18.\u003C\u003Ep__3.Target((CallSite) Program.\u003C\u003Eo__18.\u003C\u003Ep__3, (object) !Directory.Exists("autoexec")))
          Directory.CreateDirectory("autoexec");
        Program.test();
        Program.writerblx();
        // ISSUE: reference to a compiler-generated field
        if (Program.\u003C\u003Eo__18.\u003C\u003Ep__4 == null)
        {
          // ISSUE: reference to a compiler-generated field
          Program.\u003C\u003Eo__18.\u003C\u003Ep__4 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (Program.\u003C\u003Eo__18.\u003C\u003Ep__4.Target((CallSite) Program.\u003C\u003Eo__18.\u003C\u003Ep__4, (object) System.IO.File.Exists("krnl.exe.bak")))
          System.IO.File.Delete("krnl.exe.bak");
        Program.test();
        Stack<string> source = new Stack<string>((IEnumerable<string>) Environment.CurrentDirectory.Split('\\'));
        bool flag = false;
        source.Reverse<string>();
        while (source.Count != 0)
        {
          // ISSUE: reference to a compiler-generated field
          if (Program.\u003C\u003Eo__18.\u003C\u003Ep__7 == null)
          {
            // ISSUE: reference to a compiler-generated field
            Program.\u003C\u003Eo__18.\u003C\u003Ep__7 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          Func<CallSite, object, bool> target1 = Program.\u003C\u003Eo__18.\u003C\u003Ep__7.Target;
          // ISSUE: reference to a compiler-generated field
          CallSite<Func<CallSite, object, bool>> p7 = Program.\u003C\u003Eo__18.\u003C\u003Ep__7;
          // ISSUE: reference to a compiler-generated field
          if (Program.\u003C\u003Eo__18.\u003C\u003Ep__6 == null)
          {
            // ISSUE: reference to a compiler-generated field
            Program.\u003C\u003Eo__18.\u003C\u003Ep__6 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          Func<CallSite, object, string, object> target2 = Program.\u003C\u003Eo__18.\u003C\u003Ep__6.Target;
          // ISSUE: reference to a compiler-generated field
          CallSite<Func<CallSite, object, string, object>> p6 = Program.\u003C\u003Eo__18.\u003C\u003Ep__6;
          // ISSUE: reference to a compiler-generated field
          if (Program.\u003C\u003Eo__18.\u003C\u003Ep__5 == null)
          {
            // ISSUE: reference to a compiler-generated field
            Program.\u003C\u003Eo__18.\u003C\u003Ep__5 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Add, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          object obj1 = Program.\u003C\u003Eo__18.\u003C\u003Ep__5.Target((CallSite) Program.\u003C\u003Eo__18.\u003C\u003Ep__5, (object) string.Join("\\", ((IEnumerable<string>) source.ToArray()).Reverse<string>()), "\\");
          string tempPath = Path.GetTempPath();
          object obj2 = target2((CallSite) p6, obj1, tempPath);
          if (target1((CallSite) p7, obj2))
          {
            flag = true;
            break;
          }
          source.Pop();
        }
        // ISSUE: reference to a compiler-generated field
        if (Program.\u003C\u003Eo__18.\u003C\u003Ep__9 == null)
        {
          // ISSUE: reference to a compiler-generated field
          Program.\u003C\u003Eo__18.\u003C\u003Ep__9 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        Func<CallSite, object, bool> target = Program.\u003C\u003Eo__18.\u003C\u003Ep__9.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Func<CallSite, object, bool>> p9 = Program.\u003C\u003Eo__18.\u003C\u003Ep__9;
        // ISSUE: reference to a compiler-generated field
        if (Program.\u003C\u003Eo__18.\u003C\u003Ep__8 == null)
        {
          // ISSUE: reference to a compiler-generated field
          Program.\u003C\u003Eo__18.\u003C\u003Ep__8 = CallSite<Func<CallSite, object, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.Not, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj = Program.\u003C\u003Eo__18.\u003C\u003Ep__8.Target((CallSite) Program.\u003C\u003Eo__18.\u003C\u003Ep__8, (object) flag);
        if (target((CallSite) p9, obj))
        {
          if (((IEnumerable<string>) Directory.GetCurrentDirectory().Split('\\')).ToList<string>().Last<string>().StartsWith("Rar$EX"))
            flag = true;
          if (Directory.GetCurrentDirectory().ToLower().IndexOf("c:\\windows\\system32") != -1)
          {
            flag = false;
            int num = (int) MessageBox.Show("You cannot run this here!\nYou must extract the zip file!", "Zip file detected.");
          }
        }
        // ISSUE: reference to a compiler-generated field
        if (Program.\u003C\u003Eo__18.\u003C\u003Ep__10 == null)
        {
          // ISSUE: reference to a compiler-generated field
          Program.\u003C\u003Eo__18.\u003C\u003Ep__10 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (Program.\u003C\u003Eo__18.\u003C\u003Ep__10.Target((CallSite) Program.\u003C\u003Eo__18.\u003C\u003Ep__10, (object) flag))
        {
          string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
          // ISSUE: reference to a compiler-generated field
          if (Program.\u003C\u003Eo__18.\u003C\u003Ep__11 == null)
          {
            // ISSUE: reference to a compiler-generated field
            Program.\u003C\u003Eo__18.\u003C\u003Ep__11 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          if (Program.\u003C\u003Eo__18.\u003C\u003Ep__11.Target((CallSite) Program.\u003C\u003Eo__18.\u003C\u003Ep__11, (object) !Directory.Exists(folderPath + "\\krnl")))
            Directory.CreateDirectory(folderPath + "\\krnl");
          string str = folderPath + "\\krnl";
          DirectoryInfo directoryInfo1 = new DirectoryInfo(str);
          DirectoryInfo directoryInfo2 = new DirectoryInfo(Environment.CurrentDirectory);
          directoryInfo2.GetDirectories();
          FileInfo[] files = directoryInfo2.GetFiles();
          int num1 = (int) MessageBox.Show("You cannot run this here!\nExtracting the zip file to your Desktop.", "Zip file detected.");
          int num2 = (int) MessageBox.Show(Process.GetCurrentProcess().MainModule.FileName);
          for (int index = 0; index < files.Length; ++index)
          {
            // ISSUE: reference to a compiler-generated field
            if (Program.\u003C\u003Eo__18.\u003C\u003Ep__12 == null)
            {
              // ISSUE: reference to a compiler-generated field
              Program.\u003C\u003Eo__18.\u003C\u003Ep__12 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
              {
                CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
              }));
            }
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            if (Program.\u003C\u003Eo__18.\u003C\u003Ep__12.Target((CallSite) Program.\u003C\u003Eo__18.\u003C\u003Ep__12, (object) !Program.hasFile(files[index].Name, str)))
              files[index].CopyTo(files[index].FullName.Replace(Environment.CurrentDirectory, str), true);
          }
          Process.Start(str);
          Process.Start(new ProcessStartInfo()
          {
            WorkingDirectory = str,
            FileName = "krnl.exe",
            CreateNoWindow = true
          });
          Environment.Exit(1);
        }
        else
        {
          Program.test();
          if (!Settings.Default.monaco)
          {
            Program.form = (Form) new krnl();
            new Thread((ThreadStart) (() =>
            {
              while (true)
              {
                do
                {
                  Task.Delay(500).GetAwaiter().GetResult();
                  if (krnl_monaco.findpipe("krnlpipe"))
                  {
                    Program.form.Invoke((Delegate) (() => (Program.form.Controls["bunifuFlatButton5"] as BunifuFlatButton).Text = "INJECTED"));
                    Program.injecting = false;
                    Program.failed_inject = false;
                  }
                }
                while (Program.injecting && !Program.failed_inject && (Process.GetProcessesByName("RobloxPlayerBeta").Length != 0 || Process.GetProcessesByName("RobloxPlayerLauncher").Length != 0));
                Program.form.Invoke((Delegate) (() => (Program.form.Controls["bunifuFlatButton5"] as BunifuFlatButton).Text = "INJECT"));
                Program.injecting = false;
                Program.failed_inject = false;
              }
            })).Start();
          }
          else
          {
            Program.form = (Form) new krnl_monaco();
            new Thread((ThreadStart) (() =>
            {
              while (true)
              {
                do
                {
                  Task.Delay(500).GetAwaiter().GetResult();
                  if (krnl_monaco.findpipe("krnlpipe"))
                  {
                    Program.form.Invoke((Delegate) (() => (Program.form.Controls["bunifuFlatButton5"] as BunifuFlatButton).Text = "INJECTED"));
                    Program.injecting = false;
                    Program.failed_inject = false;
                  }
                }
                while (Program.injecting && !Program.failed_inject && (Process.GetProcessesByName("RobloxPlayerBeta").Length != 0 || Process.GetProcessesByName("RobloxPlayerLauncher").Length != 0));
                Program.form.Invoke((Delegate) (() => (Program.form.Controls["bunifuFlatButton5"] as BunifuFlatButton).Text = "INJECT"));
                Program.injecting = false;
                Program.failed_inject = false;
              }
            })).Start();
          }
          Program.test();
          Program.form.Width = 690;
          Program.form.Opacity = 0.0;
          Application.Run(Program.form);
          Program.form.Load += new EventHandler(Program.Form_Activated);
          Program.form.Disposed += new EventHandler(Program.Form_Disposed);
          Program.form.FormClosing += new FormClosingEventHandler(Program.Form_FormClosing);
          Process.GetCurrentProcess().Disposed += new EventHandler(Program.Program_Disposed);
          Process.GetCurrentProcess().Exited += new EventHandler(Program.Program_Exited);
          AppDomain.CurrentDomain.ProcessExit += new EventHandler(Program.CurrentDomain_ProcessExit);
          Program.test();
        }
      }
    }

    private static void Program_Disposed(object sender, EventArgs e)
    {
      if (!Settings.Default.monaco)
        return;
      int num = (int) MessageBox.Show(((krnl_monaco) Program.form).customTabControl1.TabCount.ToString());
    }

    private static void Program_Exited(object sender, EventArgs e)
    {
      if (!Settings.Default.monaco)
        return;
      int num = (int) MessageBox.Show(((krnl_monaco) Program.form).customTabControl1.TabCount.ToString());
    }

    private static void Form_FormClosing(object sender, FormClosingEventArgs e)
    {
      if (!Settings.Default.monaco)
        return;
      int num = (int) MessageBox.Show(((krnl_monaco) Program.form).customTabControl1.TabCount.ToString());
    }

    private static void Form_Disposed(object sender, EventArgs e)
    {
      if (!Settings.Default.monaco)
        return;
      int num = (int) MessageBox.Show(((krnl_monaco) Program.form).customTabControl1.TabCount.ToString());
    }

    private static void CurrentDomain_ProcessExit(object sender, EventArgs e)
    {
      if (!Settings.Default.monaco)
        return;
      int num = (int) MessageBox.Show(((krnl_monaco) Program.form).customTabControl1.TabCount.ToString());
    }

    public static void writeToDir(string directory)
    {
    }

    public static bool injectdll(object filename, int PID)
    {
      krnlgay.krnlgayResult krnlgayResult = krnlgay.DllInjector.GetInstance.Inject(Application.StartupPath + string.Format("\\\\{0}", filename), PID);
      string text = "";
      string str = "";
      // ISSUE: reference to a compiler-generated field
      if (Program.\u003C\u003Eo__25.\u003C\u003Ep__1 == null)
      {
        // ISSUE: reference to a compiler-generated field
        Program.\u003C\u003Eo__25.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target1 = Program.\u003C\u003Eo__25.\u003C\u003Ep__1.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p1 = Program.\u003C\u003Eo__25.\u003C\u003Ep__1;
      // ISSUE: reference to a compiler-generated field
      if (Program.\u003C\u003Eo__25.\u003C\u003Ep__0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        Program.\u003C\u003Eo__25.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, krnlgay.krnlgayResult, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj1 = Program.\u003C\u003Eo__25.\u003C\u003Ep__0.Target((CallSite) Program.\u003C\u003Eo__25.\u003C\u003Ep__0, (object) krnlgayResult, krnlgay.krnlgayResult.DllNotFound);
      if (target1((CallSite) p1, obj1))
        text = string.Format("{0} is missing!", filename);
      // ISSUE: reference to a compiler-generated field
      if (Program.\u003C\u003Eo__25.\u003C\u003Ep__3 == null)
      {
        // ISSUE: reference to a compiler-generated field
        Program.\u003C\u003Eo__25.\u003C\u003Ep__3 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target2 = Program.\u003C\u003Eo__25.\u003C\u003Ep__3.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p3 = Program.\u003C\u003Eo__25.\u003C\u003Ep__3;
      // ISSUE: reference to a compiler-generated field
      if (Program.\u003C\u003Eo__25.\u003C\u003Ep__2 == null)
      {
        // ISSUE: reference to a compiler-generated field
        Program.\u003C\u003Eo__25.\u003C\u003Ep__2 = CallSite<Func<CallSite, object, krnlgay.krnlgayResult, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj2 = Program.\u003C\u003Eo__25.\u003C\u003Ep__2.Target((CallSite) Program.\u003C\u003Eo__25.\u003C\u003Ep__2, (object) krnlgayResult, krnlgay.krnlgayResult.Failed);
      if (target2((CallSite) p3, obj2))
        text = "Failed to inject for unknown reason.";
      // ISSUE: reference to a compiler-generated field
      if (Program.\u003C\u003Eo__25.\u003C\u003Ep__5 == null)
      {
        // ISSUE: reference to a compiler-generated field
        Program.\u003C\u003Eo__25.\u003C\u003Ep__5 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target3 = Program.\u003C\u003Eo__25.\u003C\u003Ep__5.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p5 = Program.\u003C\u003Eo__25.\u003C\u003Ep__5;
      // ISSUE: reference to a compiler-generated field
      if (Program.\u003C\u003Eo__25.\u003C\u003Ep__4 == null)
      {
        // ISSUE: reference to a compiler-generated field
        Program.\u003C\u003Eo__25.\u003C\u003Ep__4 = CallSite<Func<CallSite, object, krnlgay.krnlgayResult, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj3 = Program.\u003C\u003Eo__25.\u003C\u003Ep__4.Target((CallSite) Program.\u003C\u003Eo__25.\u003C\u003Ep__4, (object) krnlgayResult, krnlgay.krnlgayResult.Success);
      if (target3((CallSite) p5, obj3))
        Program.injectedPID = PID;
      // ISSUE: reference to a compiler-generated field
      if (Program.\u003C\u003Eo__25.\u003C\u003Ep__7 == null)
      {
        // ISSUE: reference to a compiler-generated field
        Program.\u003C\u003Eo__25.\u003C\u003Ep__7 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target4 = Program.\u003C\u003Eo__25.\u003C\u003Ep__7.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p7 = Program.\u003C\u003Eo__25.\u003C\u003Ep__7;
      // ISSUE: reference to a compiler-generated field
      if (Program.\u003C\u003Eo__25.\u003C\u003Ep__6 == null)
      {
        // ISSUE: reference to a compiler-generated field
        Program.\u003C\u003Eo__25.\u003C\u003Ep__6 = CallSite<Func<CallSite, object, krnlgay.krnlgayResult, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj4 = Program.\u003C\u003Eo__25.\u003C\u003Ep__6.Target((CallSite) Program.\u003C\u003Eo__25.\u003C\u003Ep__6, (object) krnlgayResult, krnlgay.krnlgayResult.threaderr);
      if (target4((CallSite) p7, obj4))
      {
        text = "Caught Thread Error";
        str = "Unknown Error";
      }
      // ISSUE: reference to a compiler-generated field
      if (Program.\u003C\u003Eo__25.\u003C\u003Ep__8 == null)
      {
        // ISSUE: reference to a compiler-generated field
        Program.\u003C\u003Eo__25.\u003C\u003Ep__8 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (Program), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if (!Program.\u003C\u003Eo__25.\u003C\u003Ep__8.Target((CallSite) Program.\u003C\u003Eo__25.\u003C\u003Ep__8, (object) !string.IsNullOrEmpty(text)))
        return true;
      int num = (int) MessageBox.Show(text, str != "" ? str : "Krnl Error");
      return false;
    }

    private static void Form_Activated(object sender, EventArgs e)
    {
      while (Program.form.Opacity < 1.0)
      {
        Program.form.Opacity += 0.05;
        Task.Delay(1).GetAwaiter().GetResult();
      }
    }
  }
}
