﻿// Decompiled with JetBrains decompiler
// Type: krnlss.Games
// Assembly: krnlss, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 1D51A737-46C7-4798-AAF1-4373D41D8FFF
// Assembly location: C:\Users\Win10\Desktop\krnl\krnlss.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace krnlss
{
  public class Games : Form
  {
    public const int WM_NCLBUTTONDOWN = 161;
    public const int HT_CAPTION = 2;
    private List<Panel> listPanel = new List<Panel>();
    private int i;
    private IContainer components;
    private Panel panel1;
    private Button button1;
    private PictureBox pictureBox1;
    private Label label1;
    private PictureBox pictureBox2;
    private PictureBox pictureBox3;
    private PictureBox pictureBox4;
    private PictureBox pictureBox5;
    private PictureBox pictureBox6;
    private PictureBox pictureBox7;
    private PictureBox pictureBox8;
    private PictureBox pictureBox9;
    private PictureBox pictureBox10;
    private PictureBox pictureBox11;
    private PictureBox pictureBox12;
    private Button button2;
    private Button button3;
    private Panel panel2;
    private Panel panel3;
    private PictureBox pictureBox13;
    private PictureBox pictureBox14;
    private PictureBox pictureBox15;
    private PictureBox pictureBox16;
    private PictureBox pictureBox17;
    private PictureBox pictureBox18;
    private PictureBox pictureBox19;
    private PictureBox pictureBox20;
    private PictureBox pictureBox21;
    private PictureBox pictureBox22;
    private PictureBox pictureBox23;
    private PictureBox pictureBox24;

    [DllImport("user32.dll")]
    public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

    [DllImport("user32.dll")]
    public static extern bool ReleaseCapture();

    public Games() => this.InitializeComponent();

    private void button1_Click(object sender, EventArgs e) => this.Close();

    private void Games_Load(object sender, EventArgs e)
    {
      this.panel2.Visible = false;
      this.panel3.Visible = false;
      this.listPanel.Add(this.panel2);
      this.listPanel.Add(this.panel3);
      this.listPanel[this.i].BringToFront();
      this.listPanel[this.i].Visible = true;
    }

    private void panel1_MouseMove(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Left)
        return;
      Games.ReleaseCapture();
      Games.SendMessage(this.Handle, 161, 2, 0);
    }

    private void pictureBox1_Click(object sender, EventArgs e)
    {
      int num = (int) MessageBox.Show("Jxnt Scripts", "Credits");
      krnl.Pipe("loadstring(game:HttpGet('https://system-exodus.com/scripts/ninjalegends/NinjaLegendsV2.lua', true))()");
    }

    private void pictureBox2_Click(object sender, EventArgs e) => krnl.Pipe("loadstring(game:HttpGet('https://pastebin.com/raw/rT3UCQRs', true))();");

    private void pictureBox3_Click(object sender, EventArgs e) => krnl.Pipe("loadstring(game:HttpGet('https://pastebin.com/raw/cE6kQe1G', true))();");

    private void pictureBox4_Click(object sender, EventArgs e) => krnl.Pipe("loadstring(game:HttpGet('https://pastebin.com/raw/J420Y71u', true))();");

    private void pictureBox5_Click(object sender, EventArgs e) => krnl.Pipe("\r\n                while wait(0.5) do\r\n                local stuff = workspace:getDescendants()\r\n                for i=1,#stuff do\r\n                if stuff[i].Name == 'Hitbox' then\r\n                if stuff[i].Parent.Name ~= game.Players.LocalPlayer.Name then\r\n                stuff[i].Massless = true\r\n                stuff[i].Size = Vector3.new (100,100,100)\r\n                stuff[i].Transparency = 0.5\r\n                end\r\n                end\r\n                end\r\n                end\r\n            ");

    private void pictureBox7_Click(object sender, EventArgs e) => krnl.Pipe("\r\n                _G.ServerHop = false\r\n                _G.PercentageToHop = 25\r\n                _G.AutoEquipMask = false\r\n                _G.RepFarm = false\r\n                _G.AogiriFarm = false\r\n                _G.CCGFarm = false\r\n                _G.HumanFarm = false\r\n                _G.FarmAll = false\r\n                _G.PlayAsGhoul = false\r\n                _G.PlayAsCCG = false\r\n\r\n                loadstring(game:HttpGet(('https://pastebin.com/raw/x9She8BF'),true))()\r\n            ");

    private void pictureBox9_Click(object sender, EventArgs e) => krnl.Pipe("\r\n                local player = game.Players.LocalPlayer\r\n                local library = loadstring(game:HttpGet('https://pastebin.com/raw/JsdM2jiP',true))()\r\n                library.options.underlinecolor = 'rainbow'\r\n\r\n                -- Ranch Tab\r\n                local Ranch = library:CreateWindow('Ranch')\r\n                Ranch: Section('- Ranch -')\r\n                local Upgrade = Ranch:Toggle('Auto Upgrade Ranch', { flag = 'RU'})\r\n                local EquipBest = Ranch:Toggle('Auto Equip Pets', { flag = 'EP'})\r\n\r\n                --Auto Upgrade\r\n                spawn(function()\r\n                while wait(.01) do\r\n                                    if Ranch.flags.RU then\r\n                                    game:GetService('ReplicatedStorage').RemoteFunctions.MainRemoteFunction:InvokeServer('UpgradeRanch', false)\r\n                end\r\n                end\r\n                end)\r\n\r\n                --Auto Equip\r\n                spawn(function()\r\n                while wait(.01) do\r\n                                    if Ranch.flags.EP then\r\n                                    game:GetService('ReplicatedStorage').RemoteFunctions.MainRemoteFunction:InvokeServer('EquipTopPets')\r\n                end\r\n                end\r\n                end)\r\n            ");

    private void pictureBox8_Click(object sender, EventArgs e) => krnl.Pipe("loadstring(game:HttpGet('https://pastebin.com/raw/bCYBdgTD', true))();");

    private void pictureBox6_Click(object sender, EventArgs e) => krnl.Pipe("loadstring(game:HttpGet('https://pastebin.com/raw/ecVs72us', true))()");

    private void pictureBox10_Click(object sender, EventArgs e) => krnl.Pipe("loadstring(game:HttpGet('https://pastebin.com/raw/p2wJy279', true))()");

    private void pictureBox12_Click(object sender, EventArgs e)
    {
      krnl.Pipe("loadstring(game:HttpGet('https://pastebin.com/raw/WBfWy8Md', true))()");
      int num = (int) MessageBox.Show("This script was created by Jxnt#9946!");
    }

    private void pictureBox11_Click(object sender, EventArgs e) => krnl.Pipe("loadstring(game:HttpGet('https://pastebin.com/raw/Rge4t3Sh', true))()");

    private void button2_Click(object sender, EventArgs e)
    {
      if (this.i >= this.listPanel.Count - 1)
        return;
      this.listPanel[this.i].Visible = false;
      this.listPanel[++this.i].BringToFront();
      this.listPanel[this.i].Visible = true;
    }

    private void button3_Click(object sender, EventArgs e)
    {
      if (this.i <= 0)
        return;
      this.listPanel[this.i].Visible = false;
      this.listPanel[--this.i].BringToFront();
      this.listPanel[this.i].Visible = true;
    }

    private void pictureBox1_MouseHover(object sender, EventArgs e)
    {
    }

    private void panel1_Paint(object sender, PaintEventArgs e)
    {
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (Games));
      this.panel1 = new Panel();
      this.button3 = new Button();
      this.button2 = new Button();
      this.label1 = new Label();
      this.button1 = new Button();
      this.pictureBox1 = new PictureBox();
      this.pictureBox2 = new PictureBox();
      this.pictureBox3 = new PictureBox();
      this.pictureBox4 = new PictureBox();
      this.pictureBox5 = new PictureBox();
      this.pictureBox6 = new PictureBox();
      this.pictureBox7 = new PictureBox();
      this.pictureBox8 = new PictureBox();
      this.pictureBox9 = new PictureBox();
      this.pictureBox10 = new PictureBox();
      this.pictureBox11 = new PictureBox();
      this.pictureBox12 = new PictureBox();
      this.panel2 = new Panel();
      this.panel3 = new Panel();
      this.pictureBox13 = new PictureBox();
      this.pictureBox14 = new PictureBox();
      this.pictureBox15 = new PictureBox();
      this.pictureBox16 = new PictureBox();
      this.pictureBox17 = new PictureBox();
      this.pictureBox18 = new PictureBox();
      this.pictureBox19 = new PictureBox();
      this.pictureBox20 = new PictureBox();
      this.pictureBox21 = new PictureBox();
      this.pictureBox22 = new PictureBox();
      this.pictureBox23 = new PictureBox();
      this.pictureBox24 = new PictureBox();
      this.panel1.SuspendLayout();
      ((ISupportInitialize) this.pictureBox1).BeginInit();
      ((ISupportInitialize) this.pictureBox2).BeginInit();
      ((ISupportInitialize) this.pictureBox3).BeginInit();
      ((ISupportInitialize) this.pictureBox4).BeginInit();
      ((ISupportInitialize) this.pictureBox5).BeginInit();
      ((ISupportInitialize) this.pictureBox6).BeginInit();
      ((ISupportInitialize) this.pictureBox7).BeginInit();
      ((ISupportInitialize) this.pictureBox8).BeginInit();
      ((ISupportInitialize) this.pictureBox9).BeginInit();
      ((ISupportInitialize) this.pictureBox10).BeginInit();
      ((ISupportInitialize) this.pictureBox11).BeginInit();
      ((ISupportInitialize) this.pictureBox12).BeginInit();
      this.panel2.SuspendLayout();
      this.panel3.SuspendLayout();
      ((ISupportInitialize) this.pictureBox13).BeginInit();
      ((ISupportInitialize) this.pictureBox14).BeginInit();
      ((ISupportInitialize) this.pictureBox15).BeginInit();
      ((ISupportInitialize) this.pictureBox16).BeginInit();
      ((ISupportInitialize) this.pictureBox17).BeginInit();
      ((ISupportInitialize) this.pictureBox18).BeginInit();
      ((ISupportInitialize) this.pictureBox19).BeginInit();
      ((ISupportInitialize) this.pictureBox20).BeginInit();
      ((ISupportInitialize) this.pictureBox21).BeginInit();
      ((ISupportInitialize) this.pictureBox22).BeginInit();
      ((ISupportInitialize) this.pictureBox23).BeginInit();
      ((ISupportInitialize) this.pictureBox24).BeginInit();
      this.SuspendLayout();
      this.panel1.BackColor = Color.FromArgb(29, 29, 29);
      this.panel1.Controls.Add((Control) this.button3);
      this.panel1.Controls.Add((Control) this.button2);
      this.panel1.Controls.Add((Control) this.label1);
      this.panel1.Controls.Add((Control) this.button1);
      this.panel1.Dock = DockStyle.Top;
      this.panel1.Location = new Point(0, 0);
      this.panel1.Margin = new Padding(4, 4, 4, 4);
      this.panel1.Name = "panel1";
      this.panel1.Size = new Size(575, 41);
      this.panel1.TabIndex = 2;
      this.panel1.Paint += new PaintEventHandler(this.panel1_Paint);
      this.panel1.MouseMove += new MouseEventHandler(this.panel1_MouseMove);
      this.button3.BackColor = Color.FromArgb(29, 29, 29);
      this.button3.BackgroundImageLayout = ImageLayout.Center;
      this.button3.FlatAppearance.BorderSize = 0;
      this.button3.FlatStyle = FlatStyle.Flat;
      this.button3.Font = new Font("Corbel", 12f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.button3.ForeColor = Color.White;
      this.button3.Image = (Image) componentResourceManager.GetObject("button3.Image");
      this.button3.Location = new Point(435, 0);
      this.button3.Margin = new Padding(4, 4, 4, 4);
      this.button3.Name = "button3";
      this.button3.Size = new Size(47, 41);
      this.button3.TabIndex = 6;
      this.button3.UseVisualStyleBackColor = false;
      this.button3.Click += new EventHandler(this.button3_Click);
      this.button2.BackColor = Color.FromArgb(29, 29, 29);
      this.button2.BackgroundImageLayout = ImageLayout.Center;
      this.button2.FlatAppearance.BorderSize = 0;
      this.button2.FlatStyle = FlatStyle.Flat;
      this.button2.Font = new Font("Corbel", 12f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.button2.ForeColor = Color.White;
      this.button2.Image = (Image) componentResourceManager.GetObject("button2.Image");
      this.button2.Location = new Point(481, 0);
      this.button2.Margin = new Padding(4, 4, 4, 4);
      this.button2.Name = "button2";
      this.button2.Size = new Size(47, 41);
      this.button2.TabIndex = 5;
      this.button2.UseVisualStyleBackColor = false;
      this.button2.Click += new EventHandler(this.button2_Click);
      this.label1.AutoSize = true;
      this.label1.Font = new Font("Segoe UI", 11.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label1.ForeColor = Color.White;
      this.label1.Location = new Point(249, 9);
      this.label1.Margin = new Padding(4, 0, 4, 0);
      this.label1.Name = "label1";
      this.label1.Size = new Size(69, 25);
      this.label1.TabIndex = 4;
      this.label1.Text = nameof (Games);
      this.button1.BackColor = Color.FromArgb(29, 29, 29);
      this.button1.BackgroundImageLayout = ImageLayout.Center;
      this.button1.FlatAppearance.BorderSize = 0;
      this.button1.FlatStyle = FlatStyle.Flat;
      this.button1.Font = new Font("Corbel", 12f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.button1.ForeColor = Color.White;
      this.button1.Image = (Image) componentResourceManager.GetObject("button1.Image");
      this.button1.Location = new Point(528, 0);
      this.button1.Margin = new Padding(4, 4, 4, 4);
      this.button1.Name = "button1";
      this.button1.Size = new Size(47, 41);
      this.button1.TabIndex = 3;
      this.button1.UseVisualStyleBackColor = false;
      this.button1.Click += new EventHandler(this.button1_Click);
      this.pictureBox1.Image = (Image) componentResourceManager.GetObject("pictureBox1.Image");
      this.pictureBox1.Location = new Point(1, 0);
      this.pictureBox1.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox1.Name = "pictureBox1";
      this.pictureBox1.Size = new Size(133, 126);
      this.pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox1.TabIndex = 3;
      this.pictureBox1.TabStop = false;
      this.pictureBox1.Click += new EventHandler(this.pictureBox1_Click);
      this.pictureBox1.MouseHover += new EventHandler(this.pictureBox1_MouseHover);
      this.pictureBox2.Image = (Image) componentResourceManager.GetObject("pictureBox2.Image");
      this.pictureBox2.Location = new Point(143, 0);
      this.pictureBox2.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox2.Name = "pictureBox2";
      this.pictureBox2.Size = new Size(133, 126);
      this.pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox2.TabIndex = 4;
      this.pictureBox2.TabStop = false;
      this.pictureBox2.Click += new EventHandler(this.pictureBox2_Click);
      this.pictureBox3.Image = (Image) componentResourceManager.GetObject("pictureBox3.Image");
      this.pictureBox3.Location = new Point(284, 0);
      this.pictureBox3.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox3.Name = "pictureBox3";
      this.pictureBox3.Size = new Size(133, 126);
      this.pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox3.TabIndex = 5;
      this.pictureBox3.TabStop = false;
      this.pictureBox3.Click += new EventHandler(this.pictureBox3_Click);
      this.pictureBox4.Image = (Image) componentResourceManager.GetObject("pictureBox4.Image");
      this.pictureBox4.Location = new Point(425, 0);
      this.pictureBox4.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox4.Name = "pictureBox4";
      this.pictureBox4.Size = new Size(133, 126);
      this.pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox4.TabIndex = 6;
      this.pictureBox4.TabStop = false;
      this.pictureBox4.Click += new EventHandler(this.pictureBox4_Click);
      this.pictureBox5.Image = (Image) componentResourceManager.GetObject("pictureBox5.Image");
      this.pictureBox5.Location = new Point(1, 128);
      this.pictureBox5.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox5.Name = "pictureBox5";
      this.pictureBox5.Size = new Size(133, 126);
      this.pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox5.TabIndex = 7;
      this.pictureBox5.TabStop = false;
      this.pictureBox5.Click += new EventHandler(this.pictureBox5_Click);
      this.pictureBox6.Image = (Image) componentResourceManager.GetObject("pictureBox6.Image");
      this.pictureBox6.Location = new Point(1, 256);
      this.pictureBox6.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox6.Name = "pictureBox6";
      this.pictureBox6.Size = new Size(133, 126);
      this.pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox6.TabIndex = 8;
      this.pictureBox6.TabStop = false;
      this.pictureBox6.Click += new EventHandler(this.pictureBox6_Click);
      this.pictureBox7.Image = (Image) componentResourceManager.GetObject("pictureBox7.Image");
      this.pictureBox7.Location = new Point(143, 128);
      this.pictureBox7.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox7.Name = "pictureBox7";
      this.pictureBox7.Size = new Size(133, 126);
      this.pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox7.TabIndex = 9;
      this.pictureBox7.TabStop = false;
      this.pictureBox7.Click += new EventHandler(this.pictureBox7_Click);
      this.pictureBox8.Image = (Image) componentResourceManager.GetObject("pictureBox8.Image");
      this.pictureBox8.Location = new Point(425, 128);
      this.pictureBox8.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox8.Name = "pictureBox8";
      this.pictureBox8.Size = new Size(133, 126);
      this.pictureBox8.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox8.TabIndex = 11;
      this.pictureBox8.TabStop = false;
      this.pictureBox8.Click += new EventHandler(this.pictureBox8_Click);
      this.pictureBox9.Image = (Image) componentResourceManager.GetObject("pictureBox9.Image");
      this.pictureBox9.Location = new Point(284, 128);
      this.pictureBox9.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox9.Name = "pictureBox9";
      this.pictureBox9.Size = new Size(133, 126);
      this.pictureBox9.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox9.TabIndex = 10;
      this.pictureBox9.TabStop = false;
      this.pictureBox9.Click += new EventHandler(this.pictureBox9_Click);
      this.pictureBox10.Image = (Image) componentResourceManager.GetObject("pictureBox10.Image");
      this.pictureBox10.Location = new Point(143, 256);
      this.pictureBox10.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox10.Name = "pictureBox10";
      this.pictureBox10.Size = new Size(133, 126);
      this.pictureBox10.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox10.TabIndex = 12;
      this.pictureBox10.TabStop = false;
      this.pictureBox10.Click += new EventHandler(this.pictureBox10_Click);
      this.pictureBox11.Image = (Image) componentResourceManager.GetObject("pictureBox11.Image");
      this.pictureBox11.Location = new Point(425, 256);
      this.pictureBox11.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox11.Name = "pictureBox11";
      this.pictureBox11.Size = new Size(133, 126);
      this.pictureBox11.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox11.TabIndex = 14;
      this.pictureBox11.TabStop = false;
      this.pictureBox11.Click += new EventHandler(this.pictureBox11_Click);
      this.pictureBox12.Image = (Image) componentResourceManager.GetObject("pictureBox12.Image");
      this.pictureBox12.Location = new Point(284, 256);
      this.pictureBox12.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox12.Name = "pictureBox12";
      this.pictureBox12.Size = new Size(133, 126);
      this.pictureBox12.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox12.TabIndex = 13;
      this.pictureBox12.TabStop = false;
      this.pictureBox12.Click += new EventHandler(this.pictureBox12_Click);
      this.panel2.Controls.Add((Control) this.pictureBox1);
      this.panel2.Controls.Add((Control) this.pictureBox6);
      this.panel2.Controls.Add((Control) this.pictureBox10);
      this.panel2.Controls.Add((Control) this.pictureBox12);
      this.panel2.Controls.Add((Control) this.pictureBox11);
      this.panel2.Controls.Add((Control) this.pictureBox8);
      this.panel2.Controls.Add((Control) this.pictureBox4);
      this.panel2.Controls.Add((Control) this.pictureBox3);
      this.panel2.Controls.Add((Control) this.pictureBox9);
      this.panel2.Controls.Add((Control) this.pictureBox2);
      this.panel2.Controls.Add((Control) this.pictureBox7);
      this.panel2.Controls.Add((Control) this.pictureBox5);
      this.panel2.Location = new Point(8, 46);
      this.panel2.Margin = new Padding(4, 4, 4, 4);
      this.panel2.Name = "panel2";
      this.panel2.Size = new Size(559, 382);
      this.panel2.TabIndex = 15;
      this.panel3.Controls.Add((Control) this.pictureBox13);
      this.panel3.Controls.Add((Control) this.pictureBox14);
      this.panel3.Controls.Add((Control) this.pictureBox15);
      this.panel3.Controls.Add((Control) this.pictureBox16);
      this.panel3.Controls.Add((Control) this.pictureBox17);
      this.panel3.Controls.Add((Control) this.pictureBox18);
      this.panel3.Controls.Add((Control) this.pictureBox19);
      this.panel3.Controls.Add((Control) this.pictureBox20);
      this.panel3.Controls.Add((Control) this.pictureBox21);
      this.panel3.Controls.Add((Control) this.pictureBox22);
      this.panel3.Controls.Add((Control) this.pictureBox23);
      this.panel3.Controls.Add((Control) this.pictureBox24);
      this.panel3.Location = new Point(8, 46);
      this.panel3.Margin = new Padding(4, 4, 4, 4);
      this.panel3.Name = "panel3";
      this.panel3.Size = new Size(559, 382);
      this.panel3.TabIndex = 16;
      this.pictureBox13.Image = (Image) componentResourceManager.GetObject("pictureBox13.Image");
      this.pictureBox13.Location = new Point(1, 0);
      this.pictureBox13.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox13.Name = "pictureBox13";
      this.pictureBox13.Size = new Size(133, 126);
      this.pictureBox13.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox13.TabIndex = 3;
      this.pictureBox13.TabStop = false;
      this.pictureBox14.Image = (Image) componentResourceManager.GetObject("pictureBox14.Image");
      this.pictureBox14.Location = new Point(1, 256);
      this.pictureBox14.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox14.Name = "pictureBox14";
      this.pictureBox14.Size = new Size(133, 126);
      this.pictureBox14.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox14.TabIndex = 8;
      this.pictureBox14.TabStop = false;
      this.pictureBox15.Image = (Image) componentResourceManager.GetObject("pictureBox15.Image");
      this.pictureBox15.Location = new Point(143, 256);
      this.pictureBox15.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox15.Name = "pictureBox15";
      this.pictureBox15.Size = new Size(133, 126);
      this.pictureBox15.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox15.TabIndex = 12;
      this.pictureBox15.TabStop = false;
      this.pictureBox16.Image = (Image) componentResourceManager.GetObject("pictureBox16.Image");
      this.pictureBox16.Location = new Point(284, 256);
      this.pictureBox16.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox16.Name = "pictureBox16";
      this.pictureBox16.Size = new Size(133, 126);
      this.pictureBox16.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox16.TabIndex = 13;
      this.pictureBox16.TabStop = false;
      this.pictureBox17.Image = (Image) componentResourceManager.GetObject("pictureBox17.Image");
      this.pictureBox17.Location = new Point(425, 256);
      this.pictureBox17.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox17.Name = "pictureBox17";
      this.pictureBox17.Size = new Size(133, 126);
      this.pictureBox17.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox17.TabIndex = 14;
      this.pictureBox17.TabStop = false;
      this.pictureBox18.Image = (Image) componentResourceManager.GetObject("pictureBox18.Image");
      this.pictureBox18.Location = new Point(425, 128);
      this.pictureBox18.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox18.Name = "pictureBox18";
      this.pictureBox18.Size = new Size(133, 126);
      this.pictureBox18.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox18.TabIndex = 11;
      this.pictureBox18.TabStop = false;
      this.pictureBox19.Image = (Image) componentResourceManager.GetObject("pictureBox19.Image");
      this.pictureBox19.Location = new Point(425, 0);
      this.pictureBox19.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox19.Name = "pictureBox19";
      this.pictureBox19.Size = new Size(133, 126);
      this.pictureBox19.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox19.TabIndex = 6;
      this.pictureBox19.TabStop = false;
      this.pictureBox20.Image = (Image) componentResourceManager.GetObject("pictureBox20.Image");
      this.pictureBox20.Location = new Point(284, 0);
      this.pictureBox20.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox20.Name = "pictureBox20";
      this.pictureBox20.Size = new Size(133, 126);
      this.pictureBox20.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox20.TabIndex = 5;
      this.pictureBox20.TabStop = false;
      this.pictureBox21.Image = (Image) componentResourceManager.GetObject("pictureBox21.Image");
      this.pictureBox21.Location = new Point(284, 128);
      this.pictureBox21.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox21.Name = "pictureBox21";
      this.pictureBox21.Size = new Size(133, 126);
      this.pictureBox21.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox21.TabIndex = 10;
      this.pictureBox21.TabStop = false;
      this.pictureBox22.Image = (Image) componentResourceManager.GetObject("pictureBox22.Image");
      this.pictureBox22.Location = new Point(143, 0);
      this.pictureBox22.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox22.Name = "pictureBox22";
      this.pictureBox22.Size = new Size(133, 126);
      this.pictureBox22.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox22.TabIndex = 4;
      this.pictureBox22.TabStop = false;
      this.pictureBox23.Image = (Image) componentResourceManager.GetObject("pictureBox23.Image");
      this.pictureBox23.Location = new Point(143, 128);
      this.pictureBox23.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox23.Name = "pictureBox23";
      this.pictureBox23.Size = new Size(133, 126);
      this.pictureBox23.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox23.TabIndex = 9;
      this.pictureBox23.TabStop = false;
      this.pictureBox24.Image = (Image) componentResourceManager.GetObject("pictureBox24.Image");
      this.pictureBox24.Location = new Point(1, 128);
      this.pictureBox24.Margin = new Padding(4, 4, 4, 4);
      this.pictureBox24.Name = "pictureBox24";
      this.pictureBox24.Size = new Size(133, 126);
      this.pictureBox24.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox24.TabIndex = 7;
      this.pictureBox24.TabStop = false;
      this.AutoScaleDimensions = new SizeF(8f, 16f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.BackColor = Color.FromArgb(36, 36, 36);
      this.ClientSize = new Size(575, 434);
      this.Controls.Add((Control) this.panel3);
      this.Controls.Add((Control) this.panel1);
      this.Controls.Add((Control) this.panel2);
      this.FormBorderStyle = FormBorderStyle.None;
      this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
      this.Margin = new Padding(4, 4, 4, 4);
      this.Name = nameof (Games);
      this.Text = nameof (Games);
      this.TopMost = true;
      this.Load += new EventHandler(this.Games_Load);
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      ((ISupportInitialize) this.pictureBox1).EndInit();
      ((ISupportInitialize) this.pictureBox2).EndInit();
      ((ISupportInitialize) this.pictureBox3).EndInit();
      ((ISupportInitialize) this.pictureBox4).EndInit();
      ((ISupportInitialize) this.pictureBox5).EndInit();
      ((ISupportInitialize) this.pictureBox6).EndInit();
      ((ISupportInitialize) this.pictureBox7).EndInit();
      ((ISupportInitialize) this.pictureBox8).EndInit();
      ((ISupportInitialize) this.pictureBox9).EndInit();
      ((ISupportInitialize) this.pictureBox10).EndInit();
      ((ISupportInitialize) this.pictureBox11).EndInit();
      ((ISupportInitialize) this.pictureBox12).EndInit();
      this.panel2.ResumeLayout(false);
      this.panel3.ResumeLayout(false);
      ((ISupportInitialize) this.pictureBox13).EndInit();
      ((ISupportInitialize) this.pictureBox14).EndInit();
      ((ISupportInitialize) this.pictureBox15).EndInit();
      ((ISupportInitialize) this.pictureBox16).EndInit();
      ((ISupportInitialize) this.pictureBox17).EndInit();
      ((ISupportInitialize) this.pictureBox18).EndInit();
      ((ISupportInitialize) this.pictureBox19).EndInit();
      ((ISupportInitialize) this.pictureBox20).EndInit();
      ((ISupportInitialize) this.pictureBox21).EndInit();
      ((ISupportInitialize) this.pictureBox22).EndInit();
      ((ISupportInitialize) this.pictureBox23).EndInit();
      ((ISupportInitialize) this.pictureBox24).EndInit();
      this.ResumeLayout(false);
    }
  }
}
