﻿// Decompiled with JetBrains decompiler
// Type: krnlss.settings
// Assembly: krnlss, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 1D51A737-46C7-4798-AAF1-4373D41D8FFF
// Assembly location: C:\Users\Win10\Desktop\krnl\krnlss.exe

using Bunifu.Framework.UI;
using injection;
using krnlss.Properties;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using ToggleSlider;

namespace krnlss
{
  public class settings : Form
  {
    private Form parent;
    private Thread autoinjectiont;
    private IContainer components;
    private Panel panel1;
    private BunifuCustomLabel bunifuCustomLabel1;
    private BunifuCustomLabel bunifuCustomLabel2;
    private ToggleSliderComponent toggleSliderComponent1;
    private ToggleSliderComponent toggleSliderComponent2;
    private Button button3;
    private Button button4;
    private ToggleSliderComponent toggleSliderComponent3;
    private BunifuCustomLabel bunifuCustomLabel3;
    private Label label1;
    private PictureBox pictureBox1;
    private BunifuCustomLabel bunifuCustomLabel4;
    private Button button1;
    private ToggleSliderComponent toggleSliderComponent4;
    private BunifuCustomLabel bunifuCustomLabel5;
    private ToggleSliderComponent toggleSliderComponent5;
    private BunifuCustomLabel bunifuCustomLabel6;
    private BunifuElipse bunifuElipse1;
    public static bool monaco_changed;

    [DllImport("user32.dll")]
    private static extern bool SetWindowPos(
      IntPtr hWnd,
      IntPtr hWndInsertAfter,
      int X,
      int Y,
      int cx,
      int cy,
      uint uFlags);

    public settings(Form parentt)
    {
      this.InitializeComponent();
      this.parent = parentt;
    }

    private void krnl_Load(object sender, EventArgs e)
    {
      if (Settings.Default.autoinject)
        this.toggleSliderComponent1.Checked = true;
      if (Settings.Default.topmostchecked)
        this.toggleSliderComponent2.Checked = true;
      if (Settings.Default.fadein_out_opacity)
        this.toggleSliderComponent3.Checked = true;
      if (Settings.Default.remove_crash_logs)
        this.toggleSliderComponent4.Checked = true;
      if (!Settings.Default.monaco)
        return;
      this.toggleSliderComponent5.Checked = true;
    }

    private void button1_Click(object sender, EventArgs e) => Application.Exit();

    private void button2_Click(object sender, EventArgs e)
    {
    }

    private void button3_Click(object sender, EventArgs e)
    {
    }

    private void OPACITYASSS_ValueChanged(object sender, EventArgs e)
    {
    }

    private void button1_Click_1(object sender, EventArgs e) => this.Close();

    private void label1_Click(object sender, EventArgs e)
    {
    }

    private void panel1_MouseDown_1(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Left)
        return;
      krnl.ReleaseCapture();
      krnl.SendMessage(this.Handle, 161, 2, 0);
    }

    private void toggleSliderComponent2_Load(object sender, EventArgs e)
    {
    }

    private void button4_Click(object sender, EventArgs e) => this.Close();

    private void button3_Click_1(object sender, EventArgs e) => this.WindowState = FormWindowState.Minimized;

    private void injectdll(object filename, int PID)
    {
      switch (krnlgay.DllInjector.GetInstance.Inject(Application.StartupPath + string.Format("\\\\{0}", filename), PID))
      {
        case krnlgay.krnlgayResult.DllNotFound:
          int num1 = (int) MessageBox.Show(string.Format("Dll Named {0} Not Found!", filename));
          break;
        case krnlgay.krnlgayResult.Failed:
          int num2 = (int) MessageBox.Show("Injection Failed For Unspecified Reason");
          break;
      }
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out int lpdwProcessId);

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern bool WaitNamedPipe(string name, int timeout);

    private static bool findpipe(string pipeName)
    {
      try
      {
        return !settings.WaitNamedPipe(Path.GetFullPath("\\\\.\\pipe\\" + pipeName), 0) || Marshal.GetLastWin32Error() != 0 && Marshal.GetLastWin32Error() != 2;
      }
      catch (Exception ex)
      {
        return false;
      }
    }

    private void autoinjectbruh()
    {
    }

    private void toggleSliderComponent1_Load(object sender, EventArgs e)
    {
    }

    private void toggleSliderComponent1_CheckChanged(object sender, EventArgs e)
    {
      if (this.toggleSliderComponent1.Checked)
      {
        this.autoinjectiont = new Thread(new ThreadStart(this.autoinjectbruh));
        this.autoinjectiont.IsBackground = true;
        this.autoinjectiont.Start();
        Settings.Default.autoinject = true;
        Settings.Default.Save();
      }
      else
      {
        if (this.autoinjectiont != null)
        {
          this.autoinjectiont.Abort();
          this.autoinjectiont = (Thread) null;
        }
        Settings.Default.autoinject = false;
        Settings.Default.Save();
      }
    }

    private void toggleSliderComponent2_CheckChanged(object sender, EventArgs e)
    {
      if (this.toggleSliderComponent2.Checked)
      {
        this.TopMost = true;
        this.parent.TopMost = true;
        Settings.Default.topmostchecked = true;
        Settings.Default.Save();
      }
      else
      {
        this.TopMost = false;
        this.parent.TopMost = false;
        Settings.Default.topmostchecked = false;
        Settings.Default.Save();
      }
    }

    private void settings_FormClosing(object sender, FormClosingEventArgs e)
    {
      if (!settings.monaco_changed)
        return;
      this.TopMost = true;
      if (MessageBox.Show("Automatically restart the UI to complete the changes?", "Krnl Prompt", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
        return;
      Process.Start(Process.GetCurrentProcess().MainModule.FileName);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (settings));
      this.panel1 = new Panel();
      this.pictureBox1 = new PictureBox();
      this.label1 = new Label();
      this.button3 = new Button();
      this.button4 = new Button();
      this.bunifuCustomLabel1 = new BunifuCustomLabel();
      this.bunifuCustomLabel2 = new BunifuCustomLabel();
      this.bunifuElipse1 = new BunifuElipse(this.components);
      this.bunifuCustomLabel3 = new BunifuCustomLabel();
      this.bunifuCustomLabel4 = new BunifuCustomLabel();
      this.button1 = new Button();
      this.bunifuCustomLabel5 = new BunifuCustomLabel();
      this.bunifuCustomLabel6 = new BunifuCustomLabel();
      this.toggleSliderComponent5 = new ToggleSliderComponent();
      this.toggleSliderComponent4 = new ToggleSliderComponent();
      this.toggleSliderComponent3 = new ToggleSliderComponent();
      this.toggleSliderComponent2 = new ToggleSliderComponent();
      this.toggleSliderComponent1 = new ToggleSliderComponent();
      this.panel1.SuspendLayout();
      ((ISupportInitialize) this.pictureBox1).BeginInit();
      this.SuspendLayout();
      this.panel1.BackColor = Color.FromArgb(29, 29, 29);
      this.panel1.BorderStyle = BorderStyle.FixedSingle;
      this.panel1.Controls.Add((Control) this.pictureBox1);
      this.panel1.Controls.Add((Control) this.label1);
      this.panel1.Controls.Add((Control) this.button3);
      this.panel1.Controls.Add((Control) this.button4);
      this.panel1.Location = new Point(-9, -3);
      this.panel1.Name = "panel1";
      this.panel1.Size = new Size(281, 37);
      this.panel1.TabIndex = 13;
      this.panel1.MouseDown += new MouseEventHandler(this.panel1_MouseDown_1);
      this.pictureBox1.Image = (Image) componentResourceManager.GetObject("pictureBox1.Image");
      this.pictureBox1.Location = new Point(7, 1);
      this.pictureBox1.Name = "pictureBox1";
      this.pictureBox1.Size = new Size(35, 36);
      this.pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox1.TabIndex = 24;
      this.pictureBox1.TabStop = false;
      this.label1.AutoSize = true;
      this.label1.Font = new Font("Segoe UI", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label1.ForeColor = Color.White;
      this.label1.Location = new Point(110, 11);
      this.label1.Name = "label1";
      this.label1.Size = new Size(54, 17);
      this.label1.TabIndex = 23;
      this.label1.Text = "Settings";
      this.button3.BackColor = Color.FromArgb(29, 29, 29);
      this.button3.BackgroundImageLayout = ImageLayout.Center;
      this.button3.FlatAppearance.BorderSize = 0;
      this.button3.FlatStyle = FlatStyle.Flat;
      this.button3.Font = new Font("Segoe UI", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.button3.ForeColor = Color.White;
      this.button3.Location = new Point(200, -1);
      this.button3.Margin = new Padding(4);
      this.button3.Name = "button3";
      this.button3.Size = new Size(25, 37);
      this.button3.TabIndex = 22;
      this.button3.Text = "—";
      this.button3.UseVisualStyleBackColor = false;
      this.button3.Click += new EventHandler(this.button3_Click_1);
      this.button4.BackColor = Color.FromArgb(29, 29, 29);
      this.button4.FlatAppearance.BorderSize = 0;
      this.button4.FlatStyle = FlatStyle.Flat;
      this.button4.Font = new Font("Segoe UI", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.button4.ForeColor = Color.White;
      this.button4.Location = new Point(228, -1);
      this.button4.Margin = new Padding(4);
      this.button4.Name = "button4";
      this.button4.Size = new Size(25, 37);
      this.button4.TabIndex = 21;
      this.button4.Text = "✕";
      this.button4.UseVisualStyleBackColor = false;
      this.button4.Click += new EventHandler(this.button4_Click);
      this.bunifuCustomLabel1.AutoSize = true;
      this.bunifuCustomLabel1.Font = new Font("Segoe UI", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.bunifuCustomLabel1.ForeColor = Color.White;
      this.bunifuCustomLabel1.Location = new Point(10, 81);
      this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
      this.bunifuCustomLabel1.Size = new Size(64, 17);
      this.bunifuCustomLabel1.TabIndex = 15;
      this.bunifuCustomLabel1.Text = "Top Most";
      this.bunifuCustomLabel2.AutoSize = true;
      this.bunifuCustomLabel2.Font = new Font("Segoe UI", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.bunifuCustomLabel2.ForeColor = Color.White;
      this.bunifuCustomLabel2.Location = new Point(10, 55);
      this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
      this.bunifuCustomLabel2.Size = new Size(75, 17);
      this.bunifuCustomLabel2.TabIndex = 17;
      this.bunifuCustomLabel2.Text = "Auto Attach";
      this.bunifuElipse1.ElipseRadius = 5;
      this.bunifuElipse1.TargetControl = (Control) this;
      this.bunifuCustomLabel3.AutoSize = true;
      this.bunifuCustomLabel3.Font = new Font("Segoe UI", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.bunifuCustomLabel3.ForeColor = Color.White;
      this.bunifuCustomLabel3.Location = new Point(12, 108);
      this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
      this.bunifuCustomLabel3.Size = new Size(123, 17);
      this.bunifuCustomLabel3.TabIndex = 15;
      this.bunifuCustomLabel3.Text = "Opacity Fade-in/out";
      this.bunifuCustomLabel4.AutoSize = true;
      this.bunifuCustomLabel4.Font = new Font("Segoe UI", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.bunifuCustomLabel4.ForeColor = Color.White;
      this.bunifuCustomLabel4.Location = new Point(12, 195);
      this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
      this.bunifuCustomLabel4.Size = new Size(116, 17);
      this.bunifuCustomLabel4.TabIndex = 21;
      this.bunifuCustomLabel4.Text = "Install missing files";
      this.button1.BackColor = Color.FromArgb(36, 36, 36);
      this.button1.FlatAppearance.BorderSize = 0;
      this.button1.FlatStyle = FlatStyle.Flat;
      this.button1.Font = new Font("Segoe UI", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.button1.ForeColor = Color.White;
      this.button1.Location = new Point(155, 195);
      this.button1.Name = "button1";
      this.button1.Size = new Size(62, 23);
      this.button1.TabIndex = 22;
      this.button1.Text = "INSTALL";
      this.button1.UseVisualStyleBackColor = false;
      this.button1.Click += new EventHandler(this.button1_Click_2);
      this.bunifuCustomLabel5.AutoSize = true;
      this.bunifuCustomLabel5.Font = new Font("Segoe UI", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.bunifuCustomLabel5.ForeColor = Color.White;
      this.bunifuCustomLabel5.Location = new Point(12, 134);
      this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
      this.bunifuCustomLabel5.Size = new Size(124, 17);
      this.bunifuCustomLabel5.TabIndex = 15;
      this.bunifuCustomLabel5.Text = "Remove Crash Logs";
      this.bunifuCustomLabel6.AutoSize = true;
      this.bunifuCustomLabel6.Enabled = false;
      this.bunifuCustomLabel6.Font = new Font("Segoe UI", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.bunifuCustomLabel6.ForeColor = Color.White;
      this.bunifuCustomLabel6.Location = new Point(12, 163);
      this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
      this.bunifuCustomLabel6.Size = new Size(100, 17);
      this.bunifuCustomLabel6.TabIndex = 15;
      this.bunifuCustomLabel6.Text = "Toggle Monaco";
      this.toggleSliderComponent5.AutoSize = true;
      this.toggleSliderComponent5.Checked = false;
      this.toggleSliderComponent5.Location = new Point(187, 163);
      this.toggleSliderComponent5.Margin = new Padding(4);
      this.toggleSliderComponent5.Name = "toggleSliderComponent5";
      this.toggleSliderComponent5.Size = new Size(54, 21);
      this.toggleSliderComponent5.TabIndex = 20;
      this.toggleSliderComponent5.ToggleBarText = "";
      this.toggleSliderComponent5.ToggleCircleColor = Color.FromArgb(91, 91, 91);
      this.toggleSliderComponent5.ToggleColorBar = Color.FromArgb(35, 35, 35);
      this.toggleSliderComponent5.CheckChanged += new EventHandler(this.toggleSliderComponent5_CheckChanged);
      this.toggleSliderComponent5.Load += new EventHandler(this.toggleSliderComponent5_Load);
      this.toggleSliderComponent4.AutoSize = true;
      this.toggleSliderComponent4.Checked = false;
      this.toggleSliderComponent4.Location = new Point(187, 134);
      this.toggleSliderComponent4.Margin = new Padding(4);
      this.toggleSliderComponent4.Name = "toggleSliderComponent4";
      this.toggleSliderComponent4.Size = new Size(54, 21);
      this.toggleSliderComponent4.TabIndex = 20;
      this.toggleSliderComponent4.ToggleBarText = "";
      this.toggleSliderComponent4.ToggleCircleColor = Color.FromArgb(91, 91, 91);
      this.toggleSliderComponent4.ToggleColorBar = Color.FromArgb(35, 35, 35);
      this.toggleSliderComponent4.CheckChanged += new EventHandler(this.toggleSliderComponent4_CheckChanged);
      this.toggleSliderComponent4.Load += new EventHandler(this.toggleSliderComponent4_Load);
      this.toggleSliderComponent3.AutoSize = true;
      this.toggleSliderComponent3.Checked = false;
      this.toggleSliderComponent3.Location = new Point(187, 108);
      this.toggleSliderComponent3.Margin = new Padding(4);
      this.toggleSliderComponent3.Name = "toggleSliderComponent3";
      this.toggleSliderComponent3.Size = new Size(54, 21);
      this.toggleSliderComponent3.TabIndex = 20;
      this.toggleSliderComponent3.ToggleBarText = "";
      this.toggleSliderComponent3.ToggleCircleColor = Color.FromArgb(91, 91, 91);
      this.toggleSliderComponent3.ToggleColorBar = Color.FromArgb(35, 35, 35);
      this.toggleSliderComponent3.CheckChanged += new EventHandler(this.toggleSliderComponent3_CheckChanged);
      this.toggleSliderComponent3.Load += new EventHandler(this.toggleSliderComponent3_Load);
      this.toggleSliderComponent2.AutoSize = true;
      this.toggleSliderComponent2.Checked = false;
      this.toggleSliderComponent2.Location = new Point(187, 81);
      this.toggleSliderComponent2.Margin = new Padding(4);
      this.toggleSliderComponent2.Name = "toggleSliderComponent2";
      this.toggleSliderComponent2.Size = new Size(54, 21);
      this.toggleSliderComponent2.TabIndex = 20;
      this.toggleSliderComponent2.ToggleBarText = "";
      this.toggleSliderComponent2.ToggleCircleColor = Color.FromArgb(91, 91, 91);
      this.toggleSliderComponent2.ToggleColorBar = Color.FromArgb(35, 35, 35);
      this.toggleSliderComponent2.CheckChanged += new EventHandler(this.toggleSliderComponent2_CheckChanged);
      this.toggleSliderComponent2.Load += new EventHandler(this.toggleSliderComponent2_Load);
      this.toggleSliderComponent1.AutoSize = true;
      this.toggleSliderComponent1.Checked = false;
      this.toggleSliderComponent1.Location = new Point(187, 55);
      this.toggleSliderComponent1.Margin = new Padding(4);
      this.toggleSliderComponent1.Name = "toggleSliderComponent1";
      this.toggleSliderComponent1.Size = new Size(54, 21);
      this.toggleSliderComponent1.TabIndex = 19;
      this.toggleSliderComponent1.ToggleBarText = "";
      this.toggleSliderComponent1.ToggleCircleColor = Color.FromArgb(91, 91, 91);
      this.toggleSliderComponent1.ToggleColorBar = Color.FromArgb(35, 35, 35);
      this.toggleSliderComponent1.CheckChanged += new EventHandler(this.toggleSliderComponent1_CheckChanged);
      this.toggleSliderComponent1.Load += new EventHandler(this.toggleSliderComponent1_Load);
      this.BackColor = Color.FromArgb(25, 25, 25);
      this.ClientSize = new Size(248, 230);
      this.Controls.Add((Control) this.button1);
      this.Controls.Add((Control) this.bunifuCustomLabel4);
      this.Controls.Add((Control) this.toggleSliderComponent5);
      this.Controls.Add((Control) this.toggleSliderComponent4);
      this.Controls.Add((Control) this.toggleSliderComponent3);
      this.Controls.Add((Control) this.toggleSliderComponent2);
      this.Controls.Add((Control) this.toggleSliderComponent1);
      this.Controls.Add((Control) this.bunifuCustomLabel2);
      this.Controls.Add((Control) this.bunifuCustomLabel6);
      this.Controls.Add((Control) this.bunifuCustomLabel5);
      this.Controls.Add((Control) this.bunifuCustomLabel3);
      this.Controls.Add((Control) this.bunifuCustomLabel1);
      this.Controls.Add((Control) this.panel1);
      this.FormBorderStyle = FormBorderStyle.None;
      this.Name = nameof (settings);
      this.FormClosing += new FormClosingEventHandler(this.settings_FormClosing);
      this.Load += new EventHandler(this.krnl_Load);
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      ((ISupportInitialize) this.pictureBox1).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }

    private void toggleSliderComponent3_Load(object sender, EventArgs e)
    {
    }

    private void toggleSliderComponent3_CheckChanged(object sender, EventArgs e)
    {
      Settings.Default.fadein_out_opacity = this.toggleSliderComponent3.Checked;
      if (Settings.Default.fadein_out_opacity)
      {
        for (; this.parent.Opacity > 0.5; this.parent.Opacity -= 0.05)
          Task.Delay(10).GetAwaiter().GetResult();
      }
      else
      {
        for (; this.parent.Opacity < 1.0; this.parent.Opacity += 0.05)
          Task.Delay(10).GetAwaiter().GetResult();
      }
      Settings.Default.Save();
    }

    private void button1_Click_2(object sender, EventArgs e)
    {
      new WebClient().DownloadFile(new Uri("http://cdn.krnl.rocks:8080/bootstrapper"), "krnl_bootstrapper_v3.exe");
      Process.Start("krnl_bootstrapper_v3.exe");
      Environment.Exit(1);
    }

    private void toggleSliderComponent4_CheckChanged(object sender, EventArgs e)
    {
      Settings.Default.remove_crash_logs = this.toggleSliderComponent4.Checked;
      Settings.Default.Save();
    }

    private void toggleSliderComponent4_Load(object sender, EventArgs e)
    {
    }

    private void toggleSliderComponent5_Load(object sender, EventArgs e)
    {
    }

    private void toggleSliderComponent5_CheckChanged(object sender, EventArgs e)
    {
      settings.monaco_changed = !settings.monaco_changed;
      Settings.Default.monaco = this.toggleSliderComponent5.Checked;
      Settings.Default.Save();
    }
  }
}
