﻿// Decompiled with JetBrains decompiler
// Type: ToggleSliderControl.ToggleSlider
// Assembly: krnlss, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 1D51A737-46C7-4798-AAF1-4373D41D8FFF
// Assembly location: C:\Users\Win10\Desktop\krnl\krnlss.exe

using System.Windows.Forms;

namespace ToggleSliderControl
{
  internal class ToggleSlider : Panel
  {
  }
}
