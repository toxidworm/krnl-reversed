﻿// Decompiled with JetBrains decompiler
// Type: Properties.Resources
// Assembly: krnlss, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 1D51A737-46C7-4798-AAF1-4373D41D8FFF
// Assembly location: C:\Users\Win10\Desktop\krnl\krnlss.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Properties
{
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
  [DebuggerNonUserCode]
  [CompilerGenerated]
  public class Resources
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    public static ResourceManager ResourceManager
    {
      get
      {
        if (Properties.Resources.resourceMan == null)
        {
          ResourceManager resourceManager = Properties.Resources.resourceMan = new ResourceManager("Properties.Resources", typeof (Properties.Resources).Assembly);
        }
        return Properties.Resources.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    public static CultureInfo Culture
    {
      get => Properties.Resources.resourceCulture;
      set => Properties.Resources.resourceCulture = value;
    }

    internal Resources()
    {
    }
  }
}
