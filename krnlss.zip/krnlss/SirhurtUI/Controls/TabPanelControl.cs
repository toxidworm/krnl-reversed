﻿// Decompiled with JetBrains decompiler
// Type: SirhurtUI.Controls.TabPanelControl
// Assembly: krnlss, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 1D51A737-46C7-4798-AAF1-4373D41D8FFF
// Assembly location: C:\Users\Win10\Desktop\krnl\krnlss.exe

using System;
using System.Windows.Forms;

namespace SirhurtUI.Controls
{
  public class TabPanelControl : UserControl
  {
    public TabPanelControl() => this.InitializeComponent();

    private void InitializeComponent()
    {
      this.SuspendLayout();
      this.Name = nameof (TabPanelControl);
      this.Load += new EventHandler(this.TabPanelControl_Load);
      this.ResumeLayout(false);
    }

    private void TabPanelControl_Load(object sender, EventArgs e)
    {
    }
  }
}
