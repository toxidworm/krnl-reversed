﻿// Decompiled with JetBrains decompiler
// Type: Controls.MonacoCustomTabControl
// Assembly: krnlss, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 1D51A737-46C7-4798-AAF1-4373D41D8FFF
// Assembly location: C:\Users\Win10\Desktop\krnl\krnlss.exe

using CefSharp;
using CefSharp.WinForms;
using krnlss;
using Microsoft.CSharp.RuntimeBinder;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Controls
{
  public class MonacoCustomTabControl : TabControl
  {
    public static krnl_monaco Form1;
    private ChromiumWebBrowser browser;
    public TabPage contextTab;
    public Color selectedTextColor = Color.FromArgb((int) byte.MaxValue, (int) byte.MaxValue, (int) byte.MaxValue);
    private readonly StringFormat CenterSringFormat = new StringFormat()
    {
      Alignment = StringAlignment.Near,
      LineAlignment = StringAlignment.Center
    };
    private Color activeColor = Color.FromArgb(36, 36, 36);
    private Color backTabColor = Color.FromArgb(0, 0, 0);
    private Color borderColor = Color.FromArgb(30, 30, 30);
    private Color closingButtonColor = Color.WhiteSmoke;
    private string closingMessage;
    private int count = 1;
    public int realIndex = -1;
    private Color headerColor = Color.FromArgb(45, 45, 48);
    private Color horizLineColor = Color.FromArgb(36, 36, 36);
    private TabPage predraggedTab;
    private Color textColor = Color.FromArgb((int) byte.MaxValue, (int) byte.MaxValue, (int) byte.MaxValue);
    public static bool removed = false;
    public static int removeIdx = -1;

    public MonacoCustomTabControl()
    {
      this.InitializeChromium();
      this.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
      this.DoubleBuffered = true;
      this.SizeMode = TabSizeMode.Normal;
      this.ItemSize = new Size(240, 16);
      this.AllowDrop = true;
      this.Selecting += new TabControlCancelEventHandler(this.TabChanging);
    }

    [Category("Colors")]
    [Browsable(true)]
    [Description("The color of the selected page")]
    public Color ActiveColor
    {
      get => this.activeColor;
      set => this.activeColor = value;
    }

    [Category("Colors")]
    [Browsable(true)]
    [Description("The color of the background of the tab")]
    public Color BackTabColor
    {
      get => this.backTabColor;
      set => this.backTabColor = value;
    }

    [Category("Colors")]
    [Browsable(true)]
    [Description("The color of the border of the control")]
    public Color BorderColor
    {
      get => this.borderColor;
      set => this.borderColor = value;
    }

    [Category("Colors")]
    [Browsable(true)]
    [Description("The color of the closing button")]
    public Color ClosingButtonColor
    {
      get => this.closingButtonColor;
      set => this.closingButtonColor = value;
    }

    [Category("Options")]
    [Browsable(true)]
    [Description("The message that will be shown before closing.")]
    public string ClosingMessage
    {
      get => this.closingMessage;
      set => this.closingMessage = value;
    }

    [Category("Colors")]
    [Browsable(true)]
    [Description("The color of the header.")]
    public Color HeaderColor
    {
      get => this.headerColor;
      set => this.headerColor = value;
    }

    [Category("Colors")]
    [Browsable(true)]
    [Description("The color of the horizontal line which is located under the headers of the pages.")]
    public Color HorizontalLineColor
    {
      get => this.horizLineColor;
      set => this.horizLineColor = value;
    }

    [Category("Colors")]
    [Browsable(true)]
    [Description("The color of the title of the page")]
    public Color SelectedTextColor
    {
      get => this.selectedTextColor;
      set => this.selectedTextColor = value;
    }

    public bool ShowClosingButton { get; set; }

    [Category("Options")]
    [Browsable(true)]
    [Description("Show a Yes/No message before closing?")]
    public bool ShowClosingMessage { get; set; }

    [Category("Colors")]
    [Browsable(true)]
    [Description("The color of the title of the page")]
    public Color TextColor
    {
      get => this.textColor;
      set => this.textColor = value;
    }

    public void AddEvent(string name = "Script.lua", string content = "") => this.addnewtab();

    public void AddIntellisense(
      ChromiumWebBrowser chrome,
      string p1,
      string p2,
      string p3,
      string p4)
    {
      this.Invoke((Delegate) (() =>
      {
        try
        {
          WebBrowserExtensions.ExecuteScriptAsyncWhenPageLoaded((IWebBrowser) chrome, "AddIntellisense('" + p1 + "', '" + p2 + "', '" + p3 + "', '" + p4 + "')", true);
        }
        catch
        {
        }
      }));
    }

    public void addnewtab()
    {
      int index = this.TabCount - 1;
      this.TabPages.Insert(index, string.Format("Script{0}.lua", (object) this.TabCount));
      this.SelectTab(this.TabPages[index]);
      ((Control) this.browser).Parent = (Control) this.TabPages[index];
      this.SelectedIndex = index;
    }

    public void CloseTab(TabPage tab)
    {
      WebBrowser control = tab.Controls[0] as WebBrowser;
      int index = this.TabPages.IndexOf(tab);
      if (index == 0 && this.TabCount <= 2)
        return;
      this.TabPages.RemoveAt(index);
      --this.count;
    }

    public ChromiumWebBrowser GetWorkingTextEditor()
    {
      TabPage selectedTab = this.SelectedTab;
      return this.browser;
    }

    public void InitializeChromium()
    {
      if (!Cef.IsInitialized)
      {
        CefSettings cefSettings = new CefSettings();
        ((CefSettingsBase) cefSettings).BrowserSubprocessPath = Path.Combine(Environment.CurrentDirectory, "bin", "src", "CefSharp.BrowserSubprocess.exe");
        ((CefSettingsBase) cefSettings).LocalesDirPath = Path.Combine(Environment.CurrentDirectory, "bin", "src", "locales");
        ((CefSettingsBase) cefSettings).ResourcesDirPath = Path.Combine(Environment.CurrentDirectory, "bin", "src");
        Cef.Initialize((CefSettingsBase) cefSettings);
      }
      this.browser = new ChromiumWebBrowser(Environment.CurrentDirectory.Replace("\\", "/") + "/bin/Monaco/Monaco.html", (IRequestContext) null);
      ((Control) this.browser).Dock = DockStyle.Fill;
      ((Control) this.browser).BringToFront();
      this.browser.LoadingStateChanged += (EventHandler<LoadingStateChangedEventArgs>) ((o, e) =>
      {
        if (e.IsLoading)
          return;
        this.Invoke((Delegate) (() =>
        {
          ((Control) this.browser).Visible = true;
          Intellisense.addIntellisense(this.browser);
        }));
      });
      this.browser.BrowserSettings.WindowlessFrameRate = 30;
    }

    public void addScript(string content) => Program.tabScripts.Add(content);

    public bool OpenFileDialog(TabPage tab)
    {
      using (System.Windows.Forms.OpenFileDialog openFileDialog = new System.Windows.Forms.OpenFileDialog())
      {
        openFileDialog.Filter = "Lua Files (*.lua)|*.lua|Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
        openFileDialog.RestoreDirectory = true;
        if (openFileDialog.ShowDialog() != DialogResult.OK)
          return false;
        WebBrowserExtensions.ExecuteScriptAsync((IWebBrowser) this.GetWorkingTextEditor(), "SetText", new object[1]
        {
          (object) File.ReadAllText(openFileDialog.FileName)
        });
        tab.Text = Path.GetFileName(openFileDialog.FileName);
        return true;
      }
    }

    public string OpenSaveDialog(TabPage tab, string text)
    {
      using (SaveFileDialog saveFileDialog = new SaveFileDialog())
      {
        saveFileDialog.Filter = "Lua Files (*.lua)|*.lua|Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
        saveFileDialog.RestoreDirectory = true;
        saveFileDialog.FileName = tab.Text;
        if (saveFileDialog.ShowDialog() != DialogResult.OK)
          return tab.Text;
        File.WriteAllText(saveFileDialog.FileName, WebBrowserExtensions.EvaluateScriptAsync((IWebBrowser) this.GetWorkingTextEditor(), "GetText", new object[0]).GetAwaiter().GetResult().Result.ToString());
        return new FileInfo(saveFileDialog.FileName).Name;
      }
    }

    public void TabChanging(object sender, TabControlCancelEventArgs e)
    {
      if (this.browser != null && !this.browser.IsLoading && this.browser.IsBrowserInitialized && this.realIndex >= 0)
      {
        if (MonacoCustomTabControl.removed)
          Program.tabScripts.RemoveAt(MonacoCustomTabControl.removeIdx);
        if (MonacoCustomTabControl.removeIdx != this.realIndex)
        {
          Console.WriteLine(this.realIndex.ToString() + " | " + Program.tabScripts[this.realIndex]);
          string str = WebBrowserExtensions.EvaluateScriptAsync((IWebBrowser) this.browser, "GetText", new object[0]).GetAwaiter().GetResult().Result.ToString();
          Program.tabScripts[this.realIndex] = str != "-- Krnl Monaco" ? str : Program.tabScripts[this.realIndex];
        }
        MonacoCustomTabControl.removed = false;
        MonacoCustomTabControl.removeIdx = -1;
      }
      if (Program.tabScripts.Count < e.TabPageIndex + 1)
        Program.tabScripts.Add("-- Krnl Monaco");
      if (e.TabPageIndex == this.TabCount - 1)
      {
        e.Cancel = true;
      }
      else
      {
        if (e.Action != TabControlAction.Selecting)
          return;
        if (!this.browser.IsLoading && this.browser.IsBrowserInitialized)
        {
          WebBrowserExtensions.ExecuteScriptAsync((IWebBrowser) this.browser, "SetText", new object[1]
          {
            (object) Program.tabScripts[e.TabPageIndex]
          });
          ((Control) this.browser).Parent = (Control) this.GetPointedTab();
        }
        this.realIndex = e.TabPageIndex;
        WebBrowserExtensions.ExecuteScriptAsyncWhenPageLoaded((IWebBrowser) this.browser, "SetText(`" + Program.tabScripts[this.realIndex].Replace("`", "\\`") + "`)", true);
      }
    }

    protected override void CreateHandle()
    {
      base.CreateHandle();
      this.Alignment = TabAlignment.Top;
      MonacoCustomTabControl.SendMessage(this.Handle, 4913, IntPtr.Zero, (IntPtr) 16);
    }

    public static void Swap<T>(IList<T> list, int indexA, int indexB)
    {
      T obj = list[indexA];
      list[indexA] = list[indexB];
      list[indexB] = obj;
    }

    protected override void OnDragOver(DragEventArgs drgevent) => base.OnDragOver(drgevent);

    protected override void OnMouseDown(MouseEventArgs e)
    {
      this.predraggedTab = this.GetPointedTab();
      Point location = e.Location;
      for (int index = 0; index < this.TabCount; ++index)
      {
        object tabRect = (object) this.GetTabRect(index);
        // ISSUE: reference to a compiler-generated field
        if (MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__2 == null)
        {
          // ISSUE: reference to a compiler-generated field
          MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__2 = CallSite<Action<CallSite, object, object, int>>.Create(Binder.InvokeMember(CSharpBinderFlags.ResultDiscarded, "Offset", (IEnumerable<System.Type>) null, typeof (MonacoCustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[3]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        Action<CallSite, object, object, int> target1 = MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__2.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Action<CallSite, object, object, int>> p2 = MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__2;
        object obj1 = tabRect;
        // ISSUE: reference to a compiler-generated field
        if (MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__1 == null)
        {
          // ISSUE: reference to a compiler-generated field
          MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Subtract, typeof (MonacoCustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        Func<CallSite, object, int, object> target2 = MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__1.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Func<CallSite, object, int, object>> p1 = MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__1;
        // ISSUE: reference to a compiler-generated field
        if (MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__0 == null)
        {
          // ISSUE: reference to a compiler-generated field
          MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "Width", typeof (MonacoCustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj2 = MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__0.Target((CallSite) MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__0, tabRect);
        object obj3 = target2((CallSite) p1, obj2, 15);
        target1((CallSite) p2, obj1, obj3, 2);
        // ISSUE: reference to a compiler-generated field
        if (MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__3 == null)
        {
          // ISSUE: reference to a compiler-generated field
          MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__3 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.SetMember(CSharpBinderFlags.None, "Width", typeof (MonacoCustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj4 = MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__3.Target((CallSite) MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__3, tabRect, 10);
        // ISSUE: reference to a compiler-generated field
        if (MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__4 == null)
        {
          // ISSUE: reference to a compiler-generated field
          MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__4 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.SetMember(CSharpBinderFlags.None, "Height", typeof (MonacoCustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj5 = MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__4.Target((CallSite) MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__4, tabRect, 10);
        // ISSUE: reference to a compiler-generated field
        if (MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__6 == null)
        {
          // ISSUE: reference to a compiler-generated field
          MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__6 = CallSite<Func<CallSite, object, object>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.Not, typeof (MonacoCustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        Func<CallSite, object, object> target3 = MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__6.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Func<CallSite, object, object>> p6 = MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__6;
        // ISSUE: reference to a compiler-generated field
        if (MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__5 == null)
        {
          // ISSUE: reference to a compiler-generated field
          MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__5 = CallSite<Func<CallSite, object, Point, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.None, "Contains", (IEnumerable<System.Type>) null, typeof (MonacoCustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj6 = MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__5.Target((CallSite) MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__5, tabRect, location);
        object obj7 = target3((CallSite) p6, obj6);
        // ISSUE: reference to a compiler-generated field
        if (MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__9 == null)
        {
          // ISSUE: reference to a compiler-generated field
          MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__9 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (MonacoCustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (!MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__9.Target((CallSite) MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__9, obj7))
        {
          // ISSUE: reference to a compiler-generated field
          if (MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__8 == null)
          {
            // ISSUE: reference to a compiler-generated field
            MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__8 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (MonacoCustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          Func<CallSite, object, bool> target4 = MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__8.Target;
          // ISSUE: reference to a compiler-generated field
          CallSite<Func<CallSite, object, bool>> p8 = MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__8;
          // ISSUE: reference to a compiler-generated field
          if (MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__7 == null)
          {
            // ISSUE: reference to a compiler-generated field
            MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__7 = CallSite<Func<CallSite, object, bool, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.BinaryOperationLogical, ExpressionType.Or, typeof (MonacoCustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          object obj8 = MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__7.Target((CallSite) MonacoCustomTabControl.\u003C\u003Eo__67.\u003C\u003Ep__7, obj7, e.Button != MouseButtons.Left);
          if (!target4((CallSite) p8, obj8))
          {
            if (index != this.TabCount - 1)
            {
              this.predraggedTab = (TabPage) null;
              TabPage tabPage = this.TabPages[index];
              if ((this.ShowClosingMessage ? 1 : 0) != 0)
              {
                int num = (int) MessageBox.Show("Changing tab?");
              }
              else
              {
                if (this.TabCount == 2)
                {
                  if (MessageBox.Show("Are you sure you want to clear this tab?\nThe reason why you see this prompt is because there is only one tab currently opened.", "SINGLE TAB DETECTED", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
                    return;
                  Program.tabScripts[0] = "";
                  tabPage.Text = "Untitled.lua";
                  WebBrowserExtensions.ExecuteScriptAsync((IWebBrowser) this.GetWorkingTextEditor(), "SetText", (object[]) new string[1]
                  {
                    ""
                  });
                  return;
                }
                if (tabPage.Controls.Count > 0)
                {
                  MonacoCustomTabControl.removeIdx = index;
                  MonacoCustomTabControl.removed = true;
                  this.SelectTab(this.TabPages[index - 1]);
                  ((Control) this.browser).Parent = (Control) this.TabPages[index - 1];
                  this.TabPages[index].Dispose();
                  break;
                }
                break;
              }
            }
            else if (this.GetTabRect(this.TabCount - 1).Contains(e.Location))
            {
              this.AddEvent();
              this.predraggedTab = (TabPage) null;
              break;
            }
          }
        }
      }
      base.OnMouseDown(e);
    }

    protected override void OnMouseMove(MouseEventArgs e) => base.OnMouseMove(e);

    protected override void OnMouseUp(MouseEventArgs e)
    {
      this.predraggedTab = (TabPage) null;
      this.contextTab = (TabPage) null;
      if (e.Button == MouseButtons.Right)
      {
        MonacoCustomTabControl.Form1.TabContextMenu.Show(Cursor.Position);
        this.contextTab = this.GetPointedTab();
      }
      base.OnMouseUp(e);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
      Graphics graphics = e.Graphics;
      graphics.SmoothingMode = SmoothingMode.HighQuality;
      graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
      graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
      graphics.Clear(this.headerColor);
      try
      {
        this.SelectedTab.BackColor = this.backTabColor;
      }
      catch
      {
      }
      try
      {
        this.SelectedTab.BorderStyle = BorderStyle.None;
      }
      catch
      {
      }
      for (int index = 0; index <= this.TabCount - 1; ++index)
      {
        TabPage tabPage1 = this.TabPages[index];
        TabPage tabPage2 = tabPage1;
        SizeF sizeF = e.Graphics.MeasureString(tabPage1.Text, this.Font);
        int num1;
        int num2 = num1 = (int) sizeF.Width + 16;
        tabPage2.Width = num1;
        Rectangle rectangle;
        ref Rectangle local = ref rectangle;
        Rectangle tabRect = this.GetTabRect(index);
        Point location1 = tabRect.Location;
        int x = location1.X + 2;
        tabRect = this.GetTabRect(index);
        location1 = tabRect.Location;
        int y = location1.Y;
        Point location2 = new Point(x, y);
        tabRect = this.GetTabRect(index);
        int width = tabRect.Width;
        tabRect = this.GetTabRect(index);
        int height = tabRect.Height;
        Size size = new Size(width, height);
        local = new Rectangle(location2, size);
        Rectangle rect = new Rectangle(rectangle.Location, new Size(rectangle.Width, rectangle.Height));
        Brush brush = (Brush) new SolidBrush(this.closingButtonColor);
        if (index != this.SelectedIndex)
        {
          graphics.DrawString(tabPage1.Text, this.Font, (Brush) new SolidBrush(this.textColor), (RectangleF) rect, this.CenterSringFormat);
        }
        else
        {
          graphics.FillRectangle((Brush) new SolidBrush(this.headerColor), rect);
          graphics.FillRectangle((Brush) new SolidBrush(Color.FromArgb(36, 36, 36)), new Rectangle(rectangle.X - 5, rectangle.Y - 3, rectangle.Width, rectangle.Height + 5));
          graphics.DrawString(tabPage1.Text, this.Font, (Brush) new SolidBrush(this.selectedTextColor), (RectangleF) rect, this.CenterSringFormat);
        }
        if (index != this.TabCount - 1)
        {
          if (this.ShowClosingButton)
            e.Graphics.DrawString("X", this.Font, brush, (float) (rect.Right - 17), 3f);
        }
        else
        {
          using (Font font = new Font(SystemFonts.DefaultFont.FontFamily, 14f, FontStyle.Bold))
            e.Graphics.DrawString("+", font, brush, (float) (rect.Right - 22), (float) (rect.Top / 2 - 4));
        }
        brush.Dispose();
      }
      graphics.DrawLine(new Pen(Color.FromArgb(36, 36, 36), 5f), new Point(0, 19), new Point(this.Width, 19));
      graphics.FillRectangle((Brush) new SolidBrush(this.backTabColor), new Rectangle(0, 20, this.Width, this.Height - 20));
      graphics.DrawRectangle(new Pen(this.borderColor, 2f), new Rectangle(0, 0, this.Width, this.Height));
      graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
    }

    [DllImport("user32.dll")]
    private static extern IntPtr SendMessage(
      IntPtr hWnd,
      int Msg,
      IntPtr wParam,
      IntPtr lParam);

    private void DragDropHandler(object sender, DragEventArgs e)
    {
      foreach (string path in (string[]) e.Data.GetData(DataFormats.FileDrop, false))
        this.AddEvent(Path.GetFileNameWithoutExtension(path), File.ReadAllText(path));
    }

    private void DragOverEnterHandler(object sender, DragEventArgs e)
    {
      if (e.Data.GetDataPresent(DataFormats.FileDrop))
        e.Effect = DragDropEffects.Copy;
      else
        e.Effect = DragDropEffects.None;
    }

    private TabPage GetPointedTab()
    {
      for (int index = 0; index <= this.TabPages.Count - 1; ++index)
      {
        if (this.GetTabRect(index).Contains(this.PointToClient(Cursor.Position)))
          return this.TabPages[index];
      }
      return (TabPage) null;
    }

    private void ReplaceTabPages(TabPage Source, TabPage Destination)
    {
      object obj1 = (object) this.TabPages.IndexOf(Source);
      object obj2 = (object) this.TabPages.IndexOf(Destination);
      // ISSUE: reference to a compiler-generated field
      if (MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (MonacoCustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj3 = MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__0.Target((CallSite) MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__0, obj1, -1);
      // ISSUE: reference to a compiler-generated field
      if (MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__1 == null)
      {
        // ISSUE: reference to a compiler-generated field
        MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (MonacoCustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if ((MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__1.Target((CallSite) MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__1, obj3) ? 1 : 0) != 0)
        return;
      // ISSUE: reference to a compiler-generated field
      if (MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__4 == null)
      {
        // ISSUE: reference to a compiler-generated field
        MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__4 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (MonacoCustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target1 = MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__4.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p4 = MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__4;
      // ISSUE: reference to a compiler-generated field
      if (MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__3 == null)
      {
        // ISSUE: reference to a compiler-generated field
        MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__3 = CallSite<Func<CallSite, object, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Or, typeof (MonacoCustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, object, object> target2 = MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__3.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, object, object>> p3 = MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__3;
      object obj4 = obj3;
      // ISSUE: reference to a compiler-generated field
      if (MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__2 == null)
      {
        // ISSUE: reference to a compiler-generated field
        MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__2 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (MonacoCustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj5 = MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__2.Target((CallSite) MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__2, obj2, -1);
      object obj6 = target2((CallSite) p3, obj4, obj5);
      if ((target1((CallSite) p4, obj6) ? 1 : 0) != 0)
        return;
      // ISSUE: reference to a compiler-generated field
      if (MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__5 == null)
      {
        // ISSUE: reference to a compiler-generated field
        MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__5 = CallSite<Func<CallSite, TabControl.TabPageCollection, object, TabPage, object>>.Create(Binder.SetIndex(CSharpBinderFlags.None, typeof (MonacoCustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[3]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj7 = MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__5.Target((CallSite) MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__5, this.TabPages, obj2, Source);
      // ISSUE: reference to a compiler-generated field
      if (MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__6 == null)
      {
        // ISSUE: reference to a compiler-generated field
        MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__6 = CallSite<Func<CallSite, TabControl.TabPageCollection, object, TabPage, object>>.Create(Binder.SetIndex(CSharpBinderFlags.None, typeof (MonacoCustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[3]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj8 = MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__6.Target((CallSite) MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__6, this.TabPages, obj1, Destination);
      // ISSUE: reference to a compiler-generated field
      if (MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__8 == null)
      {
        // ISSUE: reference to a compiler-generated field
        MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__8 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (MonacoCustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target3 = MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__8.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p8 = MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__8;
      // ISSUE: reference to a compiler-generated field
      if (MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__7 == null)
      {
        // ISSUE: reference to a compiler-generated field
        MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__7 = CallSite<Func<CallSite, int, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (MonacoCustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj9 = MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__7.Target((CallSite) MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__7, this.SelectedIndex, obj1);
      if (target3((CallSite) p8, obj9))
      {
        // ISSUE: reference to a compiler-generated field
        if (MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__9 == null)
        {
          // ISSUE: reference to a compiler-generated field
          MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__9 = CallSite<Func<CallSite, object, int>>.Create(Binder.Convert(CSharpBinderFlags.None, typeof (int), typeof (MonacoCustomTabControl)));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        this.SelectedIndex = MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__9.Target((CallSite) MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__9, obj2);
      }
      else
      {
        // ISSUE: reference to a compiler-generated field
        if (MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__11 == null)
        {
          // ISSUE: reference to a compiler-generated field
          MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__11 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (MonacoCustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        Func<CallSite, object, bool> target4 = MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__11.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Func<CallSite, object, bool>> p11 = MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__11;
        // ISSUE: reference to a compiler-generated field
        if (MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__10 == null)
        {
          // ISSUE: reference to a compiler-generated field
          MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__10 = CallSite<Func<CallSite, int, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (MonacoCustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj10 = MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__10.Target((CallSite) MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__10, this.SelectedIndex, obj2);
        if (target4((CallSite) p11, obj10))
        {
          // ISSUE: reference to a compiler-generated field
          if (MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__12 == null)
          {
            // ISSUE: reference to a compiler-generated field
            MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__12 = CallSite<Func<CallSite, object, int>>.Create(Binder.Convert(CSharpBinderFlags.None, typeof (int), typeof (MonacoCustomTabControl)));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          this.SelectedIndex = MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__12.Target((CallSite) MonacoCustomTabControl.\u003C\u003Eo__75.\u003C\u003Ep__12, obj1);
        }
      }
      this.Refresh();
    }
  }
}
