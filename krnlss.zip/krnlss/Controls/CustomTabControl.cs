﻿// Decompiled with JetBrains decompiler
// Type: Controls.CustomTabControl
// Assembly: krnlss, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 1D51A737-46C7-4798-AAF1-4373D41D8FFF
// Assembly location: C:\Users\Win10\Desktop\krnl\krnlss.exe

using krnlss;
using Microsoft.CSharp.RuntimeBinder;
using ScintillaNET;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Controls
{
  public class CustomTabControl : TabControl
  {
    private readonly StringFormat CenterSringFormat = new StringFormat()
    {
      Alignment = StringAlignment.Near,
      LineAlignment = StringAlignment.Center
    };
    private Color activeColor = Color.FromArgb(36, 36, 36);
    private Color backTabColor = Color.FromArgb(0, 0, 0);
    private Color borderColor = Color.FromArgb(30, 30, 30);
    private Color closingButtonColor = Color.WhiteSmoke;
    private string closingMessage;
    private Color headerColor = Color.FromArgb(45, 45, 48);
    private Color horizLineColor = Color.FromArgb(36, 36, 36);
    private TabPage predraggedTab;
    public TabPage contextTab;
    private Color textColor = Color.FromArgb((int) byte.MaxValue, (int) byte.MaxValue, (int) byte.MaxValue);
    public Color selectedTextColor = Color.FromArgb((int) byte.MaxValue, (int) byte.MaxValue, (int) byte.MaxValue);
    public static krnl Form1;
    private int count = 1;

    public bool ShowClosingButton { get; set; }

    [Category("Colors")]
    [Browsable(true)]
    [Description("The color of the selected page")]
    public Color ActiveColor
    {
      get => this.activeColor;
      set => this.activeColor = value;
    }

    [Category("Colors")]
    [Browsable(true)]
    [Description("The color of the background of the tab")]
    public Color BackTabColor
    {
      get => this.backTabColor;
      set => this.backTabColor = value;
    }

    [Category("Colors")]
    [Browsable(true)]
    [Description("The color of the border of the control")]
    public Color BorderColor
    {
      get => this.borderColor;
      set => this.borderColor = value;
    }

    [Category("Colors")]
    [Browsable(true)]
    [Description("The color of the closing button")]
    public Color ClosingButtonColor
    {
      get => this.closingButtonColor;
      set => this.closingButtonColor = value;
    }

    [Category("Options")]
    [Browsable(true)]
    [Description("The message that will be shown before closing.")]
    public string ClosingMessage
    {
      get => this.closingMessage;
      set => this.closingMessage = value;
    }

    [Category("Colors")]
    [Browsable(true)]
    [Description("The color of the header.")]
    public Color HeaderColor
    {
      get => this.headerColor;
      set => this.headerColor = value;
    }

    [Category("Colors")]
    [Browsable(true)]
    [Description("The color of the horizontal line which is located under the headers of the pages.")]
    public Color HorizontalLineColor
    {
      get => this.horizLineColor;
      set => this.horizLineColor = value;
    }

    [Category("Options")]
    [Browsable(true)]
    [Description("Show a Yes/No message before closing?")]
    public bool ShowClosingMessage { get; set; }

    [Category("Colors")]
    [Browsable(true)]
    [Description("The color of the title of the page")]
    public Color SelectedTextColor
    {
      get => this.selectedTextColor;
      set => this.selectedTextColor = value;
    }

    [Category("Colors")]
    [Browsable(true)]
    [Description("The color of the title of the page")]
    public Color TextColor
    {
      get => this.textColor;
      set => this.textColor = value;
    }

    [DllImport("user32.dll")]
    private static extern IntPtr SendMessage(
      IntPtr hWnd,
      int Msg,
      IntPtr wParam,
      IntPtr lParam);

    public CustomTabControl()
    {
      this.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
      this.DoubleBuffered = true;
      this.SizeMode = TabSizeMode.Normal;
      this.ItemSize = new Size(240, 16);
      this.AllowDrop = true;
      this.Selecting += new TabControlCancelEventHandler(this.TabChanging);
    }

    protected override void CreateHandle()
    {
      base.CreateHandle();
      this.Alignment = TabAlignment.Top;
      CustomTabControl.SendMessage(this.Handle, 4913, IntPtr.Zero, (IntPtr) 16);
    }

    protected override void OnDragOver(DragEventArgs drgevent)
    {
      if (this.predraggedTab != null)
      {
        TabPage data = (TabPage) drgevent.Data.GetData(typeof (TabPage));
        TabPage pointedTab = this.GetPointedTab();
        int num = this.TabPages.IndexOf(data);
        if (data != null && num != this.TabCount)
        {
          TabPage tabPage = this.TabPages[this.TabCount - 1];
          if (data != tabPage && data == this.predraggedTab && pointedTab != null)
          {
            drgevent.Effect = DragDropEffects.Move;
            if (pointedTab != tabPage && pointedTab != data)
              this.ReplaceTabPages(data, pointedTab);
          }
        }
      }
      base.OnDragOver(drgevent);
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
      this.predraggedTab = this.GetPointedTab();
      Point location = e.Location;
      for (int index = 0; index < this.TabCount; ++index)
      {
        object tabRect = (object) this.GetTabRect(index);
        // ISSUE: reference to a compiler-generated field
        if (CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__2 == null)
        {
          // ISSUE: reference to a compiler-generated field
          CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__2 = CallSite<Action<CallSite, object, object, int>>.Create(Binder.InvokeMember(CSharpBinderFlags.ResultDiscarded, "Offset", (IEnumerable<System.Type>) null, typeof (CustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[3]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        Action<CallSite, object, object, int> target1 = CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__2.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Action<CallSite, object, object, int>> p2 = CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__2;
        object obj1 = tabRect;
        // ISSUE: reference to a compiler-generated field
        if (CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__1 == null)
        {
          // ISSUE: reference to a compiler-generated field
          CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Subtract, typeof (CustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        Func<CallSite, object, int, object> target2 = CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__1.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Func<CallSite, object, int, object>> p1 = CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__1;
        // ISSUE: reference to a compiler-generated field
        if (CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__0 == null)
        {
          // ISSUE: reference to a compiler-generated field
          CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "Width", typeof (CustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj2 = CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__0.Target((CallSite) CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__0, tabRect);
        object obj3 = target2((CallSite) p1, obj2, 15);
        target1((CallSite) p2, obj1, obj3, 2);
        // ISSUE: reference to a compiler-generated field
        if (CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__3 == null)
        {
          // ISSUE: reference to a compiler-generated field
          CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__3 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.SetMember(CSharpBinderFlags.None, "Width", typeof (CustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj4 = CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__3.Target((CallSite) CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__3, tabRect, 10);
        // ISSUE: reference to a compiler-generated field
        if (CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__4 == null)
        {
          // ISSUE: reference to a compiler-generated field
          CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__4 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.SetMember(CSharpBinderFlags.None, "Height", typeof (CustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj5 = CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__4.Target((CallSite) CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__4, tabRect, 10);
        // ISSUE: reference to a compiler-generated field
        if (CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__6 == null)
        {
          // ISSUE: reference to a compiler-generated field
          CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__6 = CallSite<Func<CallSite, object, object>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.Not, typeof (CustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        Func<CallSite, object, object> target3 = CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__6.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Func<CallSite, object, object>> p6 = CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__6;
        // ISSUE: reference to a compiler-generated field
        if (CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__5 == null)
        {
          // ISSUE: reference to a compiler-generated field
          CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__5 = CallSite<Func<CallSite, object, Point, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.None, "Contains", (IEnumerable<System.Type>) null, typeof (CustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj6 = CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__5.Target((CallSite) CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__5, tabRect, location);
        object obj7 = target3((CallSite) p6, obj6);
        // ISSUE: reference to a compiler-generated field
        if (CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__9 == null)
        {
          // ISSUE: reference to a compiler-generated field
          CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__9 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (CustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (!CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__9.Target((CallSite) CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__9, obj7))
        {
          // ISSUE: reference to a compiler-generated field
          if (CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__8 == null)
          {
            // ISSUE: reference to a compiler-generated field
            CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__8 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (CustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          Func<CallSite, object, bool> target4 = CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__8.Target;
          // ISSUE: reference to a compiler-generated field
          CallSite<Func<CallSite, object, bool>> p8 = CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__8;
          // ISSUE: reference to a compiler-generated field
          if (CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__7 == null)
          {
            // ISSUE: reference to a compiler-generated field
            CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__7 = CallSite<Func<CallSite, object, bool, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.BinaryOperationLogical, ExpressionType.Or, typeof (CustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
            {
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
              CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
            }));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          object obj8 = CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__7.Target((CallSite) CustomTabControl.\u003C\u003Eo__53.\u003C\u003Ep__7, obj7, e.Button != MouseButtons.Left);
          if (!target4((CallSite) p8, obj8))
          {
            if (index != this.TabCount - 1)
            {
              this.predraggedTab = (TabPage) null;
              TabPage tabPage = this.TabPages[index];
              if (!this.ShowClosingMessage)
              {
                if (this.TabCount == 2)
                {
                  if (MessageBox.Show("Are you sure you want to clear this tab?\nThe reason why you see this prompt is because there is only one tab currently opened.", "SINGLE TAB DETECTED", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
                    return;
                  tabPage.Text = "Untitled.lua";
                  this.GetWorkingTextEditor().Text = "";
                  return;
                }
                if (tabPage.Controls.Count > 0)
                  tabPage.Controls[0].Dispose();
                this.TabPages.RemoveAt(index);
                break;
              }
              this.CloseTab(tabPage);
            }
            else if (this.GetTabRect(this.TabCount - 1).Contains(e.Location))
            {
              this.AddEvent();
              this.predraggedTab = (TabPage) null;
              break;
            }
          }
        }
      }
      base.OnMouseDown(e);
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
      if (e.Button == MouseButtons.Left && this.predraggedTab != null)
      {
        int num = (int) this.DoDragDrop((object) this.predraggedTab, DragDropEffects.Move);
      }
      base.OnMouseMove(e);
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
      this.predraggedTab = (TabPage) null;
      this.contextTab = (TabPage) null;
      if (e.Button == MouseButtons.Right)
      {
        CustomTabControl.Form1.TabContextMenu.Show(Cursor.Position);
        this.contextTab = this.GetPointedTab();
      }
      base.OnMouseUp(e);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
      Graphics graphics = e.Graphics;
      graphics.SmoothingMode = SmoothingMode.HighQuality;
      graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
      graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
      graphics.Clear(this.headerColor);
      try
      {
        this.SelectedTab.BackColor = this.backTabColor;
      }
      catch
      {
      }
      try
      {
        this.SelectedTab.BorderStyle = BorderStyle.None;
      }
      catch
      {
      }
      for (int index = 0; index <= this.TabCount - 1; ++index)
      {
        TabPage tabPage1 = this.TabPages[index];
        TabPage tabPage2 = tabPage1;
        SizeF sizeF = e.Graphics.MeasureString(tabPage1.Text, this.Font);
        int num1;
        int num2 = num1 = (int) sizeF.Width + 16;
        tabPage2.Width = num1;
        Rectangle rectangle;
        ref Rectangle local = ref rectangle;
        Rectangle tabRect = this.GetTabRect(index);
        Point location1 = tabRect.Location;
        int x = location1.X + 2;
        tabRect = this.GetTabRect(index);
        location1 = tabRect.Location;
        int y = location1.Y;
        Point location2 = new Point(x, y);
        tabRect = this.GetTabRect(index);
        int width = tabRect.Width;
        tabRect = this.GetTabRect(index);
        int height = tabRect.Height;
        Size size = new Size(width, height);
        local = new Rectangle(location2, size);
        Rectangle rect = new Rectangle(rectangle.Location, new Size(rectangle.Width, rectangle.Height));
        Brush brush = (Brush) new SolidBrush(this.closingButtonColor);
        if (index != this.SelectedIndex)
        {
          graphics.DrawString(tabPage1.Text, this.Font, (Brush) new SolidBrush(this.textColor), (RectangleF) rect, this.CenterSringFormat);
        }
        else
        {
          graphics.FillRectangle((Brush) new SolidBrush(this.headerColor), rect);
          graphics.FillRectangle((Brush) new SolidBrush(Color.FromArgb(36, 36, 36)), new Rectangle(rectangle.X - 5, rectangle.Y - 3, rectangle.Width, rectangle.Height + 5));
          graphics.DrawString(tabPage1.Text, this.Font, (Brush) new SolidBrush(this.selectedTextColor), (RectangleF) rect, this.CenterSringFormat);
        }
        if (index != this.TabCount - 1)
        {
          if (this.ShowClosingButton)
            e.Graphics.DrawString("X", this.Font, brush, (float) (rect.Right - 17), 3f);
        }
        else
        {
          using (Font font = new Font(SystemFonts.DefaultFont.FontFamily, 14f, FontStyle.Bold))
            e.Graphics.DrawString("+", font, brush, (float) (rect.Right - 22), (float) (rect.Top / 2 - 4));
        }
        brush.Dispose();
      }
      graphics.DrawLine(new Pen(Color.FromArgb(36, 36, 36), 5f), new Point(0, 19), new Point(this.Width, 19));
      graphics.FillRectangle((Brush) new SolidBrush(this.backTabColor), new Rectangle(0, 20, this.Width, this.Height - 20));
      graphics.DrawRectangle(new Pen(this.borderColor, 2f), new Rectangle(0, 0, this.Width, this.Height));
      graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
    }

    private TabPage GetPointedTab()
    {
      for (int index = 0; index <= this.TabPages.Count - 1; ++index)
      {
        if (this.GetTabRect(index).Contains(this.PointToClient(Cursor.Position)))
          return this.TabPages[index];
      }
      return (TabPage) null;
    }

    private void ReplaceTabPages(TabPage Source, TabPage Destination)
    {
      object obj1 = (object) this.TabPages.IndexOf(Source);
      object obj2 = (object) this.TabPages.IndexOf(Destination);
      // ISSUE: reference to a compiler-generated field
      if (CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (CustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj3 = CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__0.Target((CallSite) CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__0, obj1, -1);
      // ISSUE: reference to a compiler-generated field
      if (CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__1 == null)
      {
        // ISSUE: reference to a compiler-generated field
        CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (CustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      if ((CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__1.Target((CallSite) CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__1, obj3) ? 1 : 0) != 0)
        return;
      // ISSUE: reference to a compiler-generated field
      if (CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__4 == null)
      {
        // ISSUE: reference to a compiler-generated field
        CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__4 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (CustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target1 = CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__4.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p4 = CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__4;
      // ISSUE: reference to a compiler-generated field
      if (CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__3 == null)
      {
        // ISSUE: reference to a compiler-generated field
        CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__3 = CallSite<Func<CallSite, object, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Or, typeof (CustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, object, object> target2 = CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__3.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, object, object>> p3 = CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__3;
      object obj4 = obj3;
      // ISSUE: reference to a compiler-generated field
      if (CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__2 == null)
      {
        // ISSUE: reference to a compiler-generated field
        CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__2 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (CustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj5 = CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__2.Target((CallSite) CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__2, obj2, -1);
      object obj6 = target2((CallSite) p3, obj4, obj5);
      if ((target1((CallSite) p4, obj6) ? 1 : 0) != 0)
        return;
      // ISSUE: reference to a compiler-generated field
      if (CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__5 == null)
      {
        // ISSUE: reference to a compiler-generated field
        CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__5 = CallSite<Func<CallSite, TabControl.TabPageCollection, object, TabPage, object>>.Create(Binder.SetIndex(CSharpBinderFlags.None, typeof (CustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[3]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj7 = CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__5.Target((CallSite) CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__5, this.TabPages, obj2, Source);
      // ISSUE: reference to a compiler-generated field
      if (CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__6 == null)
      {
        // ISSUE: reference to a compiler-generated field
        CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__6 = CallSite<Func<CallSite, TabControl.TabPageCollection, object, TabPage, object>>.Create(Binder.SetIndex(CSharpBinderFlags.None, typeof (CustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[3]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj8 = CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__6.Target((CallSite) CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__6, this.TabPages, obj1, Destination);
      // ISSUE: reference to a compiler-generated field
      if (CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__8 == null)
      {
        // ISSUE: reference to a compiler-generated field
        CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__8 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (CustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      Func<CallSite, object, bool> target3 = CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__8.Target;
      // ISSUE: reference to a compiler-generated field
      CallSite<Func<CallSite, object, bool>> p8 = CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__8;
      // ISSUE: reference to a compiler-generated field
      if (CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__7 == null)
      {
        // ISSUE: reference to a compiler-generated field
        CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__7 = CallSite<Func<CallSite, int, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (CustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj9 = CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__7.Target((CallSite) CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__7, this.SelectedIndex, obj1);
      if (target3((CallSite) p8, obj9))
      {
        // ISSUE: reference to a compiler-generated field
        if (CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__9 == null)
        {
          // ISSUE: reference to a compiler-generated field
          CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__9 = CallSite<Func<CallSite, object, int>>.Create(Binder.Convert(CSharpBinderFlags.None, typeof (int), typeof (CustomTabControl)));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        this.SelectedIndex = CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__9.Target((CallSite) CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__9, obj2);
      }
      else
      {
        // ISSUE: reference to a compiler-generated field
        if (CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__11 == null)
        {
          // ISSUE: reference to a compiler-generated field
          CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__11 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (CustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        Func<CallSite, object, bool> target4 = CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__11.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Func<CallSite, object, bool>> p11 = CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__11;
        // ISSUE: reference to a compiler-generated field
        if (CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__10 == null)
        {
          // ISSUE: reference to a compiler-generated field
          CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__10 = CallSite<Func<CallSite, int, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (CustomTabControl), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj10 = CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__10.Target((CallSite) CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__10, this.SelectedIndex, obj2);
        if (target4((CallSite) p11, obj10))
        {
          // ISSUE: reference to a compiler-generated field
          if (CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__12 == null)
          {
            // ISSUE: reference to a compiler-generated field
            CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__12 = CallSite<Func<CallSite, object, int>>.Create(Binder.Convert(CSharpBinderFlags.None, typeof (int), typeof (CustomTabControl)));
          }
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          this.SelectedIndex = CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__12.Target((CallSite) CustomTabControl.\u003C\u003Eo__58.\u003C\u003Ep__12, obj1);
        }
      }
      this.Refresh();
    }

    public void CloseTab(TabPage tab)
    {
      Scintilla control = tab.Controls[0] as Scintilla;
      int index = this.TabPages.IndexOf(tab);
      if (index != 0 || this.TabCount > 2)
      {
        this.TabPages.RemoveAt(index);
        --this.count;
      }
      else
      {
        TabPage tabPage = this.TabPages[0];
        tab.Text = "Untitled.lua";
        control.Text = "";
        control.Refresh();
      }
    }

    private void DragOverEnterHandler(object sender, DragEventArgs e)
    {
      if (e.Data.GetDataPresent(DataFormats.FileDrop))
        e.Effect = DragDropEffects.Copy;
      else
        e.Effect = DragDropEffects.None;
    }

    private void DragDropHandler(object sender, DragEventArgs e)
    {
      foreach (string path in (string[]) e.Data.GetData(DataFormats.FileDrop, false))
        this.AddEvent(Path.GetFileNameWithoutExtension(path), File.ReadAllText(path));
    }

    public Scintilla NewEditor(string script)
    {
      Scintilla scintilla = new Scintilla();
      scintilla.AllowDrop = true;
      scintilla.AutomaticFold = AutomaticFold.Show | AutomaticFold.Click | AutomaticFold.Change;
      scintilla.BackColor = Color.Black;
      scintilla.BorderStyle = BorderStyle.None;
      scintilla.Lexer = Lexer.Lua;
      scintilla.Name = "scintilla";
      scintilla.Dock = DockStyle.Fill;
      scintilla.ScrollWidth = 1;
      scintilla.TabIndex = 0;
      scintilla.Styles[32].Size = 15;
      scintilla.Styles[32].Size = 15;
      scintilla.Styles[32].Size = 15;
      scintilla.SetSelectionBackColor(true, Color.FromArgb(17, 177, (int) byte.MaxValue));
      scintilla.SetSelectionForeColor(true, Color.Black);
      scintilla.Margins[1].Width = 0;
      scintilla.StyleResetDefault();
      scintilla.Styles[32].Font = "Consolas";
      scintilla.Styles[32].Size = 10;
      scintilla.Styles[32].BackColor = Color.FromArgb(40, 40, 40);
      scintilla.Styles[32].ForeColor = Color.White;
      scintilla.StyleClearAll();
      scintilla.Styles[11].ForeColor = Color.White;
      scintilla.Styles[1].ForeColor = Color.FromArgb(79, 81, 98);
      scintilla.Styles[2].ForeColor = Color.FromArgb(79, 81, 98);
      scintilla.Styles[3].ForeColor = Color.FromArgb(58, 64, 34);
      scintilla.Styles[4].ForeColor = Color.FromArgb(165, 112, (int) byte.MaxValue);
      scintilla.Styles[6].ForeColor = Color.FromArgb((int) byte.MaxValue, 192, 115);
      scintilla.Styles[7].ForeColor = Color.FromArgb((int) byte.MaxValue, 192, 115);
      scintilla.Styles[8].ForeColor = Color.FromArgb((int) byte.MaxValue, 192, 115);
      scintilla.Styles[9].ForeColor = Color.FromArgb(138, 175, 238);
      scintilla.Styles[10].ForeColor = Color.White;
      scintilla.Styles[5].ForeColor = Color.FromArgb((int) byte.MaxValue, 60, 122);
      scintilla.Styles[13].ForeColor = Color.FromArgb(89, (int) byte.MaxValue, 172);
      scintilla.Styles[13].Bold = true;
      scintilla.Styles[14].ForeColor = Color.FromArgb(89, (int) byte.MaxValue, 172);
      scintilla.Styles[14].Bold = true;
      scintilla.Lexer = Lexer.Lua;
      scintilla.SetProperty("fold", "1");
      scintilla.SetProperty("fold.compact", "1");
      scintilla.Margins[0].Width = 15;
      scintilla.Margins[0].Type = MarginType.Number;
      scintilla.Margins[1].Type = MarginType.Symbol;
      scintilla.Margins[1].Mask = 4261412864U;
      scintilla.Margins[1].Sensitive = true;
      scintilla.Margins[1].Width = 8;
      for (int index = 25; index <= 31; ++index)
      {
        scintilla.Markers[index].SetForeColor(Color.White);
        scintilla.Markers[index].SetBackColor(Color.White);
      }
      scintilla.Markers[30].Symbol = MarkerSymbol.BoxPlus;
      scintilla.Markers[31].Symbol = MarkerSymbol.BoxMinus;
      scintilla.Markers[25].Symbol = MarkerSymbol.BoxPlusConnected;
      scintilla.Markers[27].Symbol = MarkerSymbol.TCorner;
      scintilla.Markers[26].Symbol = MarkerSymbol.BoxMinusConnected;
      scintilla.Markers[29].Symbol = MarkerSymbol.VLine;
      scintilla.Markers[28].Symbol = MarkerSymbol.LCorner;
      scintilla.Styles[33].BackColor = Color.FromArgb(40, 40, 40);
      scintilla.AutomaticFold = AutomaticFold.Show | AutomaticFold.Click | AutomaticFold.Change;
      scintilla.SetFoldMarginColor(true, Color.FromArgb(40, 40, 40));
      scintilla.SetFoldMarginHighlightColor(true, Color.FromArgb(40, 40, 40));
      scintilla.SetKeywords(0, "and break do else elseif end false for function if in local nil not or repeat return then true until while continue");
      scintilla.SetKeywords(1, "warn CFrame CFrame.fromEulerAnglesXYZ Synapse Decompile Synapse Copy Synapse Write CFrame.Angles CFrame.fromAxisAngle CFrame.new gcinfo os os.difftime os.time tick UDim UDim.new Instance Instance.Lock Instance.Unlock Instance.new pairs NumberSequence NumberSequence.new assert tonumber getmetatable Color3 Color3.fromHSV Color3.toHSV Color3.fromRGB Color3.new load Stats _G UserSettings Ray Ray.new coroutine coroutine.resume coroutine.yield coroutine.status coroutine.wrap coroutine.create coroutine.running NumberRange NumberRange.new PhysicalProperties Physicalnew printidentity PluginManager loadstring NumberSequenceKeypoint NumberSequenceKeypoint.new Version Vector2 Vector2.new wait game. game.Players game.ReplicatedStorage Game delay spawn string string.sub string.upper string.len string.gfind string.rep string.find string.match string.char string.dump string.gmatch string.reverse string.byte string.format string.gsub string.lower CellId CellId.new Delay version stats typeof UDim2 UDim2.new table table.setn table.insert table.getn table.foreachi table.maxn table.foreach table.concat table.sort table.remove settings LoadLibrary require Vector3 Vector3.FromNormalId Vector3.FromAxis Vector3.new Vector3int16 Vector3int16.new setmetatable next ypcall ipairs Wait rawequal Region3int16 Region3int16.new collectgarbage game newproxy Spawn elapsedTime Region3 Region3.new time xpcall shared rawset tostring print Workspace Vector2int16 Vector2int16.new workspace unpack math math.log math.noise math.acos math.huge math.ldexp math.pi math.cos math.tanh math.pow math.deg math.tan math.cosh math.sinh math.random math.randomseed math.frexp math.ceil math.floor math.rad math.abs math.sqrt math.modf math.asin math.min math.max math.fmod math.log10 math.atan2 math.exp math.sin math.atan ColorSequenceKeypoint ColorSequenceKeypoint.new pcall getfenv ColorSequence ColorSequence.new type ElapsedTime select Faces Faces.new rawget debug debug.traceback debug.profileend debug.profilebegin Rect Rect.new BrickColor BrickColor.Blue BrickColor.White BrickColor.Yellow BrickColor.Red BrickColor.Gray BrickColor.palette BrickColor.New BrickColor.Black BrickColor.Green BrickColor.Random BrickColor.DarkGray BrickColor.random BrickColor.new setfenv dofile Axes Axes.new error loadfile ");
      scintilla.SetKeywords(2, "getrawmetatable loadstring getnamecallmethod setreadonly islclosure getgenv unlockModule lockModule mousemoverel debug.getupvalue debug.getupvalues debug.setupvalue debug.getmetatable debug.getregistry setclipboard setthreadcontext getthreadcontext checkcaller getgc debug.getconstant getrenv getreg ");
      scintilla.ScrollWidth = 1;
      scintilla.ScrollWidthTracking = true;
      scintilla.CaretForeColor = Color.White;
      scintilla.BackColor = Color.White;
      scintilla.BorderStyle = BorderStyle.None;
      scintilla.TextChanged += new EventHandler(this.scintilla1_TextChanged);
      scintilla.WrapIndentMode = WrapIndentMode.Indent;
      scintilla.WrapVisualFlagLocation = WrapVisualFlagLocation.EndByText;
      scintilla.BorderStyle = BorderStyle.None;
      scintilla.Text = script;
      return scintilla;
    }

    private void scintilla1_TextChanged(object sender, EventArgs e)
    {
      Scintilla scintilla = (Scintilla) sender;
      int length = scintilla.Lines.Count.ToString().Length;
      scintilla.Margins[0].Width = scintilla.TextWidth(10, new string('9', length + 1)) + 2;
    }

    public void addnewtab()
    {
      int index = this.TabCount - 1;
      this.TabPages.Insert(index, string.Format("Script{0}.lua", (object) this.TabCount));
      this.TabPages[index].Controls.Add((Control) this.NewEditor(""));
      this.SelectedIndex = index;
    }

    public Scintilla GetWorkingTextEditor()
    {
      if (this.SelectedTab.Controls.Count == 0)
        return (Scintilla) null;
      if (this.SelectedTab != null)
        return this.SelectedTab.Controls[0] as Scintilla;
      this.addnewtab();
      return this.SelectedTab.Controls[0] as Scintilla;
    }

    public void AddEvent(string name = "Script.lua", string content = "")
    {
      if (string.IsNullOrEmpty(this.GetWorkingTextEditor().Text) && !string.IsNullOrEmpty(content))
      {
        this.addnewtab();
        this.SelectedTab.Text = "Script " + this.count.ToString() + ".lua";
        this.SelectedTab.Controls[0].Text = content;
        this.SelectedTab.Controls[0].Refresh();
      }
      else
      {
        this.addnewtab();
        if (name.Contains("Script" + this.count.ToString() + ".lua"))
          this.SelectedTab.Text = "Script " + this.count.ToString() + ".lua";
      }
      ++this.count;
    }

    public void TabChanging(object sender, TabControlCancelEventArgs e)
    {
      if (e.TabPageIndex != this.TabCount - 1)
        return;
      e.Cancel = true;
    }

    public string OpenSaveDialog(TabPage tab, string text)
    {
      using (SaveFileDialog saveFileDialog = new SaveFileDialog())
      {
        saveFileDialog.Filter = "Lua Files (*.lua)|*.lua|Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
        saveFileDialog.RestoreDirectory = true;
        saveFileDialog.FileName = tab.Text;
        if (saveFileDialog.ShowDialog() != DialogResult.OK)
          return tab.Text;
        File.WriteAllText(saveFileDialog.FileName, text);
        return new FileInfo(saveFileDialog.FileName).Name;
      }
    }

    public void RenameTab(string text)
    {
    }

    public bool OpenFileDialog(TabPage tab)
    {
      using (System.Windows.Forms.OpenFileDialog openFileDialog = new System.Windows.Forms.OpenFileDialog())
      {
        openFileDialog.Filter = "Lua Files (*.lua)|*.lua|Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
        openFileDialog.RestoreDirectory = true;
        if (openFileDialog.ShowDialog() != DialogResult.OK)
          return false;
        this.GetWorkingTextEditor().Text = File.ReadAllText(openFileDialog.FileName);
        tab.Text = Path.GetFileName(openFileDialog.FileName);
        return true;
      }
    }
  }
}
