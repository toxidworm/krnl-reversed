﻿// Decompiled with JetBrains decompiler
// Type: injection.krnlgay
// Assembly: krnlss, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 1D51A737-46C7-4798-AAF1-4373D41D8FFF
// Assembly location: C:\Users\Win10\Desktop\krnl\krnlss.exe

using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace injection
{
  public class krnlgay
  {
    public static IntPtr INTPTR_ZERO = IntPtr.Zero;

    public enum krnlgayResult
    {
      DllNotFound,
      ProcessNotFound,
      Failed,
      Success,
      threaderr,
    }

    public sealed class DllInjector
    {
      private static krnlgay.DllInjector _instance;

      public static krnlgay.DllInjector GetInstance
      {
        get
        {
          if (krnlgay.DllInjector._instance == null)
            krnlgay.DllInjector._instance = new krnlgay.DllInjector();
          return krnlgay.DllInjector._instance;
        }
      }

      [DllImport("kernel32.dll")]
      private static extern int ResumeThread(IntPtr hThread);

      [DllImport("kernel32.dll", SetLastError = true)]
      private static extern int CloseHandle(IntPtr hObject);

      [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
      private static extern bool WaitNamedPipe(string name, int timeout);

      [DllImport("kernel32.dll", SetLastError = true)]
      private static extern IntPtr CreateRemoteThread(
        IntPtr hProcess,
        IntPtr lpThreadAttribute,
        IntPtr dwStackSize,
        IntPtr lpStartAddress,
        IntPtr lpParameter,
        uint dwCreationFlags,
        IntPtr lpThreadId);

      [DllImport("kernel32.dll", SetLastError = true)]
      private static extern IntPtr GetModuleHandle(string lpModuleName);

      [DllImport("kernel32.dll", SetLastError = true)]
      private static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);

      [DllImport("kernel32.dll", SetLastError = true)]
      private static extern IntPtr OpenProcess(
        uint dwDesiredAccess,
        int bInheritHandle,
        uint dwProcessId);

      [DllImport("kernel32.dll", SetLastError = true)]
      private static extern IntPtr VirtualAllocEx(
        IntPtr hProcess,
        IntPtr lpAddress,
        IntPtr dwSize,
        uint flAllocationType,
        uint flProtect);

      [DllImport("kernel32.dll", SetLastError = true)]
      private static extern int WriteProcessMemory(
        IntPtr hProcess,
        IntPtr lpBaseAddress,
        byte[] buffer,
        uint size,
        int lpNumberOfBytesWritten);

      private DllInjector()
      {
      }

      private bool dllinject(uint pToBeInjected, string sDllPath)
      {
        IntPtr num1 = krnlgay.DllInjector.OpenProcess(1082U, 1, pToBeInjected);
        if (!(num1 != krnlgay.INTPTR_ZERO))
          return false;
        IntPtr procAddress = krnlgay.DllInjector.GetProcAddress(krnlgay.DllInjector.GetModuleHandle("kernel32.dll"), "LoadLibraryA");
        if (!(procAddress != krnlgay.INTPTR_ZERO))
          return false;
        IntPtr num2 = krnlgay.DllInjector.VirtualAllocEx(num1, (IntPtr) 0, (IntPtr) sDllPath.Length, 12288U, 64U);
        IntPtr remoteThread = krnlgay.DllInjector.CreateRemoteThread(num1, (IntPtr) 0, krnlgay.INTPTR_ZERO, procAddress, num2, 0U, (IntPtr) 0);
        if (!(num2 != krnlgay.INTPTR_ZERO) || krnlgay.DllInjector.WriteProcessMemory(num1, num2, Encoding.ASCII.GetBytes(sDllPath), (uint) Encoding.ASCII.GetBytes(sDllPath).Length, 0) == 0 || !(remoteThread != krnlgay.INTPTR_ZERO))
          return false;
        krnlgay.DllInjector.CloseHandle(num1);
        return true;
      }

      public krnlgay.krnlgayResult Inject(string sDllPath, int PID, bool threadject = false)
      {
        if (!File.Exists(sDllPath))
          return krnlgay.krnlgayResult.DllNotFound;
        if (threadject)
          return krnlgay.krnlgayResult.threaderr;
        Process[] processes = Process.GetProcesses();
        int index = 0;
        uint pToBeInjected = 0;
        for (; index < processes.Length; ++index)
        {
          if (processes[index].Id == PID)
          {
            pToBeInjected = (uint) PID;
            break;
          }
        }
        if (pToBeInjected == 0U)
          return krnlgay.krnlgayResult.ProcessNotFound;
        return !this.dllinject(pToBeInjected, sDllPath) ? krnlgay.krnlgayResult.Failed : krnlgay.krnlgayResult.Success;
      }
    }
  }
}
