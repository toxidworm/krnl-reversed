﻿// Decompiled with JetBrains decompiler
// Type: ToggleSlider.ToggleSliderComponent
// Assembly: krnlss, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 1D51A737-46C7-4798-AAF1-4373D41D8FFF
// Assembly location: C:\Users\Win10\Desktop\krnl\krnlss.exe

using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace ToggleSlider
{
  public class ToggleSliderComponent : UserControl
  {
    private bool Checked_bool;
    private Color ToggleColorDisabled_Color = Color.Green;
    private Color Bar_Color = Color.Gray;
    private string Text = "toggleSlider1";
    private int posx;
    private int posy;
    private bool init_ = true;
    private Color circlecolor_;
    private bool animating_;
    private Timer timer1 = new Timer();
    private IContainer components;

    public bool Checked
    {
      get => this.Checked_bool;
      set
      {
        this.Checked_bool = value;
        this.Invalidate();
      }
    }

    public Color ToggleCircleColor
    {
      get => this.ToggleColorDisabled_Color;
      set
      {
        this.ToggleColorDisabled_Color = value;
        this.Invalidate();
      }
    }

    public Color ToggleColorBar
    {
      get => this.Bar_Color;
      set
      {
        this.Bar_Color = value;
        this.Invalidate();
      }
    }

    public string ToggleBarText
    {
      get => this.Text;
      set
      {
        this.Text = value;
        this.Invalidate();
      }
    }

    public event EventHandler CheckChanged;

    public ToggleSliderComponent()
    {
      this.InitializeComponent();
      this.DoubleBuffered = true;
      this.Click += new EventHandler(this.ToggleSlider_Click);
      this.timer1.Tick += new EventHandler(this.Timer1_Tick);
      this.AutoSize = true;
    }

    protected override void OnPaint(PaintEventArgs pevent)
    {
      if (this.init_)
        this.circlecolor_ = this.ToggleColorDisabled_Color;
      pevent.Graphics.SmoothingMode = SmoothingMode.HighQuality;
      Size size = new Size(Convert.ToInt32(this.Font.SizeInPoints * 5f), Convert.ToInt32(this.Font.SizeInPoints * 5f));
      ToggleSliderComponent.RoundedRect(this.Bar_Color, pevent.Graphics, new Rectangle(size.Width / 4, size.Height / 5 / 2, size.Width / 2, 3 * (size.Height / 5) / 2), 5);
      LinearGradientBrush linearGradientBrush = new LinearGradientBrush(new Point(size.Width / 4, size.Height / 5 / 2), new Point(size.Width / 2, size.Height / 2), this.ToggleColorDisabled_Color, this.ToggleColorDisabled_Color);
      if (!this.animating_)
        this.posx = this.Checked_bool ? size.Width / 2 : 0;
      pevent.Graphics.FillEllipse((Brush) new SolidBrush(this.ToggleColorDisabled_Color), this.posx, this.posy, size.Width / 2, size.Height / 2);
      TextRenderer.DrawText((IDeviceContext) pevent.Graphics, this.ToggleBarText, this.Font, new Point(size.Width, size.Height / 10), this.ForeColor);
      this.SetStyle(ControlStyles.SupportsTransparentBackColor, true);
    }

    private void ToggleSlider_Click(object sender, EventArgs e) => this.Animate();

    private void Animate()
    {
      this.timer1.Interval = 1;
      this.timer1.Start();
      this.animating_ = true;
    }

    private void Timer1_Tick(object sender, EventArgs e)
    {
      Size size = new Size(Convert.ToInt32(this.Font.SizeInPoints * 5f), Convert.ToInt32(this.Font.SizeInPoints * 5f));
      if (this.Checked_bool)
      {
        if (this.posx > 0)
        {
          this.posx -= 3;
          this.Invalidate();
        }
        else
        {
          this.Checked_bool = false;
          this.animating_ = false;
          if (this.CheckChanged != null)
            this.CheckChanged((object) this, e);
          this.timer1.Stop();
        }
      }
      else
      {
        this.init_ = false;
        if (this.posx < size.Width / 2)
        {
          this.posx += 3;
          this.Invalidate();
        }
        else
        {
          this.Checked_bool = true;
          this.animating_ = false;
          if (this.CheckChanged != null)
            this.CheckChanged((object) this, e);
          this.timer1.Stop();
        }
      }
    }

    public static GraphicsPath RoundedRect(
      Color c,
      Graphics g,
      Rectangle bounds,
      int radius)
    {
      int num = radius * 2;
      Size size = new Size(num, num);
      Rectangle rect = new Rectangle(bounds.Location, size);
      GraphicsPath path = new GraphicsPath();
      if (radius == 0)
      {
        path.AddRectangle(bounds);
        return path;
      }
      path.AddArc(rect, 180f, 90f);
      rect.X = bounds.Right - num;
      path.AddArc(rect, 270f, 90f);
      rect.Y = bounds.Bottom - num;
      path.AddArc(rect, 0.0f, 90f);
      rect.X = bounds.Left;
      path.AddArc(rect, 90f, 90f);
      g.FillPath((Brush) new SolidBrush(c), path);
      path.CloseFigure();
      return path;
    }

    private void ToggleSliderComponent_Load(object sender, EventArgs e)
    {
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.SuspendLayout();
      this.AutoScaleDimensions = new SizeF(8f, 16f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.Margin = new Padding(4, 4, 4, 4);
      this.Name = nameof (ToggleSliderComponent);
      this.Size = new Size(308, 52);
      this.Load += new EventHandler(this.ToggleSliderComponent_Load);
      this.ResumeLayout(false);
    }
  }
}
